package com.zsx.healthassistantdoc.activity.customView;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupWindow;

import com.zsx.healthassistantdoc.R;

/**
 * Created by 酸奶 on 2016/4/2.
 */
public class SelectPicPopupWindow extends PopupWindow {
    private String TAG = "zsx";
    private Button btn_take_photo;
    private Button btn_pick_photo;
    private Button btn_cancel;
    private View mMenuView;

    public SelectPicPopupWindow(final Activity activity, View.OnClickListener itemsOnclickListener,
                                final SetBgAlphaCallBack callBack) {
        super(activity);

        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mMenuView = inflater.inflate(R.layout.dialog_pic, null);
        btn_take_photo = (Button) mMenuView.findViewById(R.id.btn_take_photo);
        btn_pick_photo = (Button) mMenuView.findViewById(R.id.btn_pick_photo);
        btn_cancel = (Button) mMenuView.findViewById(R.id.btn_cancel);

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectPicPopupWindow.this.dismiss();
            }
        });
        //设置按钮监听
        btn_take_photo.setOnClickListener(itemsOnclickListener);
        btn_pick_photo.setOnClickListener(itemsOnclickListener);
        //设置SelectPicPopupWindow的View
        this.setContentView(mMenuView);
        //设置SelectPicPopupWindow弹出窗口的宽
        this.setWidth(WindowManager.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体的高
        this.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        //设置SelectPicPopupWindow弹出窗体可点击
        this.setFocusable(true);
        //设置SelectPicPopupWindow弹出窗体动画效果
        this.setAnimationStyle(R.style.mystyle);
        //实例化一个ColorDrawable颜色为半透明
        ColorDrawable dw = new ColorDrawable(0x00ededed);
        //设置SelectPicPopupWindow弹出窗体的背景
        this.setBackgroundDrawable(dw);

        //设置SelectPicPopupWindow弹出窗体的dimiss事件，背景恢复
        this.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss() {
                Log.e(TAG, "onDismiss");
                callBack.setBackgroundAlpha(1.0f);
            }
        });

//        //mMenuView添加OnTouchListener监听判断获取触屏位置如果在选择框外面则销毁弹出框，注：经调试，发现这一块不会被执行
//        mMenuView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                Log.e(TAG,"touch");
//                int height = mMenuView.findViewById(R.id.pop_layout).getTop();
//                int y = (int) event.getY();
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (y < height) {
//                        callBack.setBackgroundAlpha(1.0f);
//                        Log.e(TAG, "点击选择框外，销毁；bg：1.0");
//                        SelectPicPopupWindow.this.dismiss();
//                    }
//                }
//                return true;
//            }
//        });
    }

    public static interface SetBgAlphaCallBack{
        void setBackgroundAlpha(float alpha);
    }
}
