package com.zsx.healthassistantdoc;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class Config {

//    public static final String SEVER_URL = "http://demo.eoeschool.com/api/v1/nimings/io";

    public static final String URL_IP = "192.168.253.1";
    public static final String URL_ROOT = "http://192.168.253.1";

    public static final String URL_SEARCH = "http://192.168.253.1:8080/HelloServer/UserSearchServlet";

    public static final String URL_HEAD = URL_ROOT + ":8080/";
    public static final String URL_TEST = URL_ROOT + ":8080/HelloServer/LoginServlet";
    public static final String URL_UPLOAD = URL_ROOT + ":8080/HelloServer/UploadfileServlet";
    public static final String URL_UPLOAD_CHAT_IMG = URL_ROOT + ":8080/HelloServer/UploadChatImageServlet";
    public static final String URL_HELLOSERVER = URL_ROOT + ":8080/HelloServer";

    public static final String URL_SERVLET = ":8080/HelloServer/LoginServlet";

    public static final String PROVINCE_URL = "http://www.hisihi.com/app.php?s=/school/province";
    public static final String SCHOOL_URL = "http://www.hisihi.com/app.php?s=/school/school/provinceid/";

    public static final String TAG = "ZSX";
    public static final String JPG = ".jpg";

    public static final String STUDENT_ID = "student_id";
    public static final String STUDENT_NAME = "student_name";
    public static final String STUDENT_HEAD = "student_head";
    public static final String ARTICLE_ID = "article_id";
    public static final String PATH_HEAD = "/sdcard/HealthMamaDoc/UserHead/";
    public static final String NAME_HEAD = "head.jpg";

    public static final int CHAT_MESSAGE = 1;
    public static final int CHAT_IMAGE = 2;
    public static final int CHAT_ALL = 3;
    public static final String CHAT_SERVER_NAME = "bill-think";
    public static final String URL_ADD_KEY_WORD="X3fs96j";


    //参数值
    //一、请求
    //1、数据请求方式
    //(1)、键
    public static final String KEY_ACTION = "action";
    //(2)、值
    public static final String ACTION_GET_CODE = "send_pass";//获取验证码
    public static final String ACTION_REGISTER = "register";//注册
    public static final String ACTION_LOGIN_DOC = "login_doc";//登录
    //2、注册操作
    //(1)、键
    public static final String KEY_PHONE = "phone";
    public static final String KEY_PHONE_MD5 = "phone_md5";
    public static final String KEY_CODE = "code";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_IMPROVE = "improve";
//    public static final String KEY_ = "";
    //3、修改信息操作
    public static final String KEY_MODIFY_NICKNAME = "modify_nickname";
    public static final String KEY_MODIFY_PASSWORD = "modify_password";
    //4、获取文章操作
    public static final String ACTION_LAST_ARTICLE_3 = "last_article_3_doc";
    public static final String ACTION_HOT_ARTICLE_3 = "hot_article_3_doc";
    public static final String ACTION_ARTICLE = "article";
    public static final String KEY_ID = "id";
    public static final String KEY_TITLE = "title";
//    public static final String KEY_CLASS = "class";
    public static final String KEY_KIND = "kind";
    public static final String KEY_DATE = "date";
    public static final String KEY_SOURCE = "source";
    public static final String KEY_CONTENT = "content";
    public static final String KEY_COMMENT = "comment";
    public static final String KEY_TIME = "time";

    public static final String KEY_BROWSE ="browse";
    //5、搜索操作
    public static final String KEY_SEARCHWORDS = "searchwords";
    public static final String ACTION_ARTICLE_SEARCH = "article_search";
    public static final String KEY_NUM = "num";
    //6、提交评论、评价、意见反馈操作
    public static final String ACTION_COMMENT_COMMIT_DOC = "comment_commit_doc";
    public static final String ACTION_JUDGE_COMMIT = "judge_commit";
    public static final String ACTION_FEEDBACK = "feedback";
//    public static final String KEY_CONTENT = "content";
    //7、获取医生列表
    public static final String ACTION_DOCTOR_LIST = "doctor_list";
    public static final String KEY_DEPARTMENT = "department";
    public static final String KEY_NAME = "name";
    public static final String KEY_HOSPITAL = "hospital";
    public static final String KEY_POSITION = "position";
    public static final String ACTION_DOCTOR_LIKE = "doctor_like";

    public static final String ACTION_STUDENT_DETAIL = "student_detail";
    //    public static final String KEY_PHONE = "name";
    //8、文章详情
    public static final String ACTION_ARTICLE_DETAIL_DOC = "article_detail";
    public static final String ACTION_DOC_LIKE_COMMIT = "doc_like_commit";
    public static final String KEY_LIKE= "like";
    public static final String KEY_ARTICLE= "article";
    public static final String ACTION_COMMENT_GET_DOC = "comment_get";
    public static final String ACTION_ARTICLE_LIKE = "article_like";

    public static final String KEY_LIST = "list";
    public static final String KEY_CLICK = "click";

//    public static final String


    //3、登录操作
    //(1)、键
//    public static final String KEY_PHONE = "phone";//见注册操作
//    public static final String KEY_PASSWORD = "password";

    //二、返回
    //1、获取验证码、注册操作
    //(1)、键
    public static final String KEY_STATUS = "status";
    //(2)、值
    public static final int RESULLT_STATUS_SUCCESS = 0;
    public static final int RESULT_STATUS_NO_USER = 1;
    public static final int RESULT_STATUS_PASS_WRONG = 2;

    //2、登录操作
//    public static final String KEY_STATUS = "status";//见1
    public static final String KEY_TOKEN = "token";

    //登录获取用户的信息JSON键名
    public static final String KEY_BODY = "body";
    public static final String KEY_NICKNAME = "nickname";
    public static final String KEY_USERID = "userid";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_SEX = "sex";
    public static final String KEY_AREA = "area";
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_SCHOOL = "school";
    public static final String KEY_HEAD = "head";

    public static final String APP_ID = "com.zsx.healthassistantdoc";
    public static final String CHARSET = "utf-8";
    public static final String METHOD_LOGIN = "LoginServlet";//访问的方法名

    //图灵机器人api调用
    public static final String KEY_KEY = "key";
    public static final String KEY_INFO = "info";
//    public static final String KEY_USERID = "userid";

    public static final String API_KEY = "52e0a7932c1ab3d803a7814b18348e26";
    public static final String API_USERID = "12345678";

    public static final String API_ANDRESS = "http://www.tuling123.com/openapi/api";

    public static final String API_FIRST_VALUE = "code";
    public static final String API_SECOND_VALUE = "text";

    //获取head
    public static String getCachedHead(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_HEAD, null);
    }
    //缓存head
    public static void cacheHead(Context context,String head) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_HEAD, head);
        e.commit();
    }
    //获取token
    public static String getCachedToken(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
    }
    //缓存token
    public static void cacheToken(Context context,String token) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_TOKEN, token);
        e.commit();
    }
    //获取用户名,即手机号码
    public static String getCachedUserid(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_USERID, null);
    }
    //缓存密码
    public static void cachePassword(Context context,String password) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_PASSWORD, password);
        e.commit();
    }
    //获取密码
    public static String getCachedPassword(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_PASSWORD, null);
    }
    //缓存用户名
    public static void cacheUserid(Context context,String userid) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_USERID, userid);
        e.commit();
    }
    //获取nickname
    public static String getCachedName(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_NAME, null);
    }
    //缓存nickname
    public static void cacheName(Context context,String name) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_NAME, name);
        e.commit();
    }
    //获取sex
    public static String getCachedSex(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_SEX, null);
    }
    //缓存sex
    public static void cacheSex(Context context,String sex) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_SEX, sex);
        e.commit();
    }
    //获取area
    public static String getCachedArea(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_AREA, null);
    }
    //缓存area
    public static void cacheArea(Context context,String area) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_AREA, area);
        e.commit();
    }
    //获取hospital
    public static String getCachedHospital(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_ADDRESS, null);
    }
    //缓存hospital
    public static void cacheHospital(Context context,String address) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_ADDRESS, address);
        e.commit();
    }
    //获取position
    public static String getCachedPosition(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_POSITION, null);
    }
    //缓存position
    public static void cachePosition(Context context,String position) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_POSITION, position);
        e.commit();
    }

    //获取department
    public static String getCachedDepartment(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_DEPARTMENT, null);
    }
    //缓存department
    public static void cacheDepartment(Context context,String department) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_DEPARTMENT, department);
        e.commit();
    }
    //TEST
    public static String getCachedIp(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString("ip", null);
    }
    //缓存ip
    public static void cacheIp(Context context,String ip) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString("ip", ip);
        e.commit();
    }

}
