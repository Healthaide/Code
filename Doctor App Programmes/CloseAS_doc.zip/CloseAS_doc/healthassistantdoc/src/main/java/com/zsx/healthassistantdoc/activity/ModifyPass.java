package com.zsx.healthassistantdoc.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistantdoc.R;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class ModifyPass extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private ImageView img_toolbar_reminder;
    private TextView tv_title;
    private EditText et_old;
    private EditText et_new;
    private EditText et_again;
    private Button btn_commit;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_modify_pass);
        initView();
    }
    private void initView() {

        tv_title = (TextView) findViewById(R.id.tv_title);

        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        et_old = (EditText) findViewById(R.id.et_old_password);
        et_new = (EditText) findViewById(R.id.et_new_password);
        et_again = (EditText) findViewById(R.id.et_new_password_again);
        btn_commit = (Button) findViewById(R.id.btn_commit);


        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("修改密码");

        btn_commit.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_commit:
                if (TextUtils.isEmpty(et_old.getText()) || TextUtils.isEmpty(et_new.getText()) || TextUtils.isEmpty(et_again.getText())) {
                    Toast.makeText(ModifyPass.this, "请输入密码", Toast.LENGTH_SHORT).show();
                }else if (!et_new.getText().toString().equals(et_again.getText().toString())) {
                    Toast.makeText(ModifyPass.this, getString(R.string.str_password_error), Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(ModifyPass.this, "修改成功", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}
