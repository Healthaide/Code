package com.zsx.healthassistantdoc.net;

import android.os.AsyncTask;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class NetConnection {
    private String TAG = "ZSX";
    private JSONObject result = new JSONObject();

    public NetConnection(final String url, final HttpMethod method,
                         final SuccessCallBack successCallBack,
                         final FailCallBack failCallBack,
                         final String... kvs){
        new AsyncTask<Void, Void, String>(){
            @Override
            protected String doInBackground(Void... params) {
//                StringBuffer paramsStr = new StringBuffer();
//                for (int i = 0; i< kvs.length; i += 2) {
//                    paramsStr.append(kvs[i]).append("=").append(kvs[i + 1]).append("&");
//                    Log.i(TAG," "+paramsStr);
//                }
                JSONObject jsonObject = new JSONObject();
                for (int i = 0; i < kvs.length; i += 2) {
                    try {
                        jsonObject.put(kvs[i], kvs[i + 1]);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                JSONArray jsonArray = new JSONArray().put(jsonObject);

                HttpParams httpParams = new BasicHttpParams();
                httpParams.setParameter("charset", "UTF-8");
                HttpClient httpClient = new DefaultHttpClient(httpParams);
//                HttpPost httpPost = new HttpPost(Config.URL_TEST + Config.METHOD_LOGIN);
                HttpPost httpPost = new HttpPost(url);
                try {
                    httpPost.setEntity(new StringEntity(jsonArray.toString(), "UTF-8"));
                    HttpResponse httpResponse = httpClient.execute(httpPost);
                    if (httpResponse.getStatusLine().getStatusCode() == 200) {
                        String returnValue = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
                        JSONArray res = new JSONArray(returnValue);
                        result = res.getJSONObject(0);
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (httpClient != null) {
                    httpClient.getConnectionManager().shutdown();

                }
                return result.toString();
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    if (successCallBack != null) {
                        successCallBack.onSuccess(result);
                    }
                }else {
                    if (failCallBack != null) {
                        failCallBack.onFail();
                    }
                }
                super.onPostExecute(result);
            }
        }.execute();
    }
    public static interface SuccessCallBack{
        void onSuccess(String result);
    }
    public static interface FailCallBack{
        void onFail();
    }
}
