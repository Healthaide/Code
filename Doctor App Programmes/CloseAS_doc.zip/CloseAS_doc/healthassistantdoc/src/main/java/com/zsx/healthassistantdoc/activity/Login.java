package com.zsx.healthassistantdoc.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.MainActivity;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.fragment.FragHome;
import com.zsx.healthassistantdoc.net.HttpMethod;
import com.zsx.healthassistantdoc.net.NetConnection;
import com.zsx.healthassistantdoc.tools.BitmapTools;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by 酸奶 on 2016/3/24.
 */
public class Login extends Activity implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_forget_password;//忘记密码

    private Button btn_login;//登录按钮
    private EditText et_username;//用户名输入框
    private EditText et_password;//密码输入框

    private RequestQueue mQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initView();
    }

    private void initView() {
        mQueue = Volley.newRequestQueue(this);

        tv_forget_password = (TextView) findViewById(R.id.tv_forget_password);
        btn_login = (Button) findViewById(R.id.btn_login);
        et_username = (EditText) findViewById(R.id.et_input_username);
        et_password = (EditText) findViewById(R.id.et_input_password);

        tv_forget_password.setOnClickListener(this);
        btn_login.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                if (TextUtils.isEmpty(et_username.getText().toString())) {
                    Toast.makeText(Login.this, getString(R.string.str_pleaseInputUsername), Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(et_password.getText().toString())) {
                    Toast.makeText(Login.this, getString(R.string.str_pleaseInputPassword), Toast.LENGTH_SHORT).show();
                    return;
                }
                new NetConnection(Config.URL_TEST, HttpMethod.POST,
                        new NetConnection.SuccessCallBack() {
                            @Override
                            public void onSuccess(String result) {
                                try {
                                    JSONObject jsonObject = new JSONObject(result);
                                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                        case Config.RESULLT_STATUS_SUCCESS:
                                            JSONObject body = jsonObject.getJSONObject(Config.KEY_BODY);

                                            //缓存用户信息
                                            //head
                                            Config.cacheHead(Login.this, Config.KEY_HEAD+body.getString(Config.KEY_HEAD));
                                            //token
                                            Config.cacheToken(Login.this, body.getString(Config.KEY_TOKEN));
                                            //userid
                                            Config.cacheUserid(Login.this, et_username.getText().toString());
                                            //password
                                            Config.cachePassword(Login.this, et_password.getText().toString());
                                            //昵称
                                            Config.cacheName(Login.this, body.getString(Config.KEY_NAME));
                                            //性别
                                            Config.cacheSex(Login.this, body.getString(Config.KEY_SEX));
                                            //地区
                                            Config.cacheArea(Login.this, body.getString(Config.KEY_AREA));
                                            //医院
                                            Config.cacheHospital(Login.this, body.getString(Config.KEY_HOSPITAL));
                                            //科室
                                            Config.cacheDepartment(Login.this, body.getString(Config.KEY_DEPARTMENT));
                                            //职位
                                            Config.cachePosition(Login.this, body.getString(Config.KEY_POSITION));

                                            getHeadFromNet(Config.URL_HEAD + body.getString(Config.KEY_HEAD));

                                            Intent intentToMain = new Intent(Login.this, MainActivity.class);
                                            startActivity(intentToMain);
                                            finish();
                                            break;
                                        default:
                                            break;
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new NetConnection.FailCallBack() {
                    @Override
                    public void onFail() {

                    }
                },Config.KEY_ACTION,Config.ACTION_LOGIN_DOC,
                        Config.KEY_PHONE,et_username.getText().toString(),
                        Config.KEY_PASSWORD,et_password.getText().toString());
                break;
        }
    }
    private void getHeadFromNet(String url) {
        Log.i(TAG, "url:" + url);
        ImageRequest imageRequest = new ImageRequest(
                url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        Log.i(TAG, "download head success");
                        BitmapTools.saveHeadImg(bitmap);
                    }
                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "download head fail");
            }
        });
        mQueue.add(imageRequest);
    }
}
