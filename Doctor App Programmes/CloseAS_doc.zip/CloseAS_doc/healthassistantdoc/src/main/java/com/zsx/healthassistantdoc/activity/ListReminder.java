package com.zsx.healthassistantdoc.activity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.customView.RefreshableView;
import com.zsx.healthassistantdoc.activity.customView.refreshView.XListView;
import com.zsx.healthassistantdoc.adapter.ReminderAdapter;
import com.zsx.healthassistantdoc.bean.ReminderDate;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListReminder extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;

    private static Class instance;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private ReminderAdapter mAdapter;
    private List<ReminderDate> mDates;

    private Random random = new Random();
    private String mReminder[] = {
            "【会话提醒】您有新的消息哦",
            "【健康提醒】长时间摊坐在椅子上，轻则损伤骨骼和脊椎，重则影响血液循环，甚至诱发癌症，不可掉以轻心。日常应注意多锻炼，少摊坐。",
            "【系统消息】欢迎使用健康妈妈APP，祝您使用愉快"};

    public static Class getInstance() {
        if (instance != null) {
            instance = ListReminder.class;
        }
        return instance;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_article);
        initView();
        initReminderDate();
    }

    private void initView() {
        mDates = new ArrayList<>();

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("消息提醒");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);

        //设置设配器
        mAdapter = new ReminderAdapter(mDates, this);
        mListView.setAdapter(mAdapter);

        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initReminderDate();
                        onLoad();
                    }
                }, 2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initReminderDate();
                    }
                }, 2000);
                onLoad();
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("刚刚");
    }

    public void initReminderDate() {
        for (int i = 0; i < 3; i++) {
            getDate(i);
            mAdapter.notifyDataSetChanged();
        }
    }

    private void getDate(int i) {
        ReminderDate reminderDate = new ReminderDate(
                mReminder[i],
                "05-"+(12-i));
        mDates.add(reminderDate);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
