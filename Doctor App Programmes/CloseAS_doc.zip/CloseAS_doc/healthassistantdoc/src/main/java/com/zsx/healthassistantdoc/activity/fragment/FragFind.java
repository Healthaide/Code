package com.zsx.healthassistantdoc.activity.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.talk.TalkMain;
import com.zsx.healthassistantdoc.adapter.ChatPreviewAdapter;
import com.zsx.healthassistantdoc.bean.ChatPreviewData;
import com.zsx.healthassistantdoc.net.HttpMethod;
import com.zsx.healthassistantdoc.net.NetConnection;
import com.zsx.healthassistantdoc.tools.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class FragFind extends Fragment{
    private String TAG = "ZSX";
    private View rootView;

    private ListView mListView;
    private ChatPreviewAdapter mAdapter;
    private List<ChatPreviewData> mDates;

    private RequestQueue mQueue;

    private String[] mHead = new String[10000];
    private String[] chatting={"17826833442","17826833461","17826833570","17826833549"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.i(TAG, "");
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.frag_find, null);
            Log.i(TAG,"FragFind:new");
        }
        //缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootView已经有parent的错误
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null) {
            parent.removeView(rootView);
            Log.i(TAG,"FragFind:remove");
        }
        initView(rootView);
        initChatDate();
        return rootView;
    }

    private void initView(View view) {
        mDates = new ArrayList<>();
        mQueue = Volley.newRequestQueue(getActivity());

        mListView = (ListView) view.findViewById(R.id.listview_chat_preview);

        mAdapter = new ChatPreviewAdapter(mDates, getActivity());
        mListView.setAdapter(mAdapter);
        L.i("before listview");
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                L.i("position:" + position);
                Intent intentToTalk = new Intent(getActivity(), TalkMain.class);
                intentToTalk.putExtra(Config.STUDENT_NAME, mDates.get(position).getNickname());
                intentToTalk.putExtra(Config.STUDENT_ID, mDates.get(position).getId());
                intentToTalk.putExtra(Config.STUDENT_HEAD, mHead[position]);
                startActivity(intentToTalk);
            }
        });
        L.i("after listview");
    }
    private void initChatDate() {
        for (int i = 0; i < chatting.length; i++) {
            final int finalI = i;
            new NetConnection(Config.URL_TEST, HttpMethod.POST,
                    new NetConnection.SuccessCallBack() {
                        @Override
                        public void onSuccess(String result) {
                            try {
                                final JSONObject jsonObject = new JSONObject(result);
                                switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                    case Config.RESULLT_STATUS_SUCCESS:
                                        mHead[finalI] = Config.URL_HEAD + jsonObject.getString(Config.KEY_HEAD);
                                        ImageRequest imageRequest = new ImageRequest(
                                                Config.URL_HEAD+jsonObject.getString(Config.KEY_HEAD),
                                                new Response.Listener<Bitmap>() {
                                                    @Override
                                                    public void onResponse(Bitmap bitmap) {
                                                        L.i("download head success");
                                                        try {
                                                            ChatPreviewData date = new ChatPreviewData(
                                                                    bitmap,
                                                                    jsonObject.getString(Config.KEY_PHONE),
                                                                    jsonObject.getString(Config.KEY_NICKNAME),
                                                                    "",
                                                                    "1462837105028");
                                                            mDates.add(date);
                                                            mAdapter.notifyDataSetChanged();
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError volleyError) {
                                                L.i("download head fail");
                                            }
                                        });
                                        mQueue.add(imageRequest);
                                        break;
                                    default:
                                        break;
                                }
                            } catch (JSONException e) {
                            }
                        }
                    }, new NetConnection.FailCallBack() {
                @Override
                public void onFail() {
                }
            }, Config.KEY_ACTION, Config.ACTION_STUDENT_DETAIL,
                    Config.KEY_TOKEN, Config.getCachedToken(getActivity()),
                    Config.KEY_PHONE, chatting[i]);
        }
//        for (int i = 0; i < 8; i++) {
//            getDate();
//            mAdapter.notifyDataSetChanged();
//        }
    }
    private void getDate() {
        Drawable drawable = getResources().getDrawable(R.drawable.pic_user_example);
        BitmapDrawable bd = (BitmapDrawable) drawable;
        Bitmap head = bd.getBitmap();
        String nickname = "萌鼠喝酸奶";
        String content = "我最近头很疼，怎么办";
        String time = "昨天";
        ChatPreviewData date = new ChatPreviewData(head,"", nickname, content, time);
        mDates.add(date);
    }

}
