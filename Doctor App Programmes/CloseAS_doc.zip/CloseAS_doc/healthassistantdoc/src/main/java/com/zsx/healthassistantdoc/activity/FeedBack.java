package com.zsx.healthassistantdoc.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.zsx.healthassistantdoc.R;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class FeedBack extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private EditText et_feedback;
    private Button btn_commit;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_feedback);
        initView();
    }

    private void initView() {
        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        tv_title = (TextView) findViewById(R.id.tv_title);
        et_feedback = (EditText) findViewById(R.id.et_feedback_content);
        btn_commit = (Button) findViewById(R.id.btn_commit);

        tv_title.setText("意见反馈");
        btn_commit.setClickable(false);
        btn_commit.setBackgroundColor(0xffdddddd);

        btn_commit.setOnClickListener(this);
        et_feedback.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!"".equals(s.toString())) {
                    btn_commit.setClickable(true);
                    btn_commit.setBackgroundResource(R.drawable.btn_login);
                } else {
                    btn_commit.setClickable(false);
                    btn_commit.setBackgroundColor(0xffdddddd);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
