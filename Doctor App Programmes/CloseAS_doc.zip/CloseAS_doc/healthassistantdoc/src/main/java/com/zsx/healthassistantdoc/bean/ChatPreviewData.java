package com.zsx.healthassistantdoc.bean;

import android.graphics.Bitmap;

/**
 * Created by 酸奶 on 2016/4/15.
 */
public class ChatPreviewData {
    private Bitmap head;
    private String id;
    private String nickname;
    private String content;
    private String time;

    public ChatPreviewData(Bitmap head, String id,String nickname, String content, String time) {
        this.head = head;
        this.id = id;
        this.nickname = nickname;
        this.content = content;
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Bitmap getHead() {
        return head;
    }

    public void setHead(Bitmap head) {
        this.head = head;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
