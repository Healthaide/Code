package com.zsx.healthassistantdoc.activity.talk;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.BaseActivityWithBell;
import com.zsx.healthassistantdoc.activity.customView.SelectPicPopupWindow;
import com.zsx.healthassistantdoc.activity.customView.AudioRecorderButton;
import com.zsx.healthassistantdoc.chat.ChatStart;
import com.zsx.healthassistantdoc.chat.XmppTool;
import com.zsx.healthassistantdoc.net.UploadFile;
import com.zsx.healthassistantdoc.tools.BitmapTools;
import com.zsx.healthassistantdoc.tools.L;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Message;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * Created by 酸奶 on 2016/3/26.
 */
public class TalkMain extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";

    public static TalkMain mActivity;

    private Button btn_send;
    private TextView tv_title;
    private TextView tv_judge;
    private ListView mListView;
    private EditText et_input_message;
    private ImageView img_change;
    private ImageView img_pic;
    private AudioRecorderButton btn_recorder;

    private String content_str;
    private List<ListData> lists;//聊天语句对象数组
    private TextAdapter mAdapter;//聊天语句适配器
    private double currentTime;//当前时间
    private double oldTime = 0;//老时间

    private SelectPicPopupWindow menuWindow;

    private ImageView img_head;//头像显示
    private Bitmap picture;//图片Bitmap
    private static String path="/sdcard/HealthMamaDoc/TalkPicture/";//sd路径
    private String img_name = "talkPic.jpg";
    private String chattingTo = "17826833570";
    private String student_id;
    private String student_name;
    private String student_head;
    private Handler mHandler;
    private RequestQueue mQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.talk_main);
        mActivity = this;
        //new Thread(networkTask).start();
        student_id = getIntent().getStringExtra(Config.STUDENT_ID);
        student_name = getIntent().getStringExtra(Config.STUDENT_NAME);
        student_head = getIntent().getStringExtra(Config.STUDENT_HEAD);

        initView();
    }
//    Handler handler = new Handler(){
//        @Override
//        public void handleMessage(Message msg){
//            super.handleMessage(msg);
//            Bundle data = msg.getData();
//            String val = data.getString("value");
//            Log.i("mylog","请求结果为->"+val);
//            //UI界面的更新等相关操作
//        }
//    };
//    /*
//    网络操作相关的子线程
//     */
//    Runnable networkTask = new Runnable() {
//            @Override
//            public void run(){
//                Message msg = new Message();
//                Bundle data = new Bundle();
//                data.putString("value","请求结果");
//                msg.setProperty("value","请求结果");
//                handler.sendMessage(msg);
//            }
//        };


    private void initView() {
        lists = new ArrayList<>();
        mHandler = new Handler();
        mQueue = Volley.newRequestQueue(this);

        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_judge = (TextView) findViewById(R.id.tv_toolbar_other);
        btn_send = (Button) findViewById(R.id.btn_send_message);
        btn_recorder = (AudioRecorderButton) findViewById(R.id.btn_recorder);
        mListView = (ListView) findViewById(R.id.listview_talk);
        img_change = (ImageView) findViewById(R.id.img_change);
        img_pic = (ImageView) findViewById(R.id.img_pic);
        et_input_message = (EditText) findViewById(R.id.et_input_message);

        //隐藏reminder
        ImageView img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        img_reminder.setVisibility(View.GONE);

        if(student_name!=null) {
            L.i("receive:" + student_name);
            tv_title.setText(student_name);
            L.i("title get text:" + tv_title.getText());
        } else{
            tv_title.setText("医生");
        }
        tv_judge.setVisibility(View.GONE);

        //设置listview的适配器
        mAdapter = new TextAdapter(lists, this);
        mListView.setAdapter(mAdapter);
        img_change.setTag("0");

        btn_send.setOnClickListener(this);
        img_change.setOnClickListener(this);
        img_pic.setOnClickListener(this);
        tv_judge.setOnClickListener(this);

        et_input_message.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if ("".equals(s.toString())) {
                    btn_send.setVisibility(View.GONE);
                    img_pic.setVisibility(View.VISIBLE);

                }else {
                    img_pic.setVisibility(View.GONE);
                    btn_send.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        try {
            new ChatStart(Config.getCachedUserid(TalkMain.this),
                    Config.getCachedPassword(TalkMain.this),
                    new ChatStart.MessageCallback() {
                        @Override
                        public void onReceive(final String message, final int type) {
                            L.e("before bean");
                            mHandler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (type == Config.CHAT_MESSAGE) {
                                        ListData listData_receiver = new ListData(message, ListData.RECEIVER, getTime());
                                        lists.add(listData_receiver);
                                        mAdapter.notifyDataSetChanged();
                                    }else if (type == Config.CHAT_IMAGE) {
                                        L.i("except key word :" + message);
                                        ImageRequest imageRequest = new ImageRequest(
                                                message,
                                                new Response.Listener<Bitmap>() {
                                                    @Override
                                                    public void onResponse(Bitmap bitmap) {
                                                        L.i("download head success");
                                                        ListData listData_send = new ListData(bitmap, ListData.RECEIVER, getTime());
                                                        lists.add(listData_send);
                                                        mAdapter.notifyDataSetChanged();
                                                    }
                                                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError volleyError) {
                                                L.i("download head fail");
                                            }
                                        });
                                        mQueue.add(imageRequest);
                                    }else if (type == Config.CHAT_ALL) {
                                        ListData listData_receiver = new ListData(message, ListData.RECEIVER, getTime());
                                        lists.add(listData_receiver);
                                        mAdapter.notifyDataSetChanged();
                                    }
                                }
                            }, 200);
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        XmppTool.closeConnection();

        super.onDestroy();
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_change:
                hiddenKb();
                if (img_change.getTag() == "0") {
                    img_change.setTag("1");
                    img_change.setImageResource(R.drawable.icon_keyboard);
                    et_input_message.setVisibility(View.GONE);
                    btn_recorder.setVisibility(View.VISIBLE);
                }else {
                    img_change.setTag("0");
                    img_change.setImageResource(R.drawable.icon_voice);
                    btn_recorder.setVisibility(View.GONE);
                    et_input_message.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.tv_toolbar_other:
                break;
            case R.id.btn_send_message:
                //获取输入内容
                content_str = et_input_message.getText().toString();
                sendMessage(content_str);
                break;
            case R.id.img_pic:

                hiddenKb();

                setBgAlpha(0.5f);//背景虚化

                menuWindow = new SelectPicPopupWindow(TalkMain.this, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        menuWindow.dismiss();
                        switch (v.getId()) {
                            case R.id.btn_pick_photo://从相册里面取照片
                                setBgAlpha(1.0f);

                                Intent intent1 = new Intent(Intent.ACTION_PICK, null);
                                intent1.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                                startActivityForResult(intent1, 1);
                                break;
                            case R.id.btn_take_photo://调用相机拍照
                                setBgAlpha(1.0f);
                                Intent intent2 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                intent2.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(path,
                                        img_name)));
                                startActivityForResult(intent2, 2);//采用ForResult打开
                                break;
                            default:
                                break;
                        }
                    }
                }, new SelectPicPopupWindow.SetBgAlphaCallBack() {
                    @Override
                    public void setBackgroundAlpha(float alpha) {
                        Log.e(TAG,"重写回调：");
                        TalkMain.this.setBgAlpha(alpha);
                    }
                });
                menuWindow.showAtLocation(TalkMain.this.findViewById(R.id.main), Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,0);//设置layout在PopupWindow中显示的位置

                break;
        }
    }

    private void sendMessage(String content_str) {
        //替换空格
        String dropSpace = content_str.replace(" ","");
        //替换回车
        String dropEnter = dropSpace.replace("\n","");

        if (dropEnter.length() > 0) {
            //清空输入框
            et_input_message.setText("");
            hiddenKb();
            //新建数据，添加数据
            ListData listData_send = new ListData(content_str, ListData.USER, getTime());
            lists.add(listData_send);
            mAdapter.notifyDataSetChanged();

            Chat chat = XmppTool.getConnection().getChatManager()
                    .createChat(student_id+"@bill-think/xx", new MessageListener() {
                        @Override
                        public void processMessage(Chat chat, Message message) {
                            Log.i(TAG, "msg:" + message.toString());
                        }
                    });
            Message message = new Message();
            message.setTo(student_id + "@bill-think/xx");
            message.setType(Message.Type.chat);
            message.setBody(content_str);
            try {
                chat.sendMessage(message);
            } catch (XMPPException e) {
                e.printStackTrace();
            }
        }
    }

    public String getTime() {
        currentTime = System.currentTimeMillis();
        SimpleDateFormat format = new SimpleDateFormat("MM月dd日 HH:mm");
        Date curDate = new Date();
        String str = format.format(curDate);
        //如果超过2分钟
        if (currentTime - oldTime >= 2 * 60 * 1000) {
            oldTime = currentTime;
            return str;
        } else {
            return "";
        }
    }
    private void hiddenKb() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isActive() && getCurrentFocus() != null) {
            if (getCurrentFocus().getWindowToken() != null) {
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            //相册
            case 1:
                if (resultCode == RESULT_OK) {
                    if (data != null) {
                        try {
                            Bitmap picture = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                            //压缩图片
//                            picture = compressImage(picture);
                            picture = BitmapTools.reduce(picture,480,800,true);
                            //保存在SD卡中，以便上传
                            setPicToView(picture);//保存在SD卡中
                            //更新页面数据
                            ListData listData_send = new ListData(picture, ListData.USER, getTime());
                            lists.add(listData_send);
                            mAdapter.notifyDataSetChanged();
                            //发送聊天图片
                            sendChatImg();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
//                    cropPhoto(data.getData());//裁剪图片
                }

                break;
            //相机
            case 2:
                if (resultCode == RESULT_OK) {
                    File temp = new File(path
                            + "/talkPic.jpg");
                    cropPhoto(Uri.fromFile(temp));//裁剪图片
                }

                break;
            case 3:
                if (data != null) {
                    Bundle extras = data.getExtras();
                    picture = extras.getParcelable("data");
                    if(picture!=null){
                        /**
                         * 上传服务器代码
                         */

                        setPicToView(picture);//保存在SD卡中
                        //添加数据
                        ListData listData_send = new ListData(picture, ListData.USER, getTime());
                        lists.add(listData_send);
                        mAdapter.notifyDataSetChanged();
                        //发送聊天图片
                        sendChatImg();

                    }
                }
                break;
            default:
                break;

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void sendChatImg() {
        L.i("before img");
        new UploadFile(new File(path + img_name), Config.URL_UPLOAD_CHAT_IMG, Config.getCachedUserid(TalkMain.this)+Config.JPG,
                new UploadFile.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        L.i("upload chat img success");
                        String url = Config.URL_ADD_KEY_WORD + "@" + Config.URL_HELLOSERVER + "/chat/" + Config.getCachedUserid(TalkMain.this) + Config.JPG;
                        Chat chat = XmppTool.getConnection().getChatManager()
                                .createChat(student_id+"@bill-think/xx", new MessageListener() {
                                    @Override
                                    public void processMessage(Chat chat, Message message) {
                                        Log.i(TAG, "msg:" + message.toString());
                                    }
                                });
                        Message message = new Message();
                        L.i("before message setTo");
                        message.setTo(student_id + "@bill-think/xx");
                        L.i("before message setType");
                        message.setType(Message.Type.headline);
                        L.i("before send");
                        message.setBody(url);
                        L.i("after send:" + message.toXML());
                        try {
                            chat.sendMessage(message);
                        } catch (XMPPException e) {
                            e.printStackTrace();
                        }
                    }
                }, new UploadFile.FailCallBack() {
            @Override
            public void onFail() {
                L.i("upload chat img fail");
            }
        });
    }

    private Bitmap compressImage(Bitmap picture) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        picture.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        int options = 100;
        while (baos.toByteArray().length / 1024 > 150) {
            baos.reset();
            options -= 10;
            picture.compress(Bitmap.CompressFormat.JPEG, options, baos);
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);

        return bitmap;
    }

    ;
    /**
     * 调用系统的裁剪
     * @param uri
     */
    public void cropPhoto(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 150);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 3);
    }
    private void setPicToView(Bitmap mBitmap) {
        String sdStatus = Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // 检测sd是否可用
            return;
        }
        FileOutputStream b = null;
        File file = new File(path);
        file.mkdirs();// 创建文件夹
        String fileName =path + img_name;//图片名字
        try {
            b = new FileOutputStream(fileName);
            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);// 把数据写入文件

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                //关闭流
                b.flush();
                b.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    private void saveChattingHeadImg(Bitmap mBitmap) {
        String sdStatus = Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // 检测sd是否可用
            return;
        }
        FileOutputStream b = null;
        File file = new File(path);
        file.mkdirs();// 创建文件夹
        String fileName =path + img_name;//图片名字
        try {
            b = new FileOutputStream(fileName);
            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);// 把数据写入文件

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                //关闭流
                b.flush();
                b.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    public void setBgAlpha(float bgAlpha){
        Log.e(TAG, "bgAlpha = " + bgAlpha);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.alpha = bgAlpha;
        getWindow().setAttributes(params);
    }

    public void getBitmapFromData(Intent data) {
        Bundle extras = data.getExtras();
        Bitmap bitmap = extras.getParcelable("data");

        if (bitmap != null) {
            Log.i(TAG,"bitmap 获取成功");
            ListData listData_send = new ListData(bitmap, ListData.USER, getTime());
            lists.add(listData_send);
            mAdapter.notifyDataSetChanged();
        } else {
            Log.i(TAG,"bitmap 获取失败");
        }
    }

}
