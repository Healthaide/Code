package com.zsx.healthassistantdoc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.bean.ReminderDate;

import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ReminderAdapter extends BaseAdapter{
    private List<ReminderDate> mDates;
    private RelativeLayout mLayout;
    private Context mContext;

    public ReminderAdapter(List<ReminderDate> dates, Context context) {
        this.mDates = dates;
        this.mContext = context;
    }
    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (RelativeLayout) inflater.inflate(R.layout.inc_reminder, null);

        ((TextView) mLayout.findViewById(R.id.tv_content)).setText(mDates.get(position).getContent());
        ((TextView) mLayout.findViewById(R.id.tv_date)).setText(mDates.get(position).getDate());

        return mLayout;
    }
}
