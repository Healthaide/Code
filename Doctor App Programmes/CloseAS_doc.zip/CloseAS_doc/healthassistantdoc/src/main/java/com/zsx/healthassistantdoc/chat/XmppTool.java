package com.zsx.healthassistantdoc.chat;



import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.tools.L;
import com.zsx.healthassistantdoc.tools.StringTools;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;


public class XmppTool {

	private static XMPPConnection con = null;
	
	private static void openConnection() {
		try {
			//url
			ConnectionConfiguration connConfig = new ConnectionConfiguration(Config.URL_IP, 5222);
			con = new XMPPConnection(connConfig);
			con.connect();
		}
		catch (XMPPException xe)
		{
			xe.printStackTrace();
			L.e("xmppexception:" + xe.toString());
		}
	}

	public static XMPPConnection getConnection() {
		if (con == null) {
			openConnection();
		}
		return con;
	}

	public static void closeConnection() {
		if (con != null) {
			con.disconnect();
		}
		con = null;
	}

	public void login(final String username, final String password) {
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					//登录
					XmppTool.getConnection().login(username, password);

					Presence presence = new Presence(Presence.Type.available);
					Presence.Mode mode = Presence.Mode.valueOf("available");
					presence.setMode(mode);
					presence.setStatus("在线");
					presence.setPriority(0);

					XmppTool.getConnection().sendPacket(presence);

					registerMessageListener(username);
				} catch (XMPPException e) {
					XmppTool.closeConnection();
				}
			}
		});
		t.start();//线程启动
	}
	private void registerMessageListener(final String username) {

		PacketTypeFilter filter = new PacketTypeFilter(Message.class);
		L.i("before");
		PacketListener mPacketListener = new PacketListener() {
			public void processPacket(Packet packet) {
				try {
					if (packet instanceof Message) {// 如果是消息类型
						Message msg = (Message) packet;
						L.i("12:" + msg.toString() + ":" + msg.toXML());

						String chatMessage = msg.getBody();
						String from = StringTools.getRealUsername(msg.getFrom());
						String to = StringTools.getRealUsername(msg.getTo());
						L.i("from:" + from + "to:" + to);

						if (chatMessage == null) {
							L.i("null  return");
							return;// 如果消息为空，直接返回了
						}else if (msg.getType() == Message.Type.error) {
							L.i("error type");
							chatMessage = "<Error> " + chatMessage;// 错误的消息类型
						}else if (to.equals(username)) {
							L.i("message:" + chatMessage);
						}
					}
				} catch (Exception e) {
					L.i("failed to process packet:");
					e.printStackTrace();
				}
			}
		};
		L.i("after");
		XmppTool.getConnection().addPacketListener(mPacketListener, filter);// 这是最关健的了，少了这句，前面的都是白费功夫
	}
}
