package com.zsx.healthassistantdoc.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.customView.RefreshableView;
import com.zsx.healthassistantdoc.activity.customView.refreshView.XListView;
import com.zsx.healthassistantdoc.adapter.ArticleAdapter;
import com.zsx.healthassistantdoc.bean.ArticleDate;
import com.zsx.healthassistantdoc.net.HttpMethod;
import com.zsx.healthassistantdoc.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListArticleLike extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;
    private ArticleAdapter mAdapter;
    private List<ArticleDate> mDates;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_article);
        initView();
        initArticleDate();
    }

    private void initView() {
        mDates = new ArrayList<>();

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("Article Collection");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);

        //设置设配器
        mAdapter = new ArticleAdapter(mDates, this);
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(ListArticleLike.this, ArticleContent.class);

                startActivity(intentToArticle);
            }
        });

        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initArticleDate();
                    }
                },2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initArticleDate();
                    }
                },2000);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("Just");
    }

    public void initArticleDate() {
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                mDates.add(articleDate);
                            }
                            mAdapter.notifyDataSetChanged();
                            onLoad();
                            break;
                        default:
                            Toast.makeText(ListArticleLike.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(ListArticleLike.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(ListArticleLike.this, getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_ARTICLE_LIKE,
                Config.KEY_TOKEN, Config.getCachedToken(ListArticleLike.this));
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
