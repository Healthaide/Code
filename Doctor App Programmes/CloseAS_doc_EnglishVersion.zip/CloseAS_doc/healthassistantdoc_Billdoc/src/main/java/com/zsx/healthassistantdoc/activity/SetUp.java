package com.zsx.healthassistantdoc.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistantdoc.ExitApplication;
import com.zsx.healthassistantdoc.R;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class SetUp extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private RelativeLayout item_notice;
    private RelativeLayout item_modify;
    private RelativeLayout item_mark;
    private RelativeLayout item_update;
    private RelativeLayout item_help;
    private RelativeLayout item_statement;
    private Button btn_exit;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_setup);
        initView();
    }

    private void initView() {
        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        item_notice = (RelativeLayout) findViewById(R.id.item_notice);
        item_modify = (RelativeLayout) findViewById(R.id.item_modify_password);
        item_mark = (RelativeLayout) findViewById(R.id.item_mark);
        item_update = (RelativeLayout) findViewById(R.id.item_update);
        item_help = (RelativeLayout) findViewById(R.id.item_help);
        item_statement = (RelativeLayout) findViewById(R.id.item_statement);

        tv_title = (TextView) findViewById(R.id.tv_title);
        btn_exit = (Button) findViewById(R.id.btn_exit);

        tv_title.setText("Setting and help");

        btn_exit.setOnClickListener(this);
        item_notice.setOnClickListener(this);
        item_modify.setOnClickListener(this);
        item_mark.setOnClickListener(this);
        item_update.setOnClickListener(this);
        item_help.setOnClickListener(this);
        item_statement.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_exit:
                Intent intentToLogin = new Intent(this, Login.class);

                startActivity(intentToLogin);
                ExitApplication.getInstance().exit();
//                try {
//                    ExitApplication.getInstance().exit();
//                    Thread.currentThread().sleep(1000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
                this.finish();
                break;
            case R.id.item_notice:
                Toast.makeText(SetUp.this, "Message Notification", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_modify_password:
                Intent intentToModify = new Intent(SetUp.this, ModifyPass.class);

                startActivity(intentToModify);
                break;
            case R.id.item_mark:
                Toast.makeText(SetUp.this, "Score", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_update:
                Toast.makeText(SetUp.this, "Already the latest", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_help:
                Toast.makeText(SetUp.this, "Help", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_statement:
                Toast.makeText(SetUp.this, "Statement", Toast.LENGTH_SHORT).show();
                break;

        }
    }
}
