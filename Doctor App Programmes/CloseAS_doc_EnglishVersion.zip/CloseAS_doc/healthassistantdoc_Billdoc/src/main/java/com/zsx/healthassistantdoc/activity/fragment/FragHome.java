package com.zsx.healthassistantdoc.activity.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.ArticleContent;
import com.zsx.healthassistantdoc.activity.SearchView;
import com.zsx.healthassistantdoc.adapter.ArticleAdapter;
import com.zsx.healthassistantdoc.bean.ArticleDate;
import com.zsx.healthassistantdoc.net.HttpMethod;
import com.zsx.healthassistantdoc.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class FragHome extends Fragment implements View.OnClickListener{
    private String TAG = "ZSX";
    private View rootView;

    private ListView listview_last;
    private ListView listview_hot;
    private EditText et_search;
    private ArticleAdapter adapter_last;
    private ArticleAdapter adapter_hot;
    private List<ArticleDate> dates_last;
    private List<ArticleDate> dates_hot;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.i(TAG, "");
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.frag_home, null);
            Log.i(TAG,"FragFind:new");
        }
        //缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootView已经有parent的错误
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null) {
            parent.removeView(rootView);
            Log.i(TAG,"FragFind:remove");
        }
        initView(rootView);

        return rootView;
    }

    private void initView(View view) {
        dates_last = new ArrayList<>();
        dates_hot = new ArrayList<>();

        et_search = (EditText) view.findViewById(R.id.et_search_input);
        listview_last = (ListView) view.findViewById(R.id.listview_article_last);
        listview_hot = (ListView) view.findViewById(R.id.listview_article_hot);
//设置设配器
        adapter_last = new ArticleAdapter(dates_last, getContext());
        adapter_hot = new ArticleAdapter(dates_hot, getContext());

        listview_last.setAdapter(adapter_last);
        listview_hot.setAdapter(adapter_hot);
        et_search.setOnClickListener(this);

        initArticleDate();

        listview_last.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(getActivity(), ArticleContent.class);

                intentToArticle.putExtra(Config.ARTICLE_ID,dates_last.get(position).getKey());
                startActivity(intentToArticle);
            }
        });
        listview_hot.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(getActivity(), ArticleContent.class);

                intentToArticle.putExtra(Config.ARTICLE_ID, dates_hot.get(position).getKey());
                startActivity(intentToArticle);
            }
        });
    }


    public void initArticleDate() {

        //想服务器请求获取最新文章数据
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    Log.i(TAG, "result json:" + result);
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < 3; i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                Log.i(TAG, "no" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                dates_last.add(articleDate);
                            }
                            adapter_last.notifyDataSetChanged();
                            setListViewHeightBasedOnChildren(listview_last);
                            break;
                        default:
                            Log.i(TAG, "status error");
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(getActivity(), "Network connection failed, please check the network", Toast.LENGTH_SHORT).show();
            }
        },Config.KEY_ACTION,Config.ACTION_LAST_ARTICLE_3,
                Config.KEY_TOKEN, Config.getCachedToken(getActivity()));

        //向服务器请求获取最热文章数据
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < 3; i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                dates_hot.add(articleDate);
                            }
                            adapter_hot.notifyDataSetChanged();
                            setListViewHeightBasedOnChildren(listview_hot);
                            break;
                        default:
                            Toast.makeText(getActivity(), getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(getActivity(), getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(getActivity(), getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_HOT_ARTICLE_3,
                Config.KEY_TOKEN, Config.getCachedToken(getActivity()));
    }

    //根据当前的ListView的列表项计算列表的尺寸,
    // 解决ScrollView嵌套ListView时，会无法正确的计算ListView的大小
    public void setListViewHeightBasedOnChildren(ListView listView) {
        /**
         * by zsx
         * 获取ListView对应的Adapter
         * 这里的adapter是你为listview所添加的adapter，可以是原始adapter，
         * 也可以是自己定义的adapter，本人这里的articleadpter是自己定义的adapter
         */
        ArticleAdapter listAdapter = (ArticleAdapter) listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.et_search_input:
                Intent intentToSearch = new Intent(getActivity(), SearchView.class);

                startActivity(intentToSearch);
                break;
        }
    }
}
