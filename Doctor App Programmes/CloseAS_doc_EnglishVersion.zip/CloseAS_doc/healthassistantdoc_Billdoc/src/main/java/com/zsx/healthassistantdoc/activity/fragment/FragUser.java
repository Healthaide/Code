package com.zsx.healthassistantdoc.activity.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.FeedBack;
import com.zsx.healthassistantdoc.activity.InfoPerson;
import com.zsx.healthassistantdoc.activity.ListArticleLike;
import com.zsx.healthassistantdoc.activity.SetUp;
import com.zsx.healthassistantdoc.adapter.ChatPreviewAdapter;
import com.zsx.healthassistantdoc.bean.ChatPreviewData;
import com.zsx.healthassistantdoc.tools.BitmapTools;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class FragUser extends Fragment implements View.OnClickListener{
    private String TAG = "ZSX";
    private View rootView;

    private ImageView img_head;
    private TextView tv_name;

    private RelativeLayout item_article;
    private RelativeLayout item_setup;
    private RelativeLayout item_feedback;

    private RequestQueue mQueue;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (rootView == null) {
            rootView = inflater.inflate(R.layout.frag_user, null);
            Log.i(TAG,"FragUser:new");
        }
        //缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootView已经有parent的错误
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null) {
            parent.removeView(rootView);
            Log.i(TAG,"FragUser:remove");
        }

        initView(rootView);

        return rootView;
    }

    private void initView(View view) {
        mQueue = Volley.newRequestQueue(getActivity());

        img_head = (ImageView) view.findViewById(R.id.img_head);
        tv_name = (TextView) view.findViewById(R.id.tv_name);
        item_article = (RelativeLayout) view.findViewById(R.id.item_to_article);
        item_setup = (RelativeLayout) view.findViewById(R.id.item_setup);
        item_feedback = (RelativeLayout) view.findViewById(R.id.item_feedback);

        tv_name.setText(Config.getCachedName(getActivity())+"doctor");
        initHead();
        img_head.setOnClickListener(this);
        tv_name.setOnClickListener(this);
        item_article.setOnClickListener(this);
        item_setup.setOnClickListener(this);
        item_feedback.setOnClickListener(this);
    }

    public void initHead() {
        Bitmap bt = BitmapFactory.decodeFile(Config.PATH_HEAD + "head.jpg");//从ad中找头像，转化成Bitmap
        if(bt!=null){
            Drawable drawable = new BitmapDrawable(bt);//转换成drawable
            img_head.setImageDrawable(drawable);
        }else {
            ImageRequest imageRequest = new ImageRequest(
                    Config.getCachedHead(getActivity()),
                    new Response.Listener<Bitmap>() {
                        @Override
                        public void onResponse(Bitmap bitmap) {
                            BitmapTools.saveHeadImg(bitmap);
                            img_head.setImageBitmap(bitmap);
                        }
                    }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Log.i(TAG, "fail");
                    img_head.setImageBitmap(BitmapTools.getBitmap(getActivity(), R.drawable.pic_user_head_empty));
                }
            });
            mQueue.add(imageRequest);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_head:
            case R.id.tv_name:
                Intent intentToInfoDoc = new Intent(getActivity(), InfoPerson.class);

                startActivity(intentToInfoDoc);
                break;
            case R.id.item_to_article:
                Intent intentToArticle = new Intent(getActivity(), ListArticleLike.class);

                startActivity(intentToArticle);
                break;
            case R.id.item_setup:
                Intent intentToSetUP = new Intent(getActivity(), SetUp.class);

                startActivity(intentToSetUP);
                break;
            case R.id.item_feedback:
                Intent intentToFeedback = new Intent(getActivity(), FeedBack.class);

                startActivity(intentToFeedback);
                break;
        }
    }


}
