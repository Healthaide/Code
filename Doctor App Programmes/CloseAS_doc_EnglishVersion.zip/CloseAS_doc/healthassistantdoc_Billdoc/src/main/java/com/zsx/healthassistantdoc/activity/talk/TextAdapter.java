package com.zsx.healthassistantdoc.activity.talk;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.ImageDetail;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Created by 酸奶 on 2016/2/29.
 */
public class TextAdapter extends BaseAdapter {
    private List<ListData> lists;
    private Context mContext;
    private RelativeLayout mLayout;
    private TextView textView;
    private TextView time;
    private ImageView imageView;
    private Bitmap bitmap;

    private int flag;//1代表文字，2代表图片，3代表语音

    public TextAdapter(List<ListData> lists, Context mContext) {
        this.lists = lists;
        this.mContext = mContext;
        this.flag = 1;
    }
    public TextAdapter(Bitmap bitmap,Context mContext) {
        this.bitmap = bitmap;
        this.mContext = mContext;
        this.flag = 2;
    }

    @Override
    public int getCount() {
        return lists.size();
    }

    @Override
    public Object getItem(int position) {
        return lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(mContext);

        if (lists.get(position).getFlag() == ListData.RECEIVER) {
            mLayout = (RelativeLayout) inflater.inflate(R.layout.talk_left_item, null);
        }
        if (lists.get(position).getFlag() == ListData.USER) {
            mLayout = (RelativeLayout) inflater.inflate(R.layout.talk_right_item, null);
            Bitmap bt = BitmapFactory.decodeFile(Config.PATH_HEAD + Config.NAME_HEAD);//从ad中找头像，转化成Bitmap
            if(bt!=null) {
                Drawable drawable = new BitmapDrawable(bt);//转换成drawable
                ((ImageView)mLayout.findViewById(R.id.img_head)).setImageDrawable(drawable);
            }
        }

        if (lists.get(position).getClassify() == 1) {

            imageView = (ImageView) mLayout.findViewById(R.id.img_picture);
            textView = (TextView) mLayout.findViewById(R.id.tv_text);
            time = (TextView) mLayout.findViewById(R.id.tv_time);

            imageView.setVisibility(View.GONE);
            textView.setVisibility(View.VISIBLE);

            textView.setText(lists.get(position).getContent());
            if (lists.get(position).getTime() == "") {
                time.setVisibility(View.GONE);
            }else {
                time.setVisibility(View.VISIBLE);
                time.setText(lists.get(position).getTime());
            }

        }else if (lists.get(position).getClassify() == 2) {


            imageView = (ImageView) mLayout.findViewById(R.id.img_picture);
            textView = (TextView) mLayout.findViewById(R.id.tv_text);
            time = (TextView) mLayout.findViewById(R.id.tv_time);

            imageView.setVisibility(View.VISIBLE);
            textView.setVisibility(View.GONE);
            time.setVisibility(View.GONE);

            imageView.setImageBitmap(lists.get(position).getBitmap());
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    toImgDetail(imageView, lists.get(position).getBitmap());
                }
            });
        }
        return mLayout;
    }

    private void toImgDetail(ImageView imageView,Bitmap bitmap) {

        Intent intent = new Intent(TalkMain.mActivity, ImageDetail.class);
        int[] location = new int[2];

//        //获取bitmap
//        BitmapDrawable bd = (BitmapDrawable) imageView.getDrawable();
//        bitmap = bd.getBitmap();
        //把bitmap存储为byte数组
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] bitmapByte = baos.toByteArray();

        intent.putExtra("bitmap", bitmapByte);
        imageView.getLocationOnScreen(location);
        intent.putExtra("locationX", location[0]);
        intent.putExtra("locationY", location[1]);

        intent.putExtra("width", imageView.getWidth());
        intent.putExtra("height", imageView.getHeight());

        TalkMain.mActivity.startActivity(intent);

        TalkMain.mActivity.overridePendingTransition(0, 0);
    }
}
