package com.zsx.healthassistantdoc.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class InfoPerson extends BaseActivityWithBell{
    private String TAG = "zsx";
    private TextView tv_title;

    private TextView tv_name;
    private TextView tv_userid;
    private TextView tv_sex;
    private TextView tv_area;
    private TextView tv_hospital;
    private TextView tv_department;
    private TextView tv_position;

    private ImageView img_head;//头像显示
    private Bitmap head;//头像Bitmap
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_doctor);
        initView();
    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_name = (TextView) findViewById(R.id.tv_name);
        tv_userid = (TextView) findViewById(R.id.tv_userid);
        tv_sex = (TextView) findViewById(R.id.tv_sex);
        tv_area = (TextView) findViewById(R.id.tv_info_area);
        tv_hospital = (TextView) findViewById(R.id.tv_hospital);
        tv_department = (TextView) findViewById(R.id.tv_department);
        tv_position = (TextView) findViewById(R.id.tv_position);
        img_head = (ImageView) findViewById(R.id.img_head);

        tv_title.setText("Personal Information");

        initInfo();

    }

    private void initInfo() {
        //设置头像
        Bitmap bt = BitmapFactory.decodeFile(Config.PATH_HEAD+"head.jpg");//从ad中找头像，转化成Bitmap
        if(bt!=null){
            @SuppressWarnings("deprecation")
            Drawable drawable = new BitmapDrawable(bt);//转换成drawable
            img_head.setImageDrawable(drawable);
        }else{
            /**
             *	如果SD里面没有则需要从服务器取头像，取回来的头像再保存在SD中
             *
             */
        }
        //设置nickname
        if (Config.getCachedName(this) == null) {
            tv_name.setText("Set Nickname");
        } else {
            tv_name.setText(Config.getCachedName(this));
        }
        //设置userid
        if (Config.getCachedUserid(this) == null) {
            tv_userid.setText("Empty");
        } else {
            tv_userid.setText(Config.getCachedUserid(this));
        }
        //设置sex
        if (Config.getCachedSex(this) == null) {
            tv_sex.setText("Empty");
        } else {
            tv_sex.setText(Config.getCachedSex(this));
        }
        //设置area
        if (Config.getCachedArea(this) == null) {
            tv_area.setText("Empty");
        } else {
            tv_area.setText(Config.getCachedArea(this));
        }
        //设置hospital
        if (Config.getCachedHospital(this) == null) {
            tv_hospital.setText("Empty");
        } else {
            tv_hospital.setText(Config.getCachedHospital(this));
        }
        //设置department
        if (Config.getCachedDepartment(this) == null) {
            tv_department.setText("Empty");
        } else {
            tv_department.setText(Config.getCachedDepartment(this));
        }
        //设置position
        if (Config.getCachedPosition(this) == null) {
            tv_position.setText("Empty");
        } else {
            tv_position.setText(Config.getCachedPosition(this));
        }
    }



}
