package com.zsx.healthassistantdoc.activity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistantdoc.Config;
import com.zsx.healthassistantdoc.R;
import com.zsx.healthassistantdoc.activity.customView.RefreshableView;
import com.zsx.healthassistantdoc.activity.customView.refreshView.XListView;
import com.zsx.healthassistantdoc.adapter.ConmentAdapter;
import com.zsx.healthassistantdoc.bean.ConmentDate;
import com.zsx.healthassistantdoc.net.HttpMethod;
import com.zsx.healthassistantdoc.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListConment extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private String articleId;

    private ConmentAdapter mAdapter;
    private List<ConmentDate> mDates;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_article);

        articleId = getIntent().getStringExtra("id");
        initView();
        initCommentDate();
    }

    private void initView() {
        mDates = new ArrayList<>();

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("Comment List");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);


        //设置设配器
        mAdapter = new ConmentAdapter(mDates, this);
        mListView.setAdapter(mAdapter);

        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initCommentDate();
                    }
                },2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initCommentDate();
                    }
                },2000);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("Just");
    }
    public void initCommentDate() {
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                ConmentDate conmentDate = new ConmentDate(
                                        null,
                                        body.getString(Config.KEY_PHONE).toString(),
                                        body.getString(Config.KEY_CONTENT),
                                        body.getString(Config.KEY_DATE));
                                mDates.add(conmentDate);
                            }
                            mAdapter.notifyDataSetChanged();
                            onLoad();
                            break;
                        default:
                            Log.i("ZSX", "status error");
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(ListConment.this, "netconnection failed", Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_COMMENT_GET_DOC,
                Config.KEY_TOKEN, Config.getCachedToken(ListConment.this),
                Config.KEY_ID, articleId);

    }

    public void initConmentDate() {
        for (int i = 0; i < 6;i++){
            getDate();
            mAdapter.notifyDataSetChanged();
        }
    }
    public void getDate() {
        Drawable drawable = getResources().getDrawable(R.drawable.pic_user_example);
        BitmapDrawable bd = (BitmapDrawable) drawable;
        Bitmap head = bd.getBitmap();
        String userid = "17826833449";
        String content = getString(R.string.conment_example);
        String time = "10";
        ConmentDate articleDate = new ConmentDate(head,userid, content, time);
        mDates.add(articleDate);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
