package com.zsx.healthassistantdoc.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistantdoc.R;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class ComplaintArticle extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_title;
    private TextView tv_commint;
    private EditText et_judge_content;
    private ImageView img_toolbar_reminder;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_quick_ask);
        initView();
    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_commint = (TextView) findViewById(R.id.tv_toolbar_other);
        et_judge_content = (EditText) findViewById(R.id.et_content);
        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);

        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("Complaint");
        tv_commint.setText("Submission");
        et_judge_content.setHint("Please give a detailed account of the reasons for this article.");
        tv_commint.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_toolbar_other:
                Toast.makeText(this, "Submission Successfully", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}
