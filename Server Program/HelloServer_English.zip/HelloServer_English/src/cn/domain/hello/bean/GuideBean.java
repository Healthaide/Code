package cn.domain.hello.bean;

public class GuideBean
{
	private String name;
	private String time;
	private String fre;
	private String pre;
	private String pro;
	private String sta;

	public GuideBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public GuideBean(String name, String time, String fre, String pre,
			String pro, String sta)
	{
		super();
		this.name = name;
		this.time = time;
		this.fre = fre;
		this.pre = pre;
		this.pro = pro;
		this.sta = sta;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getTime()
	{
		return time;
	}

	public void setTime(String time)
	{
		this.time = time;
	}

	public String getFre()
	{
		return fre;
	}

	public void setFre(String fre)
	{
		this.fre = fre;
	}

	public String getPre()
	{
		return pre;
	}

	public void setPre(String pre)
	{
		this.pre = pre;
	}

	public String getPro()
	{
		return pro;
	}

	public void setPro(String pro)
	{
		this.pro = pro;
	}

	public String getSta()
	{
		return sta;
	}

	public void setSta(String sta)
	{
		this.sta = sta;
	}

}
