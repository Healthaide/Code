package cn.domain.hello.bean;

public class ArticleCollectionBean
{
	private String phone;
	private int id;
	public ArticleCollectionBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public ArticleCollectionBean(String phone, int id)
	{
		super();
		this.phone = phone;
		this.id = id;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	

	

}
