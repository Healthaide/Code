package cn.domain.hello.bean;

public class DepdisBean
{
	private int s_id;
	private int s_disid;
	public DepdisBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public DepdisBean(int s_id, int s_disid)
	{
		super();
		this.s_id = s_id;
		this.s_disid = s_disid;
	}
	public int getS_id()
	{
		return s_id;
	}
	public void setS_id(int s_id)
	{
		this.s_id = s_id;
	}
	public int getS_disid()
	{
		return s_disid;
	}
	public void setS_disid(int s_disid)
	{
		this.s_disid = s_disid;
	}

	
}
