package cn.domain.hello.bean;

public class TopicBean
{
	private int id;
	private String head;
	private String title;
	private String content;
	private String time;
	public TopicBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public TopicBean(int id, String head, String title, String content,
			String time)
	{
		super();
		this.id = id;
		this.head = head;
		this.title = title;
		this.content = content;
		this.time = time;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getHead()
	{
		return head;
	}
	public void setHead(String head)
	{
		this.head = head;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public String getTime()
	{
		return time;
	}
	public void setTime(String time)
	{
		this.time = time;
	}
	
}
