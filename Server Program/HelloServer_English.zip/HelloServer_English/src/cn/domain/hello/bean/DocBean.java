package cn.domain.hello.bean;

public class DocBean
{

	private String phone;
	private String password;
	private String head;
	private String name;
	private String hospital;
	private String department;
	private String position;
	private String sex;
	private String area;
	private String token;
	public DocBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public DocBean(String phone, String password, String head, String name,
			String hospital, String department, String position, String sex,
			String area, String token)
	{
		super();
		this.phone = phone;
		this.password = password;
		this.head = head;
		this.name = name;
		this.hospital = hospital;
		this.department = department;
		this.position = position;
		this.sex = sex;
		this.area = area;
		this.token = token;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}
	public String getHead()
	{
		return head;
	}
	public void setHead(String head)
	{
		this.head = head;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getHospital()
	{
		return hospital;
	}
	public void setHospital(String hospital)
	{
		this.hospital = hospital;
	}
	public String getDepartment()
	{
		return department;
	}
	public void setDepartment(String department)
	{
		this.department = department;
	}
	public String getPosition()
	{
		return position;
	}
	public void setPosition(String position)
	{
		this.position = position;
	}
	public String getSex()
	{
		return sex;
	}
	public void setSex(String sex)
	{
		this.sex = sex;
	}
	public String getArea()
	{
		return area;
	}
	public void setArea(String area)
	{
		this.area = area;
	}
	public String getToken()
	{
		return token;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	
	
}
