package cn.domain.hello.bean;

public class DisartiBean
{
	private int s_disid;
	private int s_aid;
	public DisartiBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public DisartiBean(int s_disid, int s_aid)
	{
		super();
		this.s_disid = s_disid;
		this.s_aid = s_aid;
	}
	public int getS_disid()
	{
		return s_disid;
	}
	public void setS_disid(int s_disid)
	{
		this.s_disid = s_disid;
	}
	public int getS_aid()
	{
		return s_aid;
	}
	public void setS_aid(int s_aid)
	{
		this.s_aid = s_aid;
	}

	
}
