package cn.domain.hello.bean;

public class DiseaseBean
{
	private int id;
	private String name;
	private String intro;
	private String part;
	private String cause;
	private String prevent;
	private String nurse;
	private int click;

	public DiseaseBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public DiseaseBean(int id, String name, String intro, String part,
			String cause, String prevent, String nurse, int click)
	{
		super();
		this.id = id;
		this.name = name;
		this.intro = intro;
		this.part = part;
		this.cause = cause;
		this.prevent = prevent;
		this.nurse = nurse;
		this.click = click;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getIntro()
	{
		return intro;
	}

	public void setIntro(String intro)
	{
		this.intro = intro;
	}

	public String getPart()
	{
		return part;
	}

	public void setPart(String part)
	{
		this.part = part;
	}

	public String getCause()
	{
		return cause;
	}

	public void setCause(String cause)
	{
		this.cause = cause;
	}

	public String getPrevent()
	{
		return prevent;
	}

	public void setPrevent(String prevent)
	{
		this.prevent = prevent;
	}

	public String getNurse()
	{
		return nurse;
	}

	public void setNurse(String nurse)
	{
		this.nurse = nurse;
	}

	public int getClick()
	{
		return click;
	}

	public void setClick(int click)
	{
		this.click = click;
	}

}
