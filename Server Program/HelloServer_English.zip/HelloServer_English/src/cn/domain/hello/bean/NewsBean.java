package cn.domain.hello.bean;

public class NewsBean {
     private String phone;
     private String url;
	public NewsBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NewsBean(String phone, String url) {
		super();
		this.phone = phone;
		this.url = url;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
     
}
