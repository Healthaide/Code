package cn.domain.hello.bean;

public class CardBean {
	private int id;
	private String head;
	private String nickname;
	private String title;
	private String content;
	private String date;
	private int floor;
	private int click;
	public CardBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CardBean(int id, String head, String nickname, String title,
			String content, String date, int floor, int click) {
		super();
		this.id = id;
		this.head = head;
		this.nickname = nickname;
		this.title = title;
		this.content = content;
		this.date = date;
		this.floor = floor;
		this.click = click;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHead() {
		return head;
	}
	public void setHead(String head) {
		this.head = head;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public int getClick() {
		return click;
	}
	public void setClick(int click) {
		this.click = click;
	}
		
}
