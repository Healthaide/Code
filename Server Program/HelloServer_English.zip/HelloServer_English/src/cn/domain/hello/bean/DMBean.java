package cn.domain.hello.bean;

public class DMBean
{
	private String city;
	private String name;
	private String sexd;
	private String sexa;
	private String allergen;
	public DMBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public DMBean(String city, String name, String sexd, String sexa,
			String allergen)
	{
		super();
		this.city = city;
		this.name = name;
		this.sexd = sexd;
		this.sexa = sexa;
		this.allergen = allergen;
	}
	public String getCity()
	{
		return city;
	}
	public void setCity(String city)
	{
		this.city = city;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getSexd()
	{
		return sexd;
	}
	public void setSexd(String sexd)
	{
		this.sexd = sexd;
	}
	public String getSexa()
	{
		return sexa;
	}
	public void setSexa(String sexa)
	{
		this.sexa = sexa;
	}
	public String getAllergen()
	{
		return allergen;
	}
	public void setAllergen(String allergen)
	{
		this.allergen = allergen;
	}
	
}
