package cn.domain.hello.bean;

public class DepartiBean
{
	private int s_depid;
	private int s_aid;

	public DepartiBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartiBean(int s_depid, int s_aid)
	{
		super();
		this.s_depid = s_depid;
		this.s_aid = s_aid;
	}

	public int getS_depid()
	{
		return s_depid;
	}

	public void setS_depid(int s_depid)
	{
		this.s_depid = s_depid;
	}

	public int getS_aid()
	{
		return s_aid;
	}

	public void setS_aid(int s_aid)
	{
		this.s_aid = s_aid;
	}

}
