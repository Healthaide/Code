package cn.domain.hello.bean;

public class SymartiBean
{
	private int s_sid;
	private int s_aid;

	public SymartiBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public SymartiBean(int s_sid, int s_aid)
	{
		super();
		this.s_sid = s_sid;
		this.s_aid = s_aid;
	}

	public int getS_sid()
	{
		return s_sid;
	}

	public void setS_sid(int s_sid)
	{
		this.s_sid = s_sid;
	}

	public int getS_aid()
	{
		return s_aid;
	}

	public void setS_aid(int s_aid)
	{
		this.s_aid = s_aid;
	}

}
