package cn.domain.hello.bean;

/**
 * @author 包启明
 * 
 */
public class RegistBean
{

	private String phone;
	private String password;
	private String nickname;
	private String sex;
	private String area;
	private String intro;
	private String head;
	private String code;
	public RegistBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RegistBean(String phone, String password, String nickname,
			String sex, String area, String intro, String head, String code) {
		super();
		this.phone = phone;
		this.password = password;
		this.nickname = nickname;
		this.sex = sex;
		this.area = area;
		this.intro = intro;
		this.head = head;
		this.code = code;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getHead() {
		return head;
	}
	public void setHead(String head) {
		this.head = head;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
	

}
