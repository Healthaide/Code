package cn.domain.hello.bean;

public class List_articleBean
{
	private String title;
	private String kind;
	private int browse;
	private int id;
	private String token;
	private String date;

	public List_articleBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public List_articleBean(String title, String kind, int browse, int id,
			String token, String date)
	{
		super();
		this.title = title;
		this.kind = kind;
		this.browse = browse;
		this.id = id;
		this.token = token;
		this.date = date;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public int getBrowse()
	{
		return browse;
	}

	public void setBrowse(int browse)
	{
		this.browse = browse;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getToken()
	{
		return token;
	}

	public void setToken(String token)
	{
		this.token = token;
	}

	public String getDate()
	{
		return date;
	}

	public void setDate(String date)
	{
		this.date = date;
	}

}
