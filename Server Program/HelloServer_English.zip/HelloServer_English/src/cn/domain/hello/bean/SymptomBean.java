package cn.domain.hello.bean;

public class SymptomBean
{
	private int symid;
	private String name;

	public SymptomBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public SymptomBean(int symid, String name)
	{
		super();
		this.symid = symid;
		this.name = name;
	}

	public int getSymid()
	{
		return symid;
	}

	public void setSymid(int symid)
	{
		this.symid = symid;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

}
