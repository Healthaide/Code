package cn.domain.hello.bean;

public class JudgeBean
{

	private String phone;
	private String content;
	private String date;
	private String token;
	public JudgeBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public JudgeBean(String phone, String content, String date, String token)
	{
		super();
		this.phone = phone;
		this.content = content;
		this.date = date;
		this.token = token;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}
	public String getToken()
	{
		return token;
	}
	public void setToken(String token)
	{
		this.token = token;
	}

	

}
