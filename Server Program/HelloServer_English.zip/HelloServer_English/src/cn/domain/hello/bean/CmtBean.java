package cn.domain.hello.bean;

public class CmtBean
{
	private String content;
	private String date;
	private String token;
	public CmtBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public CmtBean(String content, String date, String token)
	{
		super();
		this.content = content;
		this.date = date;
		this.token = token;
	}
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}
	public String getToken()
	{
		return token;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	
}
