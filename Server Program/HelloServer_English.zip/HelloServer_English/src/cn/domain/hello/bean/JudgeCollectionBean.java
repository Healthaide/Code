package cn.domain.hello.bean;

public class JudgeCollectionBean
{
	private String phone;
	private String token;
	public JudgeCollectionBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public JudgeCollectionBean(String phone, String token)
	{
		super();
		this.phone = phone;
		this.token = token;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getToken()
	{
		return token;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	
}
