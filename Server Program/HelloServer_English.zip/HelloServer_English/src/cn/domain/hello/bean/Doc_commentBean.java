package cn.domain.hello.bean;

public class Doc_commentBean
{
	private String phone;
	private String content;
	private String time;
	private String token;
	public Doc_commentBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Doc_commentBean(String phone, String content, String time,
			String token)
	{
		super();
		this.phone = phone;
		this.content = content;
		this.time = time;
		this.token = token;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public String getTime()
	{
		return time;
	}
	public void setTime(String time)
	{
		this.time = time;
	}
	public String getToken()
	{
		return token;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	
	
}
