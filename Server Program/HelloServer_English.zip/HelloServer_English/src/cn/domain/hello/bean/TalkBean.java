package cn.domain.hello.bean;

public class TalkBean
{
	private String username;
	private String nickname;
	private String time;
	private String content;
	private String head;

	public TalkBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public TalkBean(String username, String nickname, String time,
			String content, String head)
	{
		super();
		this.username = username;
		this.nickname = nickname;
		this.time = time;
		this.content = content;
		this.head = head;
	}

	public String getUsername()
	{
		return username;
	}

	public void setUsername(String username)
	{
		this.username = username;
	}

	public String getNickname()
	{
		return nickname;
	}

	public void setNickname(String nickname)
	{
		this.nickname = nickname;
	}

	public String getTime()
	{
		return time;
	}

	public void setTime(String time)
	{
		this.time = time;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getHead()
	{
		return head;
	}

	public void setHead(String head)
	{
		this.head = head;
	}

}
