package cn.domain.hello.bean;

public class Get_codeBean
{
	private String phone;
	private String code;
	private String token;

	public Get_codeBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public Get_codeBean(String phone, String code, String token)
	{
		super();
		this.phone = phone;
		this.code = code;
		this.token = token;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getToken()
	{
		return token;
	}

	public void setToken(String token)
	{
		this.token = token;
	}

}
