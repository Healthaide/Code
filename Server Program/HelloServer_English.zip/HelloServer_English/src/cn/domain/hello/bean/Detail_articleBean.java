package cn.domain.hello.bean;

public class Detail_articleBean
{
	private String title;
	private String date;
	private String source;
	private String kind;
	private String article;
	private String comment;
	private String token;
	private int id;

	public Detail_articleBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public Detail_articleBean(String title, String date, String source,
			String kind, String article, String comment, String token, int id)
	{
		super();
		this.title = title;
		this.date = date;
		this.source = source;
		this.kind = kind;
		this.article = article;
		this.comment = comment;
		this.token = token;
		this.id = id;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getDate()
	{
		return date;
	}

	public void setDate(String date)
	{
		this.date = date;
	}

	public String getSource()
	{
		return source;
	}

	public void setSource(String source)
	{
		this.source = source;
	}

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public String getArticle()
	{
		return article;
	}

	public void setArticle(String article)
	{
		this.article = article;
	}

	public String getComment()
	{
		return comment;
	}

	public void setComment(String comment)
	{
		this.comment = comment;
	}

	public String getToken()
	{
		return token;
	}

	public void setToken(String token)
	{
		this.token = token;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

}
