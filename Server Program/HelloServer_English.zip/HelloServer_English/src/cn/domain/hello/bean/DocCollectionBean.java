package cn.domain.hello.bean;

public class DocCollectionBean
{
	private String token;
	private String phone;
	public DocCollectionBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public DocCollectionBean(String token, String phone)
	{
		super();
		this.token = token;
		this.phone = phone;
	}
	public String getToken()
	{
		return token;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	
}
