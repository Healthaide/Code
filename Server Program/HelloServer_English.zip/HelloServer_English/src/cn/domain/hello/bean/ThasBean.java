package cn.domain.hello.bean;

public class ThasBean
{
	private int s_id;
	private int id;
	public ThasBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public ThasBean(int s_id, int id)
	{
		super();
		this.s_id = s_id;
		this.id = id;
	}
	public int getS_id()
	{
		return s_id;
	}
	public void setS_id(int s_id)
	{
		this.s_id = s_id;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	
}
