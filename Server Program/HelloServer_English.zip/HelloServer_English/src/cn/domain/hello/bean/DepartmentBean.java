package cn.domain.hello.bean;

public class DepartmentBean
{
	private int depid;
	private String name;

	public DepartmentBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartmentBean(int depid, String name)
	{
		super();
		this.depid = depid;
		this.name = name;
	}

	public int getDepid()
	{
		return depid;
	}

	public void setDepid(int depid)
	{
		this.depid = depid;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

}
