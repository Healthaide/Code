
package cn.domain.hello.domain;

import java.util.*;

public class ReadPost {
	private List list;

	public ReadPost() {
		super();
	}

	public ReadPost(List list) {
		super();
		this.list = list;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
}
