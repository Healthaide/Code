package cn.domain.hello.domain;

import java.util.*;

public class WritePost {
	private List list;

	public WritePost() {
		super();
	}

	public WritePost(List list) {
		super();
		this.list = list;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
}
