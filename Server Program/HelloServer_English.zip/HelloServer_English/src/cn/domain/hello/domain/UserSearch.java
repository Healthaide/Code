package cn.domain.hello.domain;

import java.util.*;

public class UserSearch {
	private List<Integer> list;

	public UserSearch() {
		super();
	}

	public UserSearch(List list) {
		super();
		this.list = list;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
}
