package cn.domain.hello.domain;

import java.util.*;

import cn.domain.hello.tool.Dir;

public class ViewList {
	private List<Dir> list;

	public ViewList() {
		super();
	}

	public ViewList(List list) {
		super();
		this.list = list;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
}
