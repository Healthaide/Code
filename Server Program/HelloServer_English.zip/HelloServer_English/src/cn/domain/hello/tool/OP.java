package cn.domain.hello.tool;

public class OP {
	private int id;
	private String title;
	private String date;
	private int userid;
	private String content;

	public OP() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OP( String name, String content, int userid) {
		super();
		this.title = name;
		this.content = content;
		this.userid = userid;
	}

	public int getID() {
		return id;
	}

	public void setID(int ID) {
		this.id = ID;
	}

	public String getName() {
		return title;
	}

	public void setName(String name) {
		this.title = name;
	}
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
	public String getContent() {
		return content;
	}

	public void setContent(String data) {
		this.content = data;
	}
}
