package cn.domain.hello.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import cn.domain.hello.bean.ArticleBean;
import cn.domain.hello.dao.KeyService;
import cn.domain.hello.dao.SearchArticleDao;

public class UserSearchServlet extends HttpServlet {
	private static SearchArticleDao sad = new SearchArticleDao();
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private KeyService keyService = new KeyService();

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		// String token = request.getParameter("token");
		// String id = request.getParameter("id");
		// System.out.println(token);
		// System.out.println(id);

		try
		{
			
			String phone = request.getParameter("phone");
			response.setCharacterEncoding("utf-8");
			PrintWriter out = response.getWriter();
			System.out.println(keyService.getUserCheck(phone));
			out.write(keyService.getUserCheck(phone));
			out.flush();
			out.close();
		} catch (NumberFormatException e)
		{
			e.printStackTrace();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/json;charset=UTF-8");
		String reqMessage, respMessage, reqMessage2, respMessage2;
		JSONArray reqObject = null;
		JSONArray reqObject1 = null;
		JSONArray reqObject2 = null;
		JSONArray respObject = null;
		JSONArray respObject2 = null;

		try
		{

			BufferedReader br = new BufferedReader(new InputStreamReader(
					request.getInputStream(), "UTF-8"));
			StringBuffer sb = new StringBuffer("");
			String temp;
			while ((temp = br.readLine()) != null)
			{
				sb.append(temp);
			}
			br.close();
			reqMessage = sb.toString();
			System.out.println("请求信息:" + reqMessage);
			reqObject = new JSONArray(reqMessage);
			reqObject2 = new JSONArray(reqMessage);

			if (reqObject.getJSONObject(0).getString("action").equals("article_search"))
			{

				String token = reqObject.getJSONObject(0).getString("searchwords");
				PrintWriter out = response.getWriter();
				System.out.println("反馈信息:" + keyService.getArticleSearch(token));
				out.write(keyService.getArticleSearch(token));
				out.flush();
				out.close();
				
			}else if (reqObject.getJSONObject(0).getString("action").equals("self_diagnose"))
			{
				String token = reqObject.getJSONObject(0).getString("searchwords");
				PrintWriter out = response.getWriter();
				System.out.println("反馈信息:" + keyService.getArticleSearch(token));
				out.write(keyService.getArticleSearch(token));
				out.flush();
				out.close();
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
