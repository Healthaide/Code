package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cn.domain.hello.bean.ArticleCollectionBean;
import cn.domain.hello.bean.RegistBean;

public class Select_y_nDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public int a;
	public int getUserByName(String src,int id)
	{
		ArticleCollectionBean articlecollectionBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				
				String sql = "select * from article_collection where phone = ? and id=?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				prepStmt.setInt(2, id);
				
				rs = prepStmt.executeQuery();
				if (rs.next() )
				{
//					articlecollectionBean = new ArticleCollectionBean(rs.getString(1),
//							rs.getInt(2));
					a=1;
				} else
				{
//					articlecollectionBean = new ArticleCollectionBean(src + "2", src, src, src, src,
//							src, src, src, src);
					a=0;
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return a;
	}
}
