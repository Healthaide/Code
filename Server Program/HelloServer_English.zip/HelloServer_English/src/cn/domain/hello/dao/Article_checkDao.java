package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.ArticleCollectionBean;
import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.Detail_articleBean;
import cn.domain.hello.bean.DocBean;
import cn.domain.hello.bean.List_articleBean;

public class Article_checkDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<ArticleCollectionBean> getUserByName(String src)
	{
		ArticleCollectionBean detail_articleBean = null;
		List<ArticleCollectionBean> keys = new ArrayList<ArticleCollectionBean>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				
				String sql = "select id from article_collection where phone = ? ";
				prepStmt = conn.prepareStatement(sql);
			
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				
				int a = rs.getRow();
				while (rs.next() && rs.getRow() <= 10)
				{
					
					ArticleCollectionBean key = new ArticleCollectionBean();

					key.setId(rs.getInt("id"));
					keys.add(key);
				}
			
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
