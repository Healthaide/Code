package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.ArticleCollectionBean;
import cn.domain.hello.bean.CardBean;
import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.CommentCollectionBean;
import cn.domain.hello.bean.Detail_articleBean;
import cn.domain.hello.bean.DocBean;
import cn.domain.hello.bean.List_articleBean;

public class Card_myDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<CardBean> getUserByName(String src)
	{
		CardBean commentcollectionBean = null;
		List<CardBean> keys = new ArrayList<CardBean>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				//String sql = "select * from article_collection where phone = ? order by date desc";
				String sql = "select * from card where nickname = ? order by date desc ";
				prepStmt = conn.prepareStatement(sql);
				// String src1=src+"";
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// detail_articleBean = new Detail_articleBean(
				// rs.getString(1), rs.getString(2), rs.getString(3),
				// rs.getString(4), rs.getString(5), rs.getString(6),
				// rs.getString(7),rs.getInt(8));
				// }
				// int count=keys.size();
				// List<Detail_articleBean> num = new
				// ArrayList<Detail_articleBean>();
				//int a = rs.getRow();
				while (rs.next() )
				{
					//Detail_articleBean key = new Detail_articleBean();
					CardBean key = new CardBean();
//					key.setTitle(rs.getString("title"));
//					key.setDate(rs.getString("date"));
//					key.setSource(rs.getString("source"));
//					key.setKind(rs.getString("kind"));
//					key.setArticle(rs.getString("article"));
//
//					key.setToken(rs.getString("token"));
					key.setId(rs.getInt("id"));
					key.setHead(rs.getString("head"));
					key.setNickname(rs.getString("nickname"));
					key.setTitle(rs.getString("title"));
					key.setContent(rs.getString("content"));
					key.setFloor(rs.getInt("floor"));
					keys.add(key);
				}
				// for(int i=0;i<num.size();i++){
				// keys.add(num.get(i));
				// }
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
