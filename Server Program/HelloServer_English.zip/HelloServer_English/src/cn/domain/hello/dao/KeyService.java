package cn.domain.hello.dao;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.domain.hello.bean.ArticleBean;
import cn.domain.hello.bean.ArticleCollectionBean;
import cn.domain.hello.bean.CardBean;
import cn.domain.hello.bean.CmtBean;
import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.CommentCollectionBean;
import cn.domain.hello.bean.DepartiBean;
import cn.domain.hello.bean.DepartmentBean;
import cn.domain.hello.bean.DepdisBean;
import cn.domain.hello.bean.DisartiBean;
import cn.domain.hello.bean.DiseaseBean;
import cn.domain.hello.bean.DocBean;
import cn.domain.hello.bean.DocCollectionBean;
import cn.domain.hello.bean.GuideBean;
import cn.domain.hello.bean.JudgeCollectionBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.NewsBean;
import cn.domain.hello.bean.SearchBean;
import cn.domain.hello.bean.SymartiBean;
import cn.domain.hello.bean.SymdisBean;
import cn.domain.hello.bean.SymptomBean;
import cn.domain.hello.bean.TopicBean;
import cn.domain.hello.bean.TopicCommentBean;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class KeyService
{
	private ObjectMapper om = new ObjectMapper();
	private GetcommentDao gcDAO = new GetcommentDao();
	private GetcommentlotDao keyDAO = new GetcommentlotDao();
	private Last_articleDao lastDao = new Last_articleDao();
	private Last_article_docDao last_docDao = new Last_article_docDao();
	private Last_article_10Dao lastDao_10 = new Last_article_10Dao();
	private Last_article_10_docDao lastDao_10_doc = new Last_article_10_docDao();
	private Hot_articleDao hotDao = new Hot_articleDao();
	private Hot_article_docDao hot_docDao = new Hot_article_docDao();
	private Hot_article_10Dao hotDao_10 = new Hot_article_10Dao();
	private Hot_article_10_docDao hotDao_10_doc = new Hot_article_10_docDao();
	private Doc_collection_checkDao collection_checkDao = new Doc_collection_checkDao();
	private Article_checkDao article_checkDao = new Article_checkDao();
	private DepartiDao departiDao = new DepartiDao();
	private DepartmentDao departmentDao = new DepartmentDao();
	private DepdisDao depdisDao = new DepdisDao();
	private DisartiDao disartiDao = new DisartiDao();
	private DiseaseDao diseaseDao = new DiseaseDao();
	private Doc_listDao doc_listDao = new Doc_listDao();
	private GetjudgeDao getjudgeDao = new GetjudgeDao();
	private GuideDao guideDao = new GuideDao();
	private SymartiDao symartiDao = new SymartiDao();
	private SymdisDao symdisDao = new SymdisDao();
	private SymptomDao symptomDao = new SymptomDao();
	private Getdoc_commentDao getdocDAO = new Getdoc_commentDao();
	private Doc_collection_checkDao doc_collection_check = new Doc_collection_checkDao();
	private CommentCollectionDao commentcollection = new CommentCollectionDao();
	private JudgeCollectionDao judgecollectionDao = new JudgeCollectionDao();
	private Topic_listDao topic_listDao = new Topic_listDao();
	private Id_to_allDao id_to_allDao = new Id_to_allDao();
	private Gettopic_comment_10Dao gettopic_comment_10Dao = new Gettopic_comment_10Dao();
	private SearchDao searchDao = new SearchDao();
    private NewsAllDao newsallDao = new NewsAllDao();
    private ReadPostDao readpostDao = new ReadPostDao();
	private Home_newsDao homenewsDao = new Home_newsDao();
	private Card_newDao cardnewDao = new Card_newDao();
	private Card_hotDao cardhotDao = new Card_hotDao();
	private Card_myDao cardmyDao = new Card_myDao();
	private Floor_to_allDao floortoallDao = new Floor_to_allDao();
	private Id_to_All_newDao idtoallDao = new Id_to_All_newDao();
	private SearchArticleDao saDao = new SearchArticleDao();

    
	public String getTopicKeys(String id) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	
	//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
	List<TopicBean> array = id_to_allDao.getUserByName(Integer.parseInt(id));
	//GetcommentDao getcomment = new GetcommentDao();
	
//	Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
	//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
	JSONObject result;
	Get_topic_list_numDao get_topic_list_num = new Get_topic_list_numDao();
	int num=get_topic_list_num.getUserByName(0);
	Gettopic_comment_3Dao gettopic_comment_3 = new Gettopic_comment_3Dao();
	List<TopicCommentBean> array_1 = gettopic_comment_3.getUserByName(Integer.parseInt(id));
	try
	{
	result = new JSONObject()
			.put("status", 0)
			
			.put("head", array.get(0).getHead())
			.put("title", array.get(0).getTitle())
			.put("content", array.get(0).getContent())
			.put("time", array.get(0).getTime());
			
	for(int i=0;i<num;i++){

		result.put("body"+(i+1), new JSONObject()
						.put("id", array_1.get(i).getId())
						.put("phone", array_1.get(i).getPhone())
						.put("content", array_1.get(i).getContent())
						.put("time", array_1.get(i).getTime()));
	}
	JSONArray jsonarray = new JSONArray().put(result);
	return jsonarray.toString();
	} 
	catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	
//	public String getReadPost(int page, int id) throws JsonProcessingException,
//	SQLException, UnsupportedEncodingException
//			{
//			
//			//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
//			//List<TopicBean> array = id_to_allDao.getUserByName(Integer.parseInt(id));
//			//GetcommentDao getcomment = new GetcommentDao();
//			ReadPost array =  readpostDao.readPost(page,id);
//			//Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
//			//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
//			JSONObject result;
////			Get_topic_list_numDao get_topic_list_num = new Get_topic_list_numDao();
////			int num=get_topic_list_num.getUserByName(0);
////			Gettopic_comment_3Dao gettopic_comment_3 = new Gettopic_comment_3Dao();
////			List<TopicCommentBean> array_1 = gettopic_comment_3.getUserByName(Integer.parseInt(id));
//			try
//			{
//			result = new JSONObject()
//					.put("status", 0)
//					
//					.put("id", array.getList().get(1))
//					.put("name", array.getList().get(2))
//					.put("date", array.getList().get(3))
//					.put("userid", array.getList().get(4))
//					.put("content", array.getList().get(5));
//					
//			for(int i=0;i<num;i++){
//			
//				result.put("body"+(i+1), new JSONObject()
//								.put("id", array_1.get(i).getId())
//								.put("phone", array_1.get(i).getPhone())
//								.put("content", array_1.get(i).getContent())
//								.put("time", array_1.get(i).getTime()));
//			}
//			JSONArray jsonarray = new JSONArray().put(result);
//			return jsonarray.toString();
//			} 
//			catch (JSONException e1)
//			{
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//			return null;
//			}
	
	
	public String getTopic_10Keys(String id) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	
	//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
	List<TopicCommentBean> array = gettopic_comment_10Dao.getUserByName(Integer.parseInt(id));
	//GetcommentDao getcomment = new GetcommentDao();
	Get_topic_comment_numDao get_topic_comment_numDao = new Get_topic_comment_numDao();
	int num = get_topic_comment_numDao.getUserByName(Integer.parseInt(id));
	JSONObject result;
//	Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
//	//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
//	JSONObject result;
//	Getcomment_numDao getcomment_num = new Getcomment_numDao();
//	int num=getcomment_num.getUserByName(id);
	try
	{
		//result = new JSONObject().put("status", 0).put("num", num);
		result = new JSONObject().put("status", 0);
		for (int i = 0; i < num; i++)
		{
//			CmtBean cmtbean = id_to_phone.getUserByName(array.get(i).getPhone());
//			Token_to_phone token_to_phone = new Token_to_phone();
//			String phone = token_to_phone.token_to_phone(cmtbean.getToken());
			result.put(
					"body" + (i + 1),
					new JSONObject()
							//.put("head", array.get(i).getHead())
						
							.put("content", array.get(i).getContent())
							.put("date", array.get(i).getTime())
							.put("phone", array.get(i).getPhone())
							.put("id", id)
							);
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	public String getUserKeys(String id) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{

		//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
		List<CommentCollectionBean> array = commentcollection.getUserByName(id);
		//GetcommentDao getcomment = new GetcommentDao();
		
		Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
		//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
		JSONObject result;
		Getcomment_numDao getcomment_num = new Getcomment_numDao();
		int num=getcomment_num.getUserByName(id);
		try
		{
			result = new JSONObject().put("status", 0).put("num", num);

			for (int i = 0; i < num; i++)
			{
				CmtBean cmtbean = id_to_phone.getUserByName(array.get(i).getPhone());
				Token_to_phone token_to_phone = new Token_to_phone();
				String phone = token_to_phone.token_to_phone(cmtbean.getToken());
				result.put(
						"body" + (i + 1),
						new JSONObject()
								//.put("head", array.get(i).getHead())
							
								.put("content", cmtbean.getContent())
								.put("date", cmtbean.getDate())
								.put("phone", phone)
								.put("id", id)
								);
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getCardNew() throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		
		//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
		//List<CardBean> array = cardnewDao.getUserByName(nickname);
		//GetcommentDao getcomment = new GetcommentDao();
		
		//Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
		//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
		//JSONObject result;
		//Getcomment_numDao getcomment_num = new Getcomment_numDao();
		//int num=getcomment_num.getUserByName(id);
		Card_numDao cn = new Card_numDao();
		int c = cn.getUserByName();
			List<CardBean> array1 = cardnewDao.getUserByName();
			JSONObject result;
			try
			{
				result = new JSONObject().put("status", 0).put("num", c);
			
				for (int i = 0; i < c; i++)
				{
					result.put(
							"body" + (i + 1),
							new JSONObject().put("id", array1.get(i).getId())
									.put("head", array1.get(i).getHead())
									.put("nickname", array1.get(i).getNickname())
									.put("title", array1.get(i).getTitle())
									.put("content", array1.get(i).getContent())
									.put("date", array1.get(i).getDate())
									.put("floor", array1.get(i).getFloor()));
				}
				JSONArray jsonarray = new JSONArray().put(result);
				return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}
	
	
	public String getCardHot() throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		
		//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
		//List<CardBean> array = cardnewDao.getUserByName(nickname);
		//GetcommentDao getcomment = new GetcommentDao();
		
		//Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
		//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
		//JSONObject result;
		//Getcomment_numDao getcomment_num = new Getcomment_numDao();
		//int num=getcomment_num.getUserByName(id);
		Card_numDao cn = new Card_numDao();
		int c = cn.getUserByName();
			List<CardBean> array1 = cardhotDao.getUserByName();
			JSONObject result;
			try
			{
				result = new JSONObject().put("status", 0).put("num", c);
			
				for (int i = 0; i < c; i++)
				{
					result.put(
							"body" + (i + 1),
							new JSONObject().put("id", array1.get(i).getId())
									.put("head", array1.get(i).getHead())
									.put("nickname", array1.get(i).getNickname())
									.put("title", array1.get(i).getTitle())
									.put("content", array1.get(i).getContent())
									.put("date", array1.get(i).getDate())
									.put("floor", array1.get(i).getFloor()));
				}
				JSONArray jsonarray = new JSONArray().put(result);
				return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}


	public String getCardMy(String nickname) throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		
		//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
		//List<CardBean> array = cardnewDao.getUserByName(nickname);
		//GetcommentDao getcomment = new GetcommentDao();
		
		//Id_to_phone_comment id_to_phone = new Id_to_phone_comment();
		//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
		//JSONObject result;
		//Getcomment_numDao getcomment_num = new Getcomment_numDao();
		//int num=getcomment_num.getUserByName(id);
		Card_numDao cn = new Card_numDao();
		int c = cn.getUserByName();
			List<CardBean> array1 = cardmyDao.getUserByName(nickname);
			JSONObject result;
			try
			{
				result = new JSONObject().put("status", 0).put("num", c);
			
				for (int i = 0; i < c; i++)
				{
					result.put(
							"body" + (i + 1),
							new JSONObject().put("id", array1.get(i).getId())
									.put("head", array1.get(i).getHead())
									.put("nickname", array1.get(i).getNickname())
									.put("title", array1.get(i).getTitle())
									.put("content", array1.get(i).getContent())
									.put("date", array1.get(i).getDate())
									.put("floor", array1.get(i).getFloor()));
				}
				JSONArray jsonarray = new JSONArray().put(result);
				return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}

	
	
	
	public String getUserLast(String token) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<ArticleBean> array = lastDao.getUserByName(token);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 3);

			for (int i = 0; i < 3; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(i).getName())
								.put("kind", array.get(i).getKind())
								.put("browse", array.get(i).getClick())
								.put("id", array.get(i).getId()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	

	
	public String getDocLast(String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<List_articleBean> array = last_docDao.getUserByName(token);
	JSONObject result;
	try
	{
		result = new JSONObject().put("status", 0).put("num", 3);
	
		for (int i = 0; i < 3; i++)
		{
			result.put(
					"body" + (i + 1),
					new JSONObject().put("title", array.get(i).getTitle())
							.put("kind", array.get(i).getKind())
							.put("browse", array.get(i).getBrowse())
							.put("id", array.get(i).getId()));
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	public String getUserLast_10(String token) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<ArticleBean> array = lastDao_10.getUserByName(token);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(i).getName())
								.put("kind", array.get(i).getKind())
								.put("browse", array.get(i).getClick())
								.put("id", array.get(i).getId()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}
	
	public String getDocLast_10(String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<ArticleBean> array = lastDao_10_doc.getUserByName(token);
	JSONObject result;
	try
	{
		result = new JSONObject().put("status", 0).put("num", 10);
	
		for (int i = 0; i < 10; i++)
		{
			result.put(
					"body" + (i + 1),
					new JSONObject().put("title", array.get(i).getName())
							.put("kind", array.get(i).getKind())
							.put("browse", array.get(i).getClick())
							.put("id", array.get(i).getId()));
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	public String getUserHot(String token) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<ArticleBean> array = hotDao.getUserByName(token);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 3);

			for (int i = 0; i < 3; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(i).getName())
								.put("kind", array.get(i).getKind())
								.put("browse", array.get(i).getClick())
								.put("id", array.get(i).getId()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}
	
	public String getDocHot(String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<List_articleBean> array = hot_docDao.getUserByName(token);
	JSONObject result;
	try
	{
		result = new JSONObject().put("status", 0).put("num", 3);
	
		for (int i = 0; i < 3; i++)
		{
			result.put(
					"body" + (i + 1),
					new JSONObject().put("title", array.get(i).getTitle())
							.put("kind", array.get(i).getKind())
							.put("browse", array.get(i).getBrowse())
							.put("id", array.get(i).getId()));
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	public String getUserHot_10(String token) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<ArticleBean> array = hotDao_10.getUserByName(token);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(i).getName())
								.put("kind", array.get(i).getKind())
								.put("browse", array.get(i).getClick())
								.put("id", array.get(i).getId()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}
	
	
	public String getSearchDao(String keyword) throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		Line_numDao lm = new Line_numDao();
		int a;
		a=lm.getUserByName(keyword);
		
		List<SearchBean> array = searchDao.getUserByName(keyword);
		JSONObject result;
		
		
		try
		{
			
			result = new JSONObject().put("status", 0).put("num", a);
		
			for (int i = 0; i < a; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(i).getTitle())
								.put("url", array.get(i).getUrl())
								.put("content", array.get(i).getContent())
								.put("date", array.get(i).getDate()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}
	
	
	public String getFloortoallDao(int src,int src1) throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		List<CardBean> array = floortoallDao.getUserByName(src1);
		List<CardBean> array1 = idtoallDao.getUserByName(src);
		
		JSONObject result;
		try
		{
			Towards_numDao tn = new Towards_numDao();
			int a = tn.getUserByName(src1);
			if(a==0)
			{
				result = new JSONObject().put("status", 0).put("num", a+1);
				
				
				result.put("host", new JSONObject().put("head", array1.get(0).getHead())
				.put("nickname",array1.get(0).getNickname())
				.put("title",array1.get(0).getTitle())
				.put("content",array1.get(0).getContent())
				.put("date",array1.get(0).getDate()));
			
			}
			else 
			{
			result = new JSONObject().put("status", 0).put("num", a);
		
			
			result.put("host", new JSONObject().put("head", array1.get(0).getHead())
			.put("nickname",array1.get(0).getNickname())
			.put("title",array1.get(0).getTitle())
			.put("content",array1.get(0).getContent())
			.put("date",array1.get(0).getDate()));
			
			
			for (int i = 0; i < a; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("head", array.get(i).getHead())
								.put("nickname", array.get(i).getNickname())
								.put("content", array.get(i).getContent())
								.put("date", array.get(i).getDate()));
			}
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}
	
	
	public String getHomenewsDao() throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		List<SearchBean> array = homenewsDao.getUserByName();
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 5);
		
			for (int i = 0; i < 5; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(i).getTitle())
								.put("url", array.get(i).getUrl())
								.put("content", array.get(i).getContent())
								.put("date", array.get(i).getDate()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}
	
	
	
	
	public String getDocHot_10(String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<ArticleBean> array = hotDao_10_doc.getUserByName(token);
	JSONObject result;
	try
	{
		result = new JSONObject().put("status", 0).put("num", 10);
	
		for (int i = 0; i < 10; i++)
		{
			result.put(
					"body" + (i + 1),
					new JSONObject().put("title", array.get(i).getName())
							.put("kind", array.get(i).getKind())
							.put("browse", array.get(i).getClick())
							.put("id", array.get(i).getId()));
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	
	public String getNewsAll(String phone) throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
		{
		String aa=null;
		Phone_to_urlDao ptu = new Phone_to_urlDao();
		List<NewsBean> array1 = ptu.getUserByName(phone);
		List<SearchBean> array=null;
		News_numDao nn = new News_numDao();
		int a = nn.getUserByName(phone);
//		for(int i=0;i<a;i++){
//			aa=array1.get(i).getUrl();
//			array = newsallDao.getUserByName(aa);	
//		}
		
		JSONObject result;
		try
		{
			
			
			if(a==0)
			{
				result = new JSONObject().put("status", 0).put("num", a);
				JSONArray jsonarray = new JSONArray().put(result);
				
				return jsonarray.toString();
			}
			else
			{
			result = new JSONObject().put("status", 0).put("num", a);
		
			for (int i = 0; i < a; i++)
			{
				aa=array1.get(i).getUrl();
				array = newsallDao.getUserByName(aa);
				result.put(
						"body" + (i + 1),
						new JSONObject().put("title", array.get(0).getTitle())
								.put("url", array.get(0).getUrl())
								.put("content", array.get(0).getContent())
								.put("date", array.get(0).getDate()));
			}
			
			JSONArray jsonarray = new JSONArray().put(result);
			
			return jsonarray.toString();
			}
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
		}

	public String getUserCollection_check(String token)
			throws JsonProcessingException, SQLException,
			UnsupportedEncodingException
	{
		List<DocCollectionBean> array = collection_checkDao.getUserByName(token);
		Doc_collection_numDao doc_collection_num = new Doc_collection_numDao();
		int num = doc_collection_num.getUserByName(token);
		Doc_detailDao doc_detail = new Doc_detailDao();
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", num);

			for (int i = 0; i < num; i++)
			{
				DocBean docbean = doc_detail.getUserByName(array.get(i).getPhone());
				result.put(
						"body" + (i + 1),
						new JSONObject()
								.put("phone", docbean.getPhone())
								.put("head", docbean.getHead())
								.put("name", docbean.getName())
								.put("hospital", docbean.getHospital())
								.put("department", docbean.getDepartment())
								.put("position", docbean.getPosition())
								.put("sex", docbean.getSex())
								.put("area", docbean.getArea())
								.put("token", docbean.getToken()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

		public String getArticleSearch(String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<ArticleBean> array = saDao.getUserByName(token);
	JSONObject result;
	try
	{
		result = new JSONObject().put("status", 0).put("num", array.get(0).getNum());
	
		for (int i = 0; i < array.get(0).getNum(); i++)
		{
			result.put(
					"body" + (i + 1),
					new JSONObject().put("id", array.get(i).getId())
							.put("title", array.get(i).getName())
							.put("kind", array.get(i).getSource())
							.put("click", array.get(i).getClick()));
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	public String getUserCheck(String phone)
			throws JsonProcessingException, SQLException,
			UnsupportedEncodingException
	{
	
		List<ArticleCollectionBean> array = article_checkDao.getUserByName(phone);
		
		ArticleDao article = new ArticleDao();

		JSONObject result;
		Article_like_numDao article_like_num = new Article_like_numDao();
		int num = article_like_num.getUserByName(phone);
		try
		{
			result = new JSONObject().put("status", 0).put("num", num);

			CommentBean commentbean = new CommentBean();
			HashMap<Integer,CommentBean> hmcb = new HashMap<Integer,CommentBean>();
			HashMap<Integer,List<ArticleBean>> hm = new HashMap<Integer,List<ArticleBean>>();
			for(int i = 0; i <num; i++){
			
				hmcb.put(i, gcDAO.getUserByName(array.get(i).getId()));
				hm.put(i, article.getUserByName(array.get(i).getId()));
			}
			for(int i = 0; i<num; i++){
				
				result.put("body"+(i+1), 
						new JSONObject()
									.put("title", hm.get(i).get(0).getName())
									.put("date", hm.get(i).get(0).getDate())
									.put("source", hm.get(i).get(0).getSource())
									.put("kind", hm.get(i).get(0).getKind())
									.put("article", hm.get(i).get(0).getArticle())
									.put("id", hm.get(i).get(0).getId())
									.put("browse", hm.get(i).get(0).getClick())
									.put("comment", new JSONObject()
											
														.put("phone", hmcb.get(i).getPhone())
														.put("content", hmcb.get(i).getContent())
														.put("date", hmcb.get(i).getDate())));
									
				
			}

			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	
	public String getUserDeparti(int s_depid) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<DepartiBean> array = departiDao.getUserByName(s_depid);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("s_depid",
								array.get(i).getS_depid()).put("s_aid",
								array.get(i).getS_aid()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserDepartment(int depid) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<DepartmentBean> array = departmentDao.getUserByName(depid);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put("body" + (i + 1),
						new JSONObject().put("depid", array.get(i).getDepid())
								.put("name", array.get(i).getName()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserDepdis(int s_id) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<DepdisBean> array = depdisDao.getUserByName(s_id);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put("body" + (i + 1),
						new JSONObject().put("s_id", array.get(i).getS_id())
								.put("s_disid", array.get(i).getS_disid()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserDisarti(String s_name) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<DisartiBean> array = disartiDao.getUserByName(s_name);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject()
								.put("s_disid", array.get(i).getS_disid()).put(
										"s_aid", array.get(i).getS_aid()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserDisease(String name) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<DiseaseBean> array = diseaseDao.getUserByName(name);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("name", array.get(i).getName())
								.put("intro", array.get(i).getIntro())
								.put("part", array.get(i).getPart())
								.put("cause", array.get(i).getCause())
								.put("prevent", array.get(i).getPrevent())
								.put("nurse", array.get(i).getNurse())
								.put("click", array.get(i).getClick()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserDoc_fklist(String token,String department) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<DocBean> array = doc_listDao.getUserByName(token);
		String fk=null;
		int j=0;
		JSONObject result;
		Get_fk_num get_fk_num = new Get_fk_num();
		int num = get_fk_num.getUserByName(department);
		All_doc_numDao all_doc_num = new All_doc_numDao();
		int a = 0;
		int all_num = all_doc_num.getUserByName(a);
		try
		{
			result = new JSONObject().put("status", 0).put("num", num);

			
			for (int i = 0; i < all_num; i++)
			{
				if(array.get(i).getDepartment().equals("妇科")){
					 //fk=array.get(i).getDepartment();
				
				result.put(
						"body" + (j + 1),
						new JSONObject()
								.put("head", array.get(i).getHead())
								.put("name", array.get(i).getName())
								.put("hospital", array.get(i).getHospital())
								.put("department", array.get(i).getDepartment())
								.put("position", array.get(i).getPosition())
								.put("phone", array.get(i).getPhone()));
				j++;
				}
				else 
					continue;
				
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

		public String getUserDoc_nklist(String token,String department) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String nk=null;
	int j=0;
	JSONObject result;
	Get_nk_num get_nk_num = new Get_nk_num();
	int num = get_nk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("男科")){
				// nk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	public String getUserDoc_wklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String wk=null;
	int j=0;
	JSONObject result;
	Get_wk_num get_wk_num = new Get_wk_num();
	int num = get_wk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("外科")){
				// wk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}


	public String getUserDoc_neiklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String neik=null;
	int j=0;
	JSONObject result;
	Get_neik_num get_neik_num = new Get_neik_num();
	int num = get_neik_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("内科")){
				// neik=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	
	public String getUserDoc_pfklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String pfk=null;
	int j=0;
	JSONObject result;
	Get_pfk_num get_pfk_num = new Get_pfk_num();
	int num = get_pfk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("皮肤科")){
				// pfk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	
	public String getUserDoc_gsklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String gsk=null;
	int j=0;
	JSONObject result;
	Get_gsk_num get_gsk_num = new Get_gsk_num();
	int num = get_gsk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("骨伤科")){
				// gsk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	
	public String getUserDoc_jsxlklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String jsxlk=null;
	int j=0;
	JSONObject result;
	Get_jsxlk_num get_jsxlk_num = new Get_jsxlk_num();
	int num = get_jsxlk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("精神心理科")){
				// jsxlk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	public String getUserDoc_kqhmklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String kqhmk=null;
	int j=0;
	JSONObject result;
	Get_kqhmk_num get_kqhmk_num = new Get_kqhmk_num();
	int num = get_kqhmk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("口腔颌面科")){
				// kqhmk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	public String getUserDoc_yklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String yk=null;
	int j=0;
	JSONObject result;
	Get_yk_num get_yk_num = new Get_yk_num();
	int num = get_yk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("眼科")){
				// yk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	public String getUserDoc_ebyhklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String ebyhk=null;
	int j=0;
	JSONObject result;
	Get_ebyhk_num get_ebyhk_num = new Get_ebyhk_num();
	int num = get_ebyhk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("耳鼻咽喉科")){
				// ebyhk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}

	
	public String getUserDoc_yyklist(String token,String department) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<DocBean> array = doc_listDao.getUserByName(token);
	String yyk=null;
	int j=0;
	JSONObject result;
	Get_yyk_num get_yyk_num = new Get_yyk_num();
	int num = get_yyk_num.getUserByName(department);
	All_doc_numDao all_doc_num = new All_doc_numDao();
	int a=0;
	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < all_num; i++)
		{
			if(array.get(i).getDepartment().equals("营养科")){
				// yyk=array.get(i).getDepartment();
			
			result.put(
					"body" + (j + 1),
					new JSONObject()
							.put("head", array.get(i).getHead())
							.put("name", array.get(i).getName())
							.put("hospital", array.get(i).getHospital())
							.put("department", array.get(i).getDepartment())
							.put("position", array.get(i).getPosition())
							.put("phone", array.get(i).getPhone()));
			j++;
			}
			else
				continue;
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	
	public String getTopiclist(String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	List<TopicBean> array = topic_listDao.getUserByName(token);
//	String kqhmk=null;
//	int j=0;
	JSONObject result;
	Get_topic_list_numDao get_topic_list_num = new Get_topic_list_numDao();
	int num = get_topic_list_num.getUserByName(0);
//	All_doc_numDao all_doc_num = new All_doc_numDao();
//	int a=0;
//	int all_num = all_doc_num.getUserByName(a);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		
		for (int i = 0; i < num; i++)
		{
			
				// kqhmk=array.get(i).getDepartment();
			
			result.put(
					"body" + (i + 1),
					new JSONObject()
							.put("id", array.get(i).getId())
							.put("head", array.get(i).getHead())
							.put("title", array.get(i).getTitle())
							.put("content", array.get(i).getContent())
							.put("time", array.get(i).getTime())
						);
			
			
		
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
	
	public String getHomenews(String token) throws JsonProcessingException,
	SQLException, UnsupportedEncodingException
{
List<TopicBean> array = topic_listDao.getUserByName(token);
//String kqhmk=null;
//int j=0;
JSONObject result;
Get_topic_list_numDao get_topic_list_num = new Get_topic_list_numDao();
int num = get_topic_list_num.getUserByName(0);
//All_doc_numDao all_doc_num = new All_doc_numDao();
//int a=0;
//int all_num = all_doc_num.getUserByName(a);
try
{
	result = new JSONObject().put("status", 0).put("num", num);

	
	for (int i = 0; i < num; i++)
	{
		
			// kqhmk=array.get(i).getDepartment();
		
		result.put(
				"body" + (i + 1),
				new JSONObject()
						.put("id", array.get(i).getId())
						.put("head", array.get(i).getHead())
						.put("title", array.get(i).getTitle())
						.put("content", array.get(i).getContent())
						.put("time", array.get(i).getTime())
					);
		
		
	
	}
	JSONArray jsonarray = new JSONArray().put(result);
	return jsonarray.toString();
} catch (JSONException e1)
{
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
return null;
}
	
	
	
	public String getUserGetjudge(String phone,String token) throws JsonProcessingException,
		SQLException, UnsupportedEncodingException
	{
	
	//List<Key> array = keyDAO.getUserByName(Integer.parseInt(id));
	List<JudgeCollectionBean> array = judgecollectionDao.getUserByName(phone);
	//GetcommentDao getcomment = new GetcommentDao();
	
	Phone_to_token_comment phone_to_token = new Phone_to_token_comment();
	//CommentBean commentbean = getcomment.getUserByName(Integer.parseInt(id));
	JSONObject result;
	Judge_get_numDao judge_get_num = new Judge_get_numDao();
	int num = judge_get_num.getUserByName(phone);
	try
	{
		result = new JSONObject().put("status", 0).put("num", num);
	
		for (int i = 0; i < num; i++)
		{
			JdeBean jdebean = phone_to_token.getUserByName(array.get(i).getToken());
			Token_to_phone token_to_phone = new Token_to_phone();
			String phone_user = token_to_phone.token_to_phone(token);
			result.put(
					"body" + (i + 1),
					new JSONObject()
							//.put("head", array.get(i).getHead())
						
							.put("content", jdebean.getContent())
							.put("date", jdebean.getTime())
							.put("phone", phone)
							
							);
		}
		JSONArray jsonarray = new JSONArray().put(result);
		return jsonarray.toString();
	} catch (JSONException e1)
	{
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return null;
	}
	
//	public String getUserGetjudge(String phone,String token) throws JsonProcessingException,
//			SQLException, UnsupportedEncodingException
//	{
//		Token_to_phone token_to_phone = new Token_to_phone();
////		String phone = token_to_phone.token_to_phone(token);
//		List<JudgeBean> array = getjudgeDao.getUserByName(phone);
//		JSONObject result;
//		Judge_get_numDao judge_get_num = new Judge_get_numDao();
//		int num = judge_get_num.getUserByName(token);
//		Token_to_head token_to_head = new Token_to_head();
//		Phone_to_token_comment phone_to_token_comment = new Phone_to_token_comment();
//		
//		try
//		{
//			
//
//			if(num==0)
//				result = new JSONObject().put("status", 1);
//			else{
//				result = new JSONObject().put("status", 0).put("num", num);
//			for (int i = 0; i < num; i++)
//			{
//				JdeBean jdebean = phone_to_token_comment.getUserByName(array.get(i).getToken());
//				result.put(
//						"body" + (i + 1),
//						new JSONObject().put("head", token_to_head.to_head(array.get(i).getToken()))
//								.put("phone", token_to_phone.token_to_phone(array.get(i).getToken()))
//								.put("content", jdebean.getContent())
//								.put("date", jdebean.getTime())
//								//.put("token", array.get(i).getToken())
//								);
//			}
//			JSONArray jsonarray = new JSONArray().put(result);
//			return jsonarray.toString();
//			}
//		} catch (JSONException e1)
//		{
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		return null;
//	}

	public String getUserGuide(String name) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<GuideBean> array = guideDao.getUserByName(name);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put(
						"body" + (i + 1),
						new JSONObject().put("name", array.get(i).getName())
								.put("time", array.get(i).getTime())
								.put("fre", array.get(i).getFre())
								.put("pre", array.get(i).getPre())
								.put("pro", array.get(i).getPro())
								.put("sta", array.get(i).getSta()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserSymarti(int s_sid) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<SymartiBean> array = symartiDao.getUserByName(s_sid);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put("body" + (i + 1),
						new JSONObject().put("s_sid", array.get(i).getS_sid())
								.put("s_aid", array.get(i).getS_aid()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserSymdis(int s_id) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<SymdisBean> array = symdisDao.getUserByName(s_id);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put("body" + (i + 1),
						new JSONObject().put("s_id", array.get(i).getS_id())
								.put("s_id", array.get(i).getS_id()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public String getUserSymptom(int symid) throws JsonProcessingException,
			SQLException, UnsupportedEncodingException
	{
		List<SymptomBean> array = symptomDao.getUserByName(symid);
		JSONObject result;
		try
		{
			result = new JSONObject().put("status", 0).put("num", 10);

			for (int i = 0; i < 10; i++)
			{
				result.put("body" + (i + 1),
						new JSONObject().put("symid", array.get(i).getSymid())
								.put("name", array.get(i).getName()));
			}
			JSONArray jsonarray = new JSONArray().put(result);
			return jsonarray.toString();
		} catch (JSONException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}
}
