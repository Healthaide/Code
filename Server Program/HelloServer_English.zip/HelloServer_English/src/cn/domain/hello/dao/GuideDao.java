package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.JudgeBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.GuideBean;

public class GuideDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<GuideBean> getUserByName(String src)
	{
		// String C=null;
		GuideBean guide = null;
		List<GuideBean> keys = new ArrayList<GuideBean>();
		try
		{
			conn = super.openDB();

			if (conn != null)
			{
				String sql = "select * from guide where name = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// guide = new GuideBean(rs.getString(1), rs.getString(2),
				// rs.getString(3), rs.getString(4), rs.getString(5),
				// rs.getString(6));
				// }
				while (rs.next() && rs.getRow() <= 10)
				{
					GuideBean key = new GuideBean();
					key.setName(rs.getString("name"));
					key.setTime(rs.getString("time"));
					key.setFre(rs.getString("fre"));
					key.setPre(rs.getString("pre"));
					key.setPro(rs.getString("pro"));
					key.setSta(rs.getString("sta"));
					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
