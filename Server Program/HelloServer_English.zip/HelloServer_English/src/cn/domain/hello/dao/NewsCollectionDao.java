package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import cn.domain.hello.bean.ArticleCollectionBean;
import cn.domain.hello.bean.NewsBean;

public class NewsCollectionDao extends BaseDao
{
	public PreparedStatement prepStmt = null;// preparedStatement瀹炰緥鍖呭惈宸茬紪璇戠殑SQL璇彞锛屼娇璇彞鍑嗗濂斤紝淇濆瓨鐨勶紵闇�鍦ㄨ鎵ц鍓嶉�杩噑etXXX鏂规硶鎻愪緵
	public int rs;// setString瀹氫箟浜嗗瓧绗︿覆涓n涓紵瀛楃鐨勬浛鎹�

	public int getUserByName(String src, int src1)
	{
		NewsBean newsBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				// RandomTest S = new RandomTest();
				// C = S.RandomToken();
				// String D=src+src1;
				String sql = "insert into article_collection(phone,id)values(?,?)";
				prepStmt = conn.prepareStatement(sql);

				// String src9=src+"";
				// String src10=src+"";
				// String src11=src+"";
				// String src12=src+"";
				// String src13=src+"";
				prepStmt.setString(1, src);
				prepStmt.setInt(2, src1);
				// prepStmt.setString(3, src9);
				// prepStmt.setString(4, src10);
				// prepStmt.setString(5, src11);
				// prepStmt.setString(6, src12);
				// prepStmt.setString(7, src13);

				rs = prepStmt.executeUpdate();
				// if(rs.next()){
				// registBean = new
				// RegistBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
				// }
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{

				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rs;
	}

}
