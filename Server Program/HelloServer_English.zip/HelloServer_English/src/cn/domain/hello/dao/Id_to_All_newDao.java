package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.CardBean;
import cn.domain.hello.bean.DiseaseBean;
import cn.domain.hello.bean.DocBean;
import cn.domain.hello.bean.TopicBean;

public class Id_to_All_newDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<CardBean> getUserByName(int src)
	{
		TopicBean docBean = null;
		List<CardBean> keys = new ArrayList<CardBean>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				//String sql = "select * from tab_topic,tab_user where tab_user.token=? ";
				String sql = "select * from card where id=?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setInt(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// docBean = new DocBean(rs.getString(1), rs.getString(2),
				// rs.getString(3), rs.getString(4), rs.getString(5),
				// rs.getString(6),
				// rs.getString(7),rs.getString(8),rs.getString(9));
				// }
				while (rs.next() )
				{
					CardBean key = new CardBean();
					//key.setId(rs.getInt("id"));
					key.setHead(rs.getString("head"));
					key.setNickname(rs.getString("nickname"));
					key.setTitle(rs.getString("title"));
					key.setContent(rs.getString("content"));
					key.setDate(rs.getString("date"));
//					key.setPosition(rs.getString("position"));
//					key.setSex(rs.getString("sex"));
//					key.setArea(rs.getString("area"));
//					key.setToken(rs.getString("token"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
