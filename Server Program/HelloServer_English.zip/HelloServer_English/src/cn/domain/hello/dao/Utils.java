package cn.domain.hello.dao;

import java.util.ArrayList;
import java.util.List;

public class Utils
{

	private static final String SEP1 = ",";

	public static List<Object> StringToList(String listText)
	{
		if (listText == null || listText.equals(""))
			return null;

		listText = listText.substring(1);

		List<Object> list = new ArrayList<Object>();
		String[] text = listText.split(SEP1);
		for (String str : text)
		{
			list.add(str);
		}
		return list;
	}
}
