package cn.domain.hello.dao;

import java.util.Random;

public class RandomTest
{

	public int C;

	public int RandomToken()
	{
		int max = 2000;
		Random random = new Random();
		int S = random.nextInt(max);

		return S;
	}

	public int getC()
	{
		return C;
	}
}
