package cn.domain.hello.dao;

import java.util.*;
import java.sql.*;
import cn.domain.hello.domain.ReadPost;
import cn.domain.hello.tool.OP;
import cn.domain.hello.tool.Post;

public class ReadPostDao extends BaseDao {
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public ReadPost readPost(int page, int id) {
		ReadPost list = new ReadPost();
		List plist = new ArrayList<OP>();
		String sql = "";
		OP op = new OP();
		Post post = new Post();
		System.out.println("Now start to get the posts.");

		try {
			conn = super.openDB();
			if (conn != null) {
				int i = (page - 1)*10;
				
				if(page == 1){
					sql = "select title,date,userid,content from op where id = '"+id+"'";
					prepStmt = conn.prepareStatement(sql);
					rs = prepStmt.executeQuery();
					if (rs.next()) {
						op.setID(id);
						op.setName(rs.getString(1));
						op.setDate(rs.getString(2));
						op.setUserid(rs.getInt(3));
						op.setContent(rs.getString(4));
						System.out.println("the title is"+op.getName());
						plist.add(op);
					}
					i++;
				}
				
				for(;i<=(page*10);i++){
					sql = "select id,pid,date,userid,content from post where "
							+ "pid = '"+id+"' and num = '"+i+"'";
					prepStmt = conn.prepareStatement(sql);
					rs = prepStmt.executeQuery();
					if (rs.next()) {
						post.setOpID(id);
						post.setNum(i);
						post.setID(rs.getInt(1));
						post.setPID(rs.getInt(2));
						post.setDate(rs.getString(3));
						post.setUserid(rs.getInt(4));
						post.setContent(rs.getString(5));
						System.out.println("the id is"+post.getID());
						
						if(post.getPID() != 0){
							int pid = post.getPID();
							sql = "select userid,content from post where pid = '"+ pid +"'";
							prepStmt = conn.prepareStatement(sql);
							rs = prepStmt.executeQuery();
							if (rs.next()) {
								post.setPcontent(rs.getString(2));
								
								System.out.println("the pcontent is"+rs.getString(2));
								
								int uid = rs.getInt(1);
								sql = "select uname from user where id = '"+ uid +"'";
								prepStmt = conn.prepareStatement(sql);
								rs = prepStmt.executeQuery();
								if (rs.next()) {
									post.setPuname(rs.getString(1));
								}
							}
						}
						
						plist.add(post);
						post = new Post();
					}
				}
			}
			list.setList(plist);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
}