package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.DiseaseBean;
import cn.domain.hello.bean.DocBean;
import cn.domain.hello.bean.TopicBean;

public class Topic_listDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<TopicBean> getUserByName(String src)
	{
		TopicBean docBean = null;
		List<TopicBean> keys = new ArrayList<TopicBean>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				//String sql = "select * from tab_topic,tab_user where tab_user.token=? ";
				String sql = "select * from tab_topic,tab_user where tab_user.state=0 and tab_user.token in (select tab_user.token from tab_user where tab_user.token=?)";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// docBean = new DocBean(rs.getString(1), rs.getString(2),
				// rs.getString(3), rs.getString(4), rs.getString(5),
				// rs.getString(6),
				// rs.getString(7),rs.getString(8),rs.getString(9));
				// }
				while (rs.next() )
				{
					TopicBean key = new TopicBean();
					key.setId(rs.getInt("id"));
					key.setHead(rs.getString("head"));
					key.setTitle(rs.getString("title"));
					key.setContent(rs.getString("content"));
					key.setTime(rs.getString("time"));
//					key.setPosition(rs.getString("position"));
//					key.setSex(rs.getString("sex"));
//					key.setArea(rs.getString("area"));
//					key.setToken(rs.getString("token"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
