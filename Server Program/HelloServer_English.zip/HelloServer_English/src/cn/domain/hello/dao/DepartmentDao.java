package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.DepartiBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.DepartmentBean;

public class DepartmentDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<DepartmentBean> getUserByName(int src)
	{
		// String C=null;
		DepartmentBean department = null;
		List<DepartmentBean> keys = new ArrayList<DepartmentBean>();
		try
		{
			conn = super.openDB();

			if (conn != null)
			{
				String sql = "select * from department where depid = ?";
				prepStmt = conn.prepareStatement(sql);

				prepStmt.setInt(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// department = new DepartmentBean(rs.getInt(1),
				// rs.getString(2));
				// }
				while (rs.next() && rs.getRow() <= 10)
				{
					DepartmentBean key = new DepartmentBean();
					key.setDepid(rs.getInt("depid"));
					key.setName(rs.getString("name"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
