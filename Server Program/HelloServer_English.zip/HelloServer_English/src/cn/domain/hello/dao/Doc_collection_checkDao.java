package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.DocBean;
import cn.domain.hello.bean.DocCollectionBean;

public class Doc_collection_checkDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<DocCollectionBean> getUserByName(String src)
	{
		DocCollectionBean docBean = null;
		List<DocCollectionBean> keys = new ArrayList<DocCollectionBean>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select phone from doc_collection where token = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// docBean = new DocBean(rs.getString(1), rs.getString(2),
				// rs.getString(3), rs.getString(4), rs.getString(5),
				// rs.getString(6),
				// rs.getString(7),rs.getString(8),rs.getString(9));
				// }
				while (rs.next() && rs.getRow() <= 10)
				{
					DocCollectionBean key = new DocCollectionBean();
					key.setPhone(rs.getString("phone"));
//					key.setName(rs.getString("name"));
//					key.setHospital(rs.getString("hospital"));
//					key.setDepartment(rs.getString("department"));
//					key.setPosition(rs.getString("position"));
//					key.setSex(rs.getString("sex"));
//					key.setArea(rs.getString("area"));
					//key.setToken(rs.getString("token"));
					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
