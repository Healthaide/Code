package cn.domain.hello.dao;

import java.util.*;
import java.sql.*;

import cn.domain.hello.domain.ViewList;
import cn.domain.hello.tool.Dir;

public class ViewListDao extends BaseDao {
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public ViewList getSDir(List aordlist, int page, int ad) {
		ViewList list = new ViewList();
		List<Dir> vlist = new ArrayList<Dir>();

		try {
			conn = super.openDB();
			if (conn != null) {
				int limit = 10;
				if(aordlist.size() < (page * 10) + limit){
					limit = aordlist.size() - (page * 10);
				}
				
				System.out.println("可获取"+limit+"个数据");
				
				for (int a = page * 10; a < (page * 10) + limit; a++) {
					Dir dir = new Dir();
					int id = -1;
					id = (Integer) aordlist.get(a);
					
					dir.setID(id);
					
					if (0 == ad) {
						String sql = "select name,click from article where id = '" + id + "'";
						prepStmt = conn.prepareStatement(sql);
						rs = prepStmt.executeQuery();
						if (rs.next()) {
							System.out.println("文章id为："+id);
							dir.setName(rs.getString(1));
							dir.setClick(rs.getInt(2));
						}
					} else if (1 == ad) {
						String sql = "select name,click from disease where id = '" + id + "'";
						prepStmt = conn.prepareStatement(sql);
						rs = prepStmt.executeQuery();
						if (rs.next()) {
							System.out.println("疾病id为："+id);
							dir.setName(rs.getString(1));
							dir.setClick(rs.getInt(2));
						}
					}
					vlist.add(dir);
				}
			}
			list.setList(vlist);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
}