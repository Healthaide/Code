package cn.domain.hello.dao;

public class Token_to_phone_new {

	public String Token_to_phone(String str){
		String sc;
		sc=str.substring(0, 11);
		return sc;
	}
	
}
