package cn.domain.hello.dao;

import java.util.*;
import java.sql.*;

import cn.domain.hello.domain.UserSearch;
import cn.domain.hello.tool.IndexT;
import cn.domain.hello.tool.TopN;

public class UserSearchDao extends BaseDao {
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public ResultSet rs1 = null;

	public UserSearch getSWord(String nativeBytes, int stable) {
		HashMap<Integer,String> hash = new HashMap<Integer,String>();
		UserSearch list = new UserSearch();

		String[] keyword = nativeBytes.split("#");
		int lena = keyword.length, a = 0;

		try {
			conn = super.openDB();
			if (conn != null) {
				for (; a < lena; a++) {
					// String sql =
					// "select * from CustomerLogin where loginName = ? and password = ?";
					
					
					String[] sear = keyword[a].split("/");
					
					String sql = "";
					boolean dis = false;
					int tnum = 0;
					if (sear[1].equals("nsym")) {
						sql = "select symid from symptom where name = '" + sear[0] + "'";
					} else if (sear[1].equals("ndis")) {
						sql = "select id from disease where name = '" + sear[0] + "'";
						if(stable == 1){
							dis = true;
						}
					} else if (sear[1].equals("ndep")) {
						sql = "select depid from department where name = '" + sear[0] + "'";
					}	

					
					prepStmt = conn.prepareStatement(sql);
					rs = prepStmt.executeQuery();
					
					while (rs.next()) {
						int id = rs.getInt(1);
						
						System.out.println(sear[0] + "id："+id);
						
						
						if(stable == 0){
							if (sear[1].equals("nsym")) {
								sql = "select s_aid from symarti where s_sid = '" + id + "'";
							} else if (sear[1].equals("ndis")) {
								sql = "select s_aid from disarti where s_disid = '" + id + "'";
							} else if (sear[1].equals("ndep")) {
								sql = "select s_aid from departi where s_depid = '" + id + "'";
							}
						}else if(stable == 1){
							if (sear[1].equals("nsym")) {
								sql = "select s_disid from symdis where s_id = '" + id + "'";
							} else if (sear[1].equals("ndep")) {
								sql = "select s_disid from depdis where s_id = '" + id + "'";
							}
						}
						prepStmt = conn.prepareStatement(sql);
						boolean hadResults = prepStmt.execute();
						while (hadResults) {
	            			ResultSet rs = prepStmt.getResultSet();  
	            			while (rs != null && rs.next()) {
								IndexT indext = new IndexT();
								indext.setAID(rs.getInt(1));
								if(stable == 0){
									sql = "select click from article where id = '" + rs.getInt(1) + "'";
								}else if(stable == 1){
									sql = "select click from disease where id = '" + rs.getInt(1) + "'";
								}
								prepStmt = conn.prepareStatement(sql);
								rs1 = prepStmt.executeQuery();
								if (rs1.next()) {
									indext.setclick(rs1.getInt(1));
								}

								if (!hash.containsKey(indext.getAID())) {
									indext.setrel(1);
									hash.put(indext.getAID(), indext.toString());
								} else {
									indext = new IndexT((String) hash.get(indext.getAID()));
									indext.setrel(indext.getrel() + 1);
									hash.put(indext.getAID(), indext.toString());
								}
								System.out.println("id为:" + indext.getAID());
	            			}
	            			hadResults = prepStmt.getMoreResults(); //检查是否存在更多结果集
	            		}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		List<Integer> l = TopN.topN(100, hash);
		list.setList(l);
		
		return list;
	}

}