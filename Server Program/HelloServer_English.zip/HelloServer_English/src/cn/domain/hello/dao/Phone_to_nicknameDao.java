package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Phone_to_nicknameDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public String nickname=null;
	public String token_to_phone_doc(String token){
		try{
			conn = super.openDB();
			if (conn != null){
				String sql = "select nickname from user where phone=?";
				prepStmt = conn.prepareStatement(sql);

				prepStmt.setString(1, token);
				rs = prepStmt.executeQuery();
				if(rs.next()){
					 nickname = rs.getString(1);
				}
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if (rs != null)
						rs.close();
					if (prepStmt != null)
						prepStmt.close();
					if (conn != null)
						conn.close();
					super.closeDB();
				} catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return nickname;
		}
		
		
				
	
}
