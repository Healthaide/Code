package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import cn.domain.hello.bean.List_articleBean;

public class Find_token_passDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public String getUserByName(String src)
	{
		String C = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select token from tab_user where password = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				if (rs.next())
				{
					C = rs.getString(1);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return C;
	}
}
