package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import cn.domain.hello.bean.CommentBean;

public class CodeSelectDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public String S;

	public String getCodeSelect(String src)
	{
		// CommentBean commentBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select code from user where phone = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				if (rs.next())
					S = rs.getString(1);
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return S;
	}
}
