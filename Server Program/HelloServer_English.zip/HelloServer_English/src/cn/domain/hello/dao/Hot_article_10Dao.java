package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.domain.hello.bean.ArticleBean;
import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.List_articleBean;

public class Hot_article_10Dao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	// List<String> list = new ArrayList();
	public List<ArticleBean> getUserByName(String src)
	{
		ArticleBean commentBean = null;
		List<ArticleBean> keys = new ArrayList<ArticleBean>();
		// Map<String,Object>map= new HashMap<String,String>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				//String sql = "select * from tab_list_article,tab_user where tab_user.token=? is not null order by browse desc";
				String sql = "select *from article left join tab_user on article.state=tab_user.state where tab_user.token=? ORDER BY click DESC";
				prepStmt = conn.prepareStatement(sql);
				// String src1=src+"";
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();

				// ResultSetMetaData resultSetMetaDate = rs.getMetaData();
				// int columnCount = resultSetMetaDate.getColumnCount();
				// while (rs.next()) {
				// commentBean = new CommentBean(rs.getString(1),
				// rs.getString(2), rs.getString(3), rs.getString(4),
				// rs.getInt(5),rs.getString(6));
				// }

				while (rs.next() && rs.getRow() <= 10)
				{
					ArticleBean key = new ArticleBean();
					key.setName(rs.getString("name"));
					key.setKind(rs.getString("kind"));
					key.setClick(rs.getInt("click"));
					key.setId(rs.getInt("id"));
//					key.setToken(rs.getString("token"));
					key.setDate(rs.getString("date"));
					keys.add(key);
				}
				// CommentBean cb = new CommentBean();
				// cb.setHead(rs.getString(1));
				// cb.setContent(rs.getString(2));
				// cb.setPhone(rs.getString(3));
				// cb.setToken(rs.getString(4));
				// cb.setId(rs.getInt(5));
				// cb.setDate(rs.getString(6));
				// list.add(cb);
				//
				// }
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
