package cn.domain.hello.dao;

public class JdeBean
{

	private String content;
	private String time;
	public JdeBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public JdeBean(String content, String time)
	{
		super();
		this.content = content;
		this.time = time;
	}
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public String getTime()
	{
		return time;
	}
	public void setTime(String time)
	{
		this.time = time;
	}

	
}
