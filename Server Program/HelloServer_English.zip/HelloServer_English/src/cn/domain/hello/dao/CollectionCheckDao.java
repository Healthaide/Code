package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.domain.hello.bean.ArticleBean;
import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.SearchBean;

public class CollectionCheckDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public int S;
	
	// List<String> list = new ArrayList();
	public int getUserByName(String src,String src1)
	{
		//SearchBean commentBean = null;
		//List<SearchBean> keys = new ArrayList<SearchBean>();
		// Map<String,Object>map= new HashMap<String,String>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				//String tt="%"+src+"%";
				//String sql = "select * from tab_list_article,tab_user where tab_user.token=? is not null order by browse desc";
//				String sql = "select *from news where title like '"+tt+"'";
				String sql = "select count(*) from article_collection where phone=? and url=? ";
				//int a=0;
				prepStmt = conn.prepareStatement(sql);
				// String src1=src+"";
				prepStmt.setString(1, src);
				prepStmt.setString(2, src1);
				rs = prepStmt.executeQuery();
				if(rs.next())
					S = rs.getInt(1);
				// ResultSetMetaData resultSetMetaDate = rs.getMetaData();
				// int columnCount = resultSetMetaDate.getColumnCount();
				// while (rs.next()) {
				// commentBean = new CommentBean(rs.getString(1),
				// rs.getString(2), rs.getString(3), rs.getString(4),
				// rs.getInt(5),rs.getString(6));
				// }

//				while (rs.next() && rs.getRow() <= 10)
//				{
//					SearchBean key = new SearchBean();
//					key.setTitle(rs.getString("title"));
//					key.setUrl(rs.getString("url"));
//					key.setContent(rs.getString("content"));
//					key.setDate(rs.getString("date"));
////					key.setToken(rs.getString("token"));
//					//key.setDate(rs.getString("date"));
//					keys.add(key);
//				}
//				// CommentBean cb = new CommentBean();
				// cb.setHead(rs.getString(1));
				// cb.setContent(rs.getString(2));
				// cb.setPhone(rs.getString(3));
				// cb.setToken(rs.getString(4));
				// cb.setId(rs.getInt(5));
				// cb.setDate(rs.getString(6));
				// list.add(cb);
				//
				// }
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return S;
	}
}

