package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Token_to_phone extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public String phone=null;
	public String token_to_phone(String token){
		try{
			conn = super.openDB();
			if (conn != null){
				String sql = "select phone from tab_user where token=?";
				prepStmt = conn.prepareStatement(sql);

				prepStmt.setString(1, token);
				rs = prepStmt.executeQuery();
				if(rs.next()){
					 phone = rs.getString(1);
				}
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if (rs != null)
						rs.close();
					if (prepStmt != null)
						prepStmt.close();
					if (conn != null)
						conn.close();
					super.closeDB();
				} catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return phone;
		}
		
		
				
	
}
