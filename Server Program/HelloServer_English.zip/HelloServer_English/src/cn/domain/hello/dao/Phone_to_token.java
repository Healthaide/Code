package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Phone_to_token extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public String head=null;
	public String to_token(String token){
		try{
			conn = super.openDB();
			if (conn != null){
				String sql = "select token from tab_user where phone=?";
				prepStmt = conn.prepareStatement(sql);

				prepStmt.setString(1, token);
				rs = prepStmt.executeQuery();
				if(rs.next()){
					 head = rs.getString(1);
				}
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if (rs != null)
						rs.close();
					if (prepStmt != null)
						prepStmt.close();
					if (conn != null)
						conn.close();
					super.closeDB();
				} catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return head;
		}
		
		
				
	
}
