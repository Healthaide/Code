package cn.domain.hello.dao;

public class Key
{

	private String phone;
	private String content;
	private int id;
	private String date;
	public Key()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Key(String phone, String content, int id, String date)
	{
		super();
		this.phone = phone;
		this.content = content;
		this.id = id;
		this.date = date;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}

	
}
