package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cn.domain.hello.bean.CmtBean;
import cn.domain.hello.bean.CommentBean;

public class Id_to_phone_comment extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public CmtBean getUserByName(String src)
	{
		CmtBean cmtBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select content,date,token from tab_comment where phone = ?";
				prepStmt = conn.prepareStatement(sql);
				// String src1=src+"";
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				if (rs.next())
				{
					cmtBean = new CmtBean(
							rs.getString(1), rs.getString(2), 
							rs.getString(3));
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return cmtBean;
	}
}
