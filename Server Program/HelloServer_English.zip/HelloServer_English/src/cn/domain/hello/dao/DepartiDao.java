package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.DepartiBean;

public class DepartiDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<DepartiBean> getUserByName(int src)
	{
		// String C=null;
		DepartiBean departi = null;
		List<DepartiBean> keys = new ArrayList<DepartiBean>();
		try
		{
			conn = super.openDB();

			if (conn != null)
			{
				String sql = "select * from departi where s_depid = ?";
				prepStmt = conn.prepareStatement(sql);

				prepStmt.setInt(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// departi = new DepartiBean(rs.getInt(1), rs.getInt(2));
				// }
				while (rs.next() && rs.getRow() <= 10)
				{
					DepartiBean key = new DepartiBean();
					key.setS_depid(rs.getInt("s_depid"));
					key.setS_aid(rs.getInt("s_aid"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
