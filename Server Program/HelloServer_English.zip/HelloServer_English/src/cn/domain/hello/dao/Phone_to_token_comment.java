package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cn.domain.hello.bean.CmtBean;
import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.JudgeBean;

public class Phone_to_token_comment extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public JdeBean getUserByName(String src)
	{
		JdeBean jdeBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select content,time from tab_doc_comment where token = ?";
				prepStmt = conn.prepareStatement(sql);
				// String src1=src+"";
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				if (rs.next())
				{
					jdeBean = new JdeBean(
							rs.getString(1), rs.getString(2));
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jdeBean;
	}
}
