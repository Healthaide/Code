package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import cn.domain.hello.bean.CommentBean;

public class Get_gsk_num extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public int S;
	public String str2;

	public int getUserByName(String src)
	{
		// CommentBean commentBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select count(*) from tab_doc where department = ?";
				prepStmt = conn.prepareStatement(sql);
//				if(src.equals("Gynaecology")){
//					str2="妇科";
//				}else if(src.equals("Andrology")){
//					str2="男科";
//				}else if(src.equals("Surgery")){
//					str2="外科";
//				}else if(src.equals("Internal")){
//					str2="内科";
//				}else if(src.equals("Skin")){
//					str2="皮肤科";
//				}else if(src.equals("Orthopedics")){
//					str2="骨伤科";
//				}else if(src.equals("Psychosocial")){
//					str2="精神心理科";
//				}else if(src.equals("Oral")){
//					str2="口腔颌面科";
//				}else if(src.equals("Ophthalmology")){
//					str2="眼科";
//				}else if(src.equals("E.N.T.")){
//					str2="耳鼻咽喉科";
//				}else if(src.equals("Nutriology")){
//					str2="营养科";
//				}
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				if (rs.next())
					S = rs.getInt(1);
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return S;
	}
}
