package cn.domain.hello.dao;

import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import cn.domain.hello.bean.ArticleBean;

public class ArticleDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	// public PreparedStatement prepStmt2 = null;
	public ResultSet rs = null;

	// public int rs2;

	public List<ArticleBean> getUserByName(int src)
	{
		// String C=null;
		ArticleBean article = null;
		// ArrayList<String> list = new ArrayList();
		List<ArticleBean> keys = new ArrayList<ArticleBean>();
		try
		{
			conn = super.openDB();

			if (conn != null)
			{

				String sql = "select * from article where id = ?  ";
				// String sql2 = "update article set click= click+1";
				// prepStmt2 = conn.prepareStatement(sql2);
				// String src1=src+"";
				// prepStmt2.setString(1, src1);
				// rs2 = prepStmt2.executeUpdate();

				prepStmt = conn.prepareStatement(sql);
				prepStmt.setInt(1, src);
				rs = prepStmt.executeQuery();
				// ResultSetMetaData resultSetMetaDate = rs.getMetaData();
				// int columnCount = resultSetMetaDate.getColumnCount();
				if (rs.next())
				{
//					article = new ArticleBean(rs.getInt("id"), rs.getString("name"),
//							rs.getString("source"), rs.getString("date"), rs.getString("kind"),
//							rs.getString("article"), rs.getInt("click"),rs.getInt("num"));
					ArticleBean key = new ArticleBean();
					key.setId(rs.getInt("id"));
					key.setName(rs.getString("name"));
					key.setSource(rs.getString("source"));
					key.setDate(rs.getString("date"));
					key.setArticle(rs.getString("article"));
					key.setKind(rs.getString("kind"));
					key.setClick(rs.getInt("click"));

					keys.add(key);
				}
				// while(rs.next()){
				// for(int i=1;i<=columnCount;i++){
				// list.add(rs.getString(i));
				// }
				// }
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();

				// if (prepStmt2 != null)
				// prepStmt2.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
