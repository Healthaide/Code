package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Token_to_head_doc extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public String head=null;
	public String to_head(String token){
		try{
			conn = super.openDB();
			if (conn != null){
				String sql = "select head from tab_doc where token=?";
				prepStmt = conn.prepareStatement(sql);

				prepStmt.setString(1, token);
				rs = prepStmt.executeQuery();
				if(rs.next()){
					 head = rs.getString(1);
				}
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if (rs != null)
						rs.close();
					if (prepStmt != null)
						prepStmt.close();
					if (conn != null)
						conn.close();
					super.closeDB();
				} catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return head;
		}
		
		
				
	
}
