package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.DepartmentBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.DepdisBean;

public class DepdisDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<DepdisBean> getUserByName(int src)
	{
		// String C=null;
		DepdisBean depdis = null;
		List<DepdisBean> keys = new ArrayList<DepdisBean>();
		try
		{
			conn = super.openDB();

			if (conn != null)
			{
				String sql = "select * from depdis where s_id = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setInt(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// depdis = new DepdisBean(rs.getInt(1), rs.getString(2));
				// }
				while (rs.next() && rs.getRow() <= 10)
				{
					DepdisBean key = new DepdisBean();
					key.setS_id(rs.getInt("s_id"));
					key.setS_disid(rs.getInt("s_disid"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
