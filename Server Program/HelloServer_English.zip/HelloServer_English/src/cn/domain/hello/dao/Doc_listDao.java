package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.DiseaseBean;
import cn.domain.hello.bean.DocBean;

public class Doc_listDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public static String s2;

	public List<DocBean> getUserByName(String src)
	{
		DocBean docBean = null;
		List<DocBean> keys = new ArrayList<DocBean>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select * from tab_doc,tab_user where tab_user.token=? ";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// docBean = new DocBean(rs.getString(1), rs.getString(2),
				// rs.getString(3), rs.getString(4), rs.getString(5),
				// rs.getString(6),
				// rs.getString(7),rs.getString(8),rs.getString(9));
				// }
				while (rs.next() )
				{
					DocBean key = new DocBean();
					key.setPhone(rs.getString("phone"));
					//replaceString(rs.getString("head"));
					key.setHead(rs.getString("head"));
					key.setName(rs.getString("name"));
					key.setHospital(rs.getString("hospital"));
					key.setDepartment(rs.getString("department"));
					key.setPosition(rs.getString("position"));
					key.setSex(rs.getString("sex"));
					key.setArea(rs.getString("area"));
					key.setToken(rs.getString("token"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
	public static void replaceString(String s){
		String s1 = "HelloServer_English";
		String s1_1 = "HelloServer";
		
		String b = s.substring(s1_1.length(), s.length());
		s2 = s1+b;
	}
}
