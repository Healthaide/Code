package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.domain.hello.bean.CommentBean;
import cn.domain.hello.bean.Doc_commentBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.TopicCommentBean;

public class Gettopic_comment_10Dao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	// List<String> list = new ArrayList();
	public List<TopicCommentBean> getUserByName(int src)
	{
		TopicCommentBean commentBean = null;
		List<TopicCommentBean> keys = new ArrayList<TopicCommentBean>();
		// Map<String,Object>map= new HashMap<String,String>();
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				String sql = "select * from tab_topic_comment where id = ? order by time desc";
				prepStmt = conn.prepareStatement(sql);
				// String src1=src+"";
				prepStmt.setInt(1, src);
				rs = prepStmt.executeQuery();

				// ResultSetMetaData resultSetMetaDate = rs.getMetaData();
				// int columnCount = resultSetMetaDate.getColumnCount();
				// while (rs.next()) {
				// commentBean = new CommentBean(rs.getString(1),
				// rs.getString(2), rs.getString(3), rs.getString(4),
				// rs.getInt(5),rs.getString(6));
				// }
				// int count=keys.size();
				// List<Key> num = new ArrayList<Key>();
				while (rs.next())
				{
					TopicCommentBean key = new TopicCommentBean();
					//key.setHead(rs.getString("head"));
					key.setId(rs.getInt("id"));
					key.setPhone(rs.getString("phone"));
					key.setContent(rs.getString("content"));
					//key.setId(rs.getInt("id"));
					key.setTime(rs.getString("time"));
				
					keys.add(key);
				}
				// CommentBean cb = new CommentBean();
				// cb.setHead(rs.getString(1));
				// cb.setContent(rs.getString(2));
				// cb.setPhone(rs.getString(3));
				// cb.setToken(rs.getString(4));
				// cb.setId(rs.getInt(5));
				// cb.setDate(rs.getString(6));
				// list.add(cb);
				//
				// }
				// for(int i=0;i<num.size();i++){
				// keys.add(num.get(i));
				// }
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
