package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import cn.domain.hello.bean.RegistBean;

public class Check_id extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public int getUserByName(String id)
	{
		RegistBean registBean = null;
		int b=0;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				int a = Integer.parseInt(id);
				//String sql = "select * from tab_user where phone = ?";
				String sql = "select * from article where id = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, id);
				rs = prepStmt.executeQuery();
				if (rs.next() && rs != null)
				{
					b=1;
				} else
				{
					b=0;
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return b;
	}
}
