package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.domain.hello.bean.DepdisBean;
import cn.domain.hello.bean.List_articleBean;
import cn.domain.hello.bean.DisartiBean;

public class DisartiDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;

	public List<DisartiBean> getUserByName(String src)
	{
		// String C=null;
		DisartiBean disarti = null;
		List<DisartiBean> keys = new ArrayList<DisartiBean>();
		try
		{
			conn = super.openDB();

			if (conn != null)
			{
				String sql = "select * from disarti where s_name = ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				// if (rs.next()) {
				// disarti = new DisartiBean(rs.getString(1), rs.getInt(2));
				// }
				while (rs.next() && rs.getRow() <= 10)
				{
					DisartiBean key = new DisartiBean();
					key.setS_aid(rs.getInt("s_aid"));
					key.setS_disid(rs.getInt("s_disid"));

					keys.add(key);
				}
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return keys;
	}
}
