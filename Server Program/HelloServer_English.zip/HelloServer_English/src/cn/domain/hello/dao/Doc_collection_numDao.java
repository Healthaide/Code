package cn.domain.hello.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import cn.domain.hello.bean.CommentBean;

public class Doc_collection_numDao extends BaseDao
{
	public PreparedStatement prepStmt = null;
	public ResultSet rs = null;
	public int S;

	public int getUserByName(String src)
	{
		// CommentBean commentBean = null;
		try
		{
			conn = super.openDB();
			if (conn != null)
			{
				//String sql = "select count(*) from doc_collection where token like ?";
				String sql = "select count(*) from doc_collection where token like ?";
				prepStmt = conn.prepareStatement(sql);
				prepStmt.setString(1, src);
				rs = prepStmt.executeQuery();
				if(rs.next())
					S = rs.getInt(1);
			}
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
				if (prepStmt != null)
					prepStmt.close();
				if (conn != null)
					conn.close();
				super.closeDB();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return S;
	}
}
