package cn.domain.hello.config;

public class Config
{

	public static final String dbServerIp = "localhost";// 锟斤拷菘锟斤拷锟斤拷锟斤拷IP
	public static final String dbUser = "root";// 锟斤拷菘锟斤拷没锟斤拷锟�
	public static final String dbPwd = "root";// 锟斤拷菘锟斤拷锟斤拷锟�
	public static final String dbPort = "3306";// 锟斤拷菘锟剿口猴拷
	public static final String dbName = "openfire";// 锟斤拷菘锟斤拷锟�
	public static final String dbEncoding = "UTF-8";// 锟斤拷菘锟斤拷锟斤拷
}
