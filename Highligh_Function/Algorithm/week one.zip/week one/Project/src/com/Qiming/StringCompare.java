package com.Qiming;

public class StringCompare {
public static void main(String[] args) {
	String A = "1";
	String B = "1";
	if(A==B) {
		System.out.printf("True");
	}
	else {
		System.out.println("Faluse");
	}
}
}
