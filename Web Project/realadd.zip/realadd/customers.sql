/*
MySQL Data Transfer
Source Host: localhost
Source Database: customers
Target Host: localhost
Target Database: customers
Date: 2018/3/4 21:07:28
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for article
-- ----------------------------
CREATE TABLE `article` (
  `Cid` varchar(255) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Source` varchar(255) DEFAULT NULL,
  `Kind` varchar(255) DEFAULT NULL,
  `Article` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for comment1
-- ----------------------------
CREATE TABLE `comment1` (
  `shijian` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for doctor2
-- ----------------------------
CREATE TABLE `doctor2` (
  `Did` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Hospital` varchar(255) DEFAULT NULL,
  `Department` varchar(255) DEFAULT NULL,
  `Position` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for message
-- ----------------------------
CREATE TABLE `message` (
  `Yid` varchar(255) DEFAULT NULL,
  `Messagearea` varchar(255) DEFAULT NULL,
  `Messagetime` varchar(255) DEFAULT NULL,
  `Messagearticle` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for t_users
-- ----------------------------
CREATE TABLE `t_users` (
  `Username` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Age` varchar(255) DEFAULT NULL,
  `Gender` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for topic
-- ----------------------------
CREATE TABLE `topic` (
  `Xid` varchar(255) DEFAULT NULL,
  `Topicname` varchar(255) DEFAULT NULL,
  `Topictime` varchar(255) DEFAULT NULL,
  `Topicarticle` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `article` VALUES ('1212', '1212', '1212', '1212', '1212', '1212');
INSERT INTO `article` VALUES ('0EE80E1AA8BB46B5BCFB766B3A7F1D1E', '11', '11', '1', '1', '1');
INSERT INTO `article` VALUES ('8F2258407FE84E60BFFBA2EBC3AE3C85', '11', '11', '11', '11', '11');
INSERT INTO `article` VALUES ('CA65607FC0024D0893CA47ADBF31A350', '11', '11', '11', '11', '11');
INSERT INTO `article` VALUES ('57BC8CFC021A4AA1985FCEE19EFACE17', '11', '11', '11', '11', '11');
INSERT INTO `article` VALUES ('92BD5FECA3004B86A08E8C756C2880F0', '11', '11', '11', '11', '11');
INSERT INTO `article` VALUES ('867CFF37C3954664BB0C34500F7A4C75', '77', '77', '77', '77', '77');
INSERT INTO `article` VALUES ('43E70FD117414C60AAFBD1E52E3308D3', '77', '77', '77', '77', '77');
INSERT INTO `article` VALUES ('18FCD6943F954C65AD6D8F5D4AB9EB62', '9', '9', '9', '9', '9');
INSERT INTO `article` VALUES ('5C4F79396FD6442D979E7B2A61909BF1', '00', '0', '0', '0', '0');
INSERT INTO `article` VALUES ('255CE991934148A2BB4E793D867E50D1', '7', '7', '7', '7', '7');
INSERT INTO `article` VALUES ('582D08EF7D944243BC9F62076338B848', '66', '66', '66', '66', '66');
INSERT INTO `article` VALUES ('4D28CF92B0F542CBA8EF7FB91EF24AD2', '00', '0', '0', '0', '0');
INSERT INTO `comment1` VALUES ('1212');
INSERT INTO `doctor2` VALUES ('19A8BF57C4E54570BD291997FCAD8ECD', '22', '22', '22', '22', '22', '22');
INSERT INTO `doctor2` VALUES ('FB26B1A468A14EBCA3477B7CDF9CF955', '99', '99', '99', '99', '99', '99');
INSERT INTO `doctor2` VALUES ('C326875449FA49FEB6787AF7482DC53E', '', '', '', '', '', '');
INSERT INTO `doctor2` VALUES ('4969C5BF414B433A8B172DE3771BB746', '', '', '', '', '', '');
INSERT INTO `message` VALUES ('1212', '1212', '1212', '121');
INSERT INTO `t_users` VALUES ('1001', '1001', '20', 'male');
INSERT INTO `topic` VALUES ('121', '1212', '1212', '1212');
