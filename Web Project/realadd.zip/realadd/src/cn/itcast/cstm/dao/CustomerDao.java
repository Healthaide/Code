package cn.itcast.cstm.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.itcast.cstm.domain.Customer;
import cn.itcast.cstm.domain.PageBean;
import cn.itcast.jdbc.TxQueryRunner;

public class CustomerDao {
	
	private QueryRunner qr=new TxQueryRunner();
	public void add(Customer c){
		try{
		String sql="insert into article values(?,?,?,?,?,?)";
		Object[] params={c.getCid(),c.getTitle(),c.getDate(),c.getSource(),c.getKind(),c.getArticle()};
		qr.update(sql,params);
		
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
	}
	public void addt(Customer c){
		try{
		String sql="insert into topic values(?,?,?,?)";
		Object[] params={c.getXid(),c.getTopicname(),c.getTopictime(),c.getTopicarticle()};
		qr.update(sql,params);
		
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
	}
	public void addm(Customer c){
		try{
		String sql="insert into message values(?,?,?,?)";
		Object[] params={c.getYid(),c.getMessagearea(),c.getMessagetime(),c.getMessagearticle()};
		qr.update(sql,params);
		
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
	}
	public void addd(Customer c){
		try{
			String sql="insert into doctor2 values(?,?,?,?,?,?,?)";
			Object[] params={c.getDid(),c.getName(),c.getHospital(),c.getDepartment(),c.getPosition(),c.getPhone(),c.getPassword()};
			qr.update(sql,params);
			
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
		}
		
	
	
	public PageBean<Customer> findAll(int pc, int ps){
		try{
/*
 *  他需要创建PageBean对象
 *  设置pb的pc和ps
 *  得到tr  设置给pb
 *  得到beanList 设置给pb
 *  返回pb
 *  private int pc;//当前页码 page code
//private int tp;//总页数 totoa pages
private int tr;//总记录数
private int ps;//每页记录数
private List<T>beanList;//当前页记录
 */
PageBean<Customer> pb=new PageBean<Customer>();
pb.setPc(pc);
pb.setPs(ps);
/*
   的到tr
   
 */
	String sql="select count(*) from article";
	Number num=(Number)qr.query(sql, new ScalarHandler());
	int tr=num.intValue();
	pb.setTr(tr);
	/*
	 * 得到beanlist
	 */
	sql="select* from article order by date limit ?,?";
	List<Customer> beanList=qr.query(sql, 
			new BeanListHandler<Customer>(Customer.class),
			(pc-1)*ps,ps);
	pb.setBeanList(beanList);
	return pb;
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
	}
	public PageBean<Customer> findAllc(int pc, int ps){
		try{
/*
 *  他需要创建PageBean对象
 *  设置pb的pc和ps
 *  得到tr  设置给pb
 *  得到beanList 设置给pb
 *  返回pb
 *  private int pc;//当前页码 page code
//private int tp;//总页数 totoa pages
private int tr;//总记录数
private int ps;//每页记录数
private List<T>beanList;//当前页记录
 */
PageBean<Customer> pb=new PageBean<Customer>();
pb.setPc(pc);
pb.setPs(ps);
/*
   的到tr
   
 */
	String sql="select count(*) from comment1";
	Number num=(Number)qr.query(sql, new ScalarHandler());
	int tr=num.intValue();
	pb.setTr(tr);
	/*
	 * 得到beanlist
	 */
	sql="select* from comment1 order by shijian desc limit ?,?";
	List<Customer> beanList=qr.query(sql, 
			new BeanListHandler<Customer>(Customer.class),
			(pc-1)*ps,ps);
	pb.setBeanList(beanList);
	return pb;
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
	}
	public PageBean<Customer> findAlld(int pc, int ps){
		try{
/*
 *  他需要创建PageBean对象
 *  设置pb的pc和ps
 *  得到tr  设置给pb
 *  得到beanList 设置给pb
 *  返回pb
 *  private int pc;//当前页码 page code
//private int tp;//总页数 totoa pages
private int tr;//总记录数
private int ps;//每页记录数
private List<T>beanList;//当前页记录
 */
PageBean<Customer> pb=new PageBean<Customer>();
pb.setPc(pc);
pb.setPs(ps);
/*
   的到tr
   
 */
	String sql="select count(*) from doctor2";
	Number num=(Number)qr.query(sql, new ScalarHandler());
	int tr=num.intValue();
	pb.setTr(tr);
	/*
	 * 得到beanlist
	 */
	sql="select* from doctor2 limit ?,?";
	List<Customer> beanList=qr.query(sql, 
			new BeanListHandler<Customer>(Customer.class),
			(pc-1)*ps,ps);
	pb.setBeanList(beanList);
	return pb;
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
	}
//public List<Customer> findAlld(){
// 	try{
//		String sql="select*from doctor2";
//	return 	qr.query(sql, new BeanListHandler<Customer>(Customer.class));
//
//		
//	}catch(SQLException e){
//		throw new RuntimeException(e);
//	}
//	}

	


	public Customer load(String cid) {
		try{
		
		String sql="select*from article where cid=?";
		return qr.query(sql, new BeanHandler<Customer>(Customer.class),cid);
		}catch(SQLException e){
			throw new RuntimeException(e);
			
		}
	}
//		
//		
//		
//		
//		
//		
//		
//		
//		
//	}
/*
 * 编辑客户
 */
	public void edit(Customer c) {
		try{
	String sql="update article set title=?,date=?,source=?,kind=?,article=?where cid=? ";
	Object[] params={c.getTitle(),c.getDate(),c.getSource(),c.getKind(),c.getArticle(),c.getCid()};
			qr.update(sql, params);
		} catch(SQLException e)	{
		throw new RuntimeException(e);
	}
	}
	
	public void delete(String cid) {
		String sql = "delete from article where cid=?";
		Object[] params = {cid};
		try {
			qr.update(sql, params);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public PageBean<Customer> query(Customer criteria, int pc, int ps) {
		try {
			/*
			 * 1. 创建PageBean对象　
			 * 2. 设置已有的属性，pc和ps
			 * 3. 得到tr
			 * 4. 得到beanList
			 */
			/*
			 * 创建pb，设置已有属性
			 */
			PageBean<Customer> pb = new PageBean<Customer>();
			pb.setPc(pc);
			pb.setPs(ps);
			
			/*
			 * 得到tr
			 */
			
			/*
			 * 1. 给出一个sql语句前半部
			 */
			StringBuilder cntSql = new StringBuilder("select count(*) from article");
			StringBuilder whereSql = new StringBuilder(" where 1=1");
			/*
			 * 2. 判断条件，完成向sql中追加where子句
			 */
			/*
			 * 3. 创建一个ArrayList，用来装载参数值
			 */
			List<Object> params = new ArrayList<Object>();
			String title = criteria.getTitle();
			if(title != null && !title.trim().isEmpty()) {
				whereSql.append(" and title like ?");
				params.add("%" + title + "%");
			}
			
			
			
			/*
			 * select count(*) .. + where子句
			 * 执行之
			 */
			Number num = (Number)qr.query(cntSql.append(whereSql).toString(), 
					new ScalarHandler(), params.toArray());
			int tr = num.intValue();
			pb.setTr(tr);
			
			/*
			 * 得到beanList
			 */
			StringBuilder sql = new StringBuilder("select * from article");
			// 我们查询beanList这一步，还需要给出limit子句
			StringBuilder limitSql = new StringBuilder(" limit ?,?");
			// params中需要给出limit后两个问号对应的值
			params.add((pc-1)*ps);
			params.add(ps);
			// 执行之
			List<Customer> beanList = qr.query(sql.append(whereSql).append(limitSql).toString(), 
					new BeanListHandler<Customer>(Customer.class), 
					params.toArray());
			pb.setBeanList(beanList);
			
			return pb;
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	public PageBean<Customer> query1(Customer criteria, int pc, int ps) {
		try {
			/*
			 * 1. 创建PageBean对象　
			 * 2. 设置已有的属性，pc和ps
			 * 3. 得到tr
			 * 4. 得到beanList
			 */
			/*
			 * 创建pb，设置已有属性
			 */
			PageBean<Customer> pb = new PageBean<Customer>();
			pb.setPc(pc);
			pb.setPs(ps);
			
			/*
			 * 得到tr
			 */
			
			/*
			 * 1. 给出一个sql语句前半部
			 */
			StringBuilder cntSql = new StringBuilder("select count(*) from comment1");
			StringBuilder whereSql = new StringBuilder(" where 1=1");
			/*
			 * 2. 判断条件，完成向sql中追加where子句
			 */
			/*
			 * 3. 创建一个ArrayList，用来装载参数值
			 */
			List<Object> params = new ArrayList<Object>();
			String aid = criteria.getAid();
			if(aid != null && !aid.trim().isEmpty()) {
				whereSql.append(" and aid like ?");
				params.add("%" + aid + "%");
			}	
			
			
			
			/*
			 * select count(*) .. + where子句
			 * 执行之
			 */
			Number num = (Number)qr.query(cntSql.append(whereSql).toString(), 
					new ScalarHandler(), params.toArray());
			int tr = num.intValue();
			pb.setTr(tr);
			
			/*
			 * 得到beanList
			 */
			StringBuilder sql = new StringBuilder("select * from comment1");
			// 我们查询beanList这一步，还需要给出limit子句
			StringBuilder limitSql = new StringBuilder(" limit ?,?");
			// params中需要给出limit后两个问号对应的值
			params.add((pc-1)*ps);
			params.add(ps);
			// 执行之
			List<Customer> beanList = qr.query(sql.append(whereSql).append(limitSql).toString(), 
					new BeanListHandler<Customer>(Customer.class), 
					params.toArray());
			pb.setBeanList(beanList);
			
			return pb;
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}	
	public PageBean<Customer> query2(Customer criteria, int pc, int ps) {
		try {
			/*
			 * 1. 创建PageBean对象　
			 * 2. 设置已有的属性，pc和ps
			 * 3. 得到tr
			 * 4. 得到beanList
			 */
			/*
			 * 创建pb，设置已有属性
			 */
			PageBean<Customer> pb = new PageBean<Customer>();
			pb.setPc(pc);
			pb.setPs(ps);
			
			/*
			 * 得到tr
			 */
			
			/*
			 * 1. 给出一个sql语句前半部
			 */
			StringBuilder cntSql = new StringBuilder("select count(*) from doctor2");
			StringBuilder whereSql = new StringBuilder(" where 1=1");
			/*
			 * 2. 判断条件，完成向sql中追加where子句
			 */
			/*
			 * 3. 创建一个ArrayList，用来装载参数值
			 */
			List<Object> params = new ArrayList<Object>();
			String name = criteria.getName();	
			if(name != null && !name.trim().isEmpty()) {
				whereSql.append(" and name like ?");
				params.add("%" + name + "%");
			}	
			
			
			
			/*
			 * select count(*) .. + where子句
			 * 执行之
			 */
			Number num = (Number)qr.query(cntSql.append(whereSql).toString(), 
					new ScalarHandler(), params.toArray());
			int tr = num.intValue();
			pb.setTr(tr);
			
			/*
			 * 得到beanList
			 */
			StringBuilder sql = new StringBuilder("select * from doctor2");
			// 我们查询beanList这一步，还需要给出limit子句
			StringBuilder limitSql = new StringBuilder(" limit ?,?");
			// params中需要给出limit后两个问号对应的值
			params.add((pc-1)*ps);
			params.add(ps);
			// 执行之
			List<Customer> beanList = qr.query(sql.append(whereSql).append(limitSql).toString(), 
					new BeanListHandler<Customer>(Customer.class), 
					params.toArray());
			pb.setBeanList(beanList);
			
			return pb;
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}	
}
