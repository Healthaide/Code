package cn.itcast.cstm.service;

import java.util.List;

import cn.itcast.cstm.dao.CustomerDao;
import cn.itcast.cstm.domain.Customer;
import cn.itcast.cstm.domain.PageBean;

public class CustomerService {
private CustomerDao customerDao=new CustomerDao();
public void add(Customer c){
	customerDao.add(c);
}
public void addt(Customer c){
	customerDao.addt(c);
}
public void addm(Customer c){
	customerDao.addm(c);
}
public void addd(Customer c){
	customerDao.addd(c);
}

// public List<Customer> findAlld(int p){
// 	return customerDao.findAlld();
//}

public PageBean<Customer> findAlld(int pc,int ps){
	return customerDao.findAlld(pc,ps);
}
public PageBean<Customer> findAllc(int pc,int ps){
	return customerDao.findAllc(pc,ps);
}
public PageBean<Customer> findAll(int pc,int ps){
	return customerDao.findAll(pc,ps);
}

public Customer load(String cid) {
	  
	return customerDao.load(cid);
}
/*
 * 
 */
public void edit(Customer c) {
customerDao.edit(c);
}

public void delete(String cid){
	
    customerDao.delete(cid);
}
public PageBean<Customer> query(Customer criteria, int pc, int ps) {
		return customerDao.query(criteria, pc, ps);
	}
public PageBean<Customer> query1(Customer criteria, int pc, int ps) {
	return customerDao.query1(criteria, pc, ps);
}
public PageBean<Customer> query2(Customer criteria, int pc, int ps) {
	return customerDao.query2(criteria, pc, ps);
}
}

