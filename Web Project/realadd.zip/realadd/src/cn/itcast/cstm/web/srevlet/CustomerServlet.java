package cn.itcast.cstm.web.srevlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.cstm.domain.Customer;
import cn.itcast.cstm.domain.PageBean;
import cn.itcast.cstm.service.CustomerService;
import cn.itcast.servlet.BaseServlet;
import cn.itcast.usermng.domain.User;
import cn.itcast.usermng.service.UserException;
import cn.itcast.usermng.service.UserService;
import cn.itcast.utils.CommonUtils;

public class CustomerServlet extends BaseServlet {

	private CustomerService customerService=new CustomerService();
	
	
	
	public String add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Customer c= CommonUtils.toBean(request.getParameterMap(), Customer.class);
		c.setCid(CommonUtils.uuid());
		customerService.add(c);
		request.setAttribute("msg","发布成功");
		return "f:/editors.jsp";
		
	}
	public String addt(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Customer c= CommonUtils.toBean(request.getParameterMap(), Customer.class);
		c.setXid(CommonUtils.uuid());
		customerService.addt(c);
		request.setAttribute("msg","授权成功");
		return "f:/doctor1.jsp";
		
	}
	public String addm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Customer c= CommonUtils.toBean(request.getParameterMap(), Customer.class);
		c.setYid(CommonUtils.uuid());
		customerService.addm(c);
		request.setAttribute("msg","授权成功");
		return "f:/doctor1.jsp";
		
	}
	public String addd(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Customer c= CommonUtils.toBean(request.getParameterMap(), Customer.class);
		c.setDid(CommonUtils.uuid());
		customerService.addd(c);
		request.setAttribute("msg","授权成功");
		return "f:/doctor1.jsp";
		
	}
	/*
	 * public String findAlldaddd(HttpServletRequest request, HttpServletResponse response)
	 * throws ServletException, IOException {
		request.setAttribute("msg","success");
		return "f:/msg.jsp";
		
	}
	 */
		
	
//	public String findAll(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		
//		request.setAttribute("cstmList", customerService.findAll());
//		return "f:/article_tables.jsp";
//	
//	}
//public String findAlld(HttpServletRequest request, HttpServletResponse response)
//		throws ServletException, IOException {
//	
//	request.setAttribute("cstmList", customerService.findAlld());
//	return "f:/doctor4.jsp";
//	}
	
	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 获取页面传递的PC 
		 * 给定PS的值
		 * 使用pc和ps调用service方法 得到pageBean 保存到request域 
		 * 转发到listjsp
		 */
	/*
	 * 得到pc
	 * 如果pc参数不存在 说明pc=1
	 * 如果pc参数存在 需要转换成int 类型即可
	 */
		int pc=getPc(request);  //得到pc
		int ps=10;//给定ps的值 每页10行
	PageBean<Customer> pb= 	customerService.findAll(pc,ps);//传递ps pc给service  得到pageBean
	pb.setUrl(getUrl(request));
	request.setAttribute("pb",pb);  //保存到request域中
	return "f:/article_tables.jsp";  // 转发到article页面
	}
		//获取pc
		public int getPc(HttpServletRequest request){
			String value=request.getParameter("pc");
			if(value==null ||value.trim().isEmpty()){
				return 1;
				
			} 
				return Integer.parseInt(value);
		}
		public String findAlld(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			/*
			 * 获取页面传递的PC 
			 * 给定PS的值
			 * 使用pc和ps调用service方法 得到pageBean 保存到request域 
			 * 转发到listjsp
			 */
		/*
		 * 得到pc
		 * 如果pc参数不存在 说明pc=1
		 * 如果pc参数存在 需要转换成int 类型即可
		 */
			int pc=getPc(request);  //得到pc
			int ps=10;//给定ps的值 每页10行
		PageBean<Customer> pb= 	customerService.findAlld(pc, ps);//传递ps pc给service  得到pageBean
		request.setAttribute("pb",pb);  //保存到request域中
		return "f:/doctor4.jsp";  // 转发到article页面
		}
		public String findAllc(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			/*
			 * 获取页面传递的PC 
			 * 给定PS的值
			 * 使用pc和ps调用service方法 得到pageBean 保存到request域 
			 * 转发到listjsp
			 */
		/*
		 * 得到pc
		 * 如果pc参数不存在 说明pc=1
		 * 如果pc参数存在 需要转换成int 类型即可
		 */
			int pc=getPc(request);  //得到pc
			int ps=10;//给定ps的值 每页10行
		PageBean<Customer> pb= 	customerService.findAllc(pc, ps);//传递ps pc给service  得到pageBean
		request.setAttribute("pb",pb);  //保存到request域中
		return "f:/comment.jsp";  // 转发到article页面
		}

//			//获取pc
////			private int getPc(HttpServletRequest request){
////				String value=request.getParameter("pc");
////				if(value==null ||value.trim().isEmpty()){
////					return 1;
////					
////				} 
////					return Integer.parseInt(value);
//			
//	
//	/*
//	 * 按主键查询  
//	 * 1.获取cid
//	   使用cid来调用service方法 得到Customer对象 
//	   把customer保存到request域总
//	   转发到edit.jsp 显示在表单中
//	 */
	public String preEdit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	String cid=request.getParameter("cid");
	Customer cstm=customerService.load(cid);
	request.setAttribute("cstm", cstm);
	
	return "f:/editors1.jsp";
}
	public String edit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 封装表单数据到Customer对象中
		 * 调用service方法完成修改
		 * 保存成功信息到request中
		 * 转发到msg.jsp显示成功信息
		 */
		/*
		 * 封装到了cid到customer对象中
		 */
		Customer c=CommonUtils.toBean(request.getParameterMap(),Customer.class);
		customerService.edit(c);
		request.setAttribute("msg", "success");
		return "f:/msg.jsp";
		
		
		
	}
	public String delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 1. 获取cid
		 * 2. 调用dao完成删除
		 * 3. 保存成功信息到request中
		 * 4. 转发到msg.jsp显示
		 */
		String cid = request.getParameter("cid");
		customerService.delete(cid);
		request.setAttribute("msg", "删除成功！");
		return "f:/11.jsp";
	}
	public String query(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		System.out.println(getUrl(request));
		/*
		 * 0. 把条件封装到Customer对象中
		 * 1. 得到pc
		 * 2. 给定ps
		 * 3. 使用pc和ps，以及条件对象，调用service方法得到PageBean
		 * 4. 把PageBean保存到request域中
		 * 5. 转发到list.jsp
		 */
		// 获取查询条件
		Customer criteria = CommonUtils.toBean(request.getParameterMap(), Customer.class);
		
		/*
		 * 处理GET请求方式编码问题！
		 */
		
		int pc = getPc(request);//得到pc
		int ps = 10;//给定ps的值，第页10行记录
		PageBean<Customer> pb = customerService.query(criteria, pc, ps);
		
		// 得到url，保存到pb中
		pb.setUrl(getUrl(request));
		
		request.setAttribute("pb", pb);
		return "f:/article_tables.jsp";
	}
	public String query1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		System.out.println(getUrl(request));
		/*
		 * 0. 把条件封装到Customer对象中
		 * 1. 得到pc
		 * 2. 给定ps
		 * 3. 使用pc和ps，以及条件对象，调用service方法得到PageBean
		 * 4. 把PageBean保存到request域中
		 * 5. 转发到list.jsp
		 */
		// 获取查询条件
		Customer criteria = CommonUtils.toBean(request.getParameterMap(), Customer.class);
		
		/*
		 * 处理GET请求方式编码问题！
		 */
		
		int pc = getPc(request);//得到pc
		int ps = 10;//给定ps的值，第页10行记录
		PageBean<Customer> pb = customerService.query1(criteria, pc, ps);
		
		// 得到url，保存到pb中
		pb.setUrl(getUrl(request));
		
		request.setAttribute("pb", pb);
		return "f:/comment.jsp";
	}
	public String query2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		System.out.println(getUrl(request));
		/*
		 * 0. 把条件封装到Customer对象中
		 * 1. 得到pc
		 * 2. 给定ps
		 * 3. 使用pc和ps，以及条件对象，调用service方法得到PageBean
		 * 4. 把PageBean保存到request域中
		 * 5. 转发到list.jsp
		 */
		// 获取查询条件
		Customer criteria = CommonUtils.toBean(request.getParameterMap(), Customer.class);
		
		/*
		 * 处理GET请求方式编码问题！
		 */
		
		int pc = getPc(request);//得到pc
		int ps = 10;//给定ps的值，第页10行记录
		PageBean<Customer> pb = customerService.query2(criteria, pc, ps);
		
		// 得到url，保存到pb中
		pb.setUrl(getUrl(request));
		
		request.setAttribute("pb", pb);
		return "f:/doctor4.jsp";
	}
	
	/**
	 * 处理四样
	 * @param criteria
	 * @return
	 * @throws UnsupportedEncodingException 
	 */


	/**
	 * 截取url
	 *   /项目名/Servlet路径?参数字符串
	 * @param request
	 * @return
	 */
	private String getUrl(HttpServletRequest request) {
		String contextPath = request.getContextPath();//获取项目名
		String servletPath = request.getServletPath();//获取servletPath，即/CustomerServlet
		String queryString = request.getQueryString();//获取问号之后的参数部份
		
		//  判断参数部份中是否包含pc这个参数，如果包含，需要截取下去，不要这一部份。
		if(queryString.contains("&pc=")) {
			int index = queryString.lastIndexOf("&pc=");
			queryString = queryString.substring(0, index);
		}
		
		return contextPath + servletPath + "?" + queryString;
	}


	
	public String login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		// 依赖service
		UserService userService = new UserService();
		
		/*
		 * 1. 一句封装
		 */
		User form = CommonUtils.toBean(request.getParameterMap(), User.class);
		/*
		 * 2. 输入校验（略）
		 */
		/*
		 * 3. 调用userService的login()方法，完成业务
		 */
		try {
			User user = userService.login(form);
			/*
			 * 执行到这里，说明登录成功了
			 */
			// 保存当前用户到session中
			request.getSession().setAttribute("session_user", user);
			// 重定向到index.jsp
			return "r:/editors.jsp";
		} catch (UserException e) {
			/*
			 * 执行到这里，说明登录失败
			 * 1. 保存异常信息、form，到reuqest域
			 * 2. 转发到login.jsp
			 */
			request.setAttribute("msg", e.getMessage());
			request.setAttribute("form", form);
			
			return "f:/login.jsp";
		}
	}
	public String quit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		request.getSession().invalidate();
		return "f:/login.jsp";
}
}