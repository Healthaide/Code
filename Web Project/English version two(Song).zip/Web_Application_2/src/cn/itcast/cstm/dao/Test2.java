package cn.itcast.cstm.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Test2 {
    public static String TimeStamp2Date(String timestampString) {
        String formats = "yyyy-MM-dd";
        Long timestamp = Long.parseLong(timestampString) * 1000;
        String date = new SimpleDateFormat(formats, Locale.CHINA).format(new Date(timestamp));
        return date;
    }
    public static void main(String[] args){
    	System.out.println(TimeStamp2Date("1473048265"));
    }
}
