package cn.itcast.cstm.dao;

import org.junit.Test;

import cn.itcast.cstm.domain.Customer;
import cn.itcast.utils.CommonUtils;

public class CustomerTest {
	@Test
public void fun1(){
	CustomerDao dao=new CustomerDao();
	for(int i=0;i<=300;i++){
		Customer c=new Customer();
		c.setCid(CommonUtils.uuid());
	
		dao.add(c);
	}
}
}
