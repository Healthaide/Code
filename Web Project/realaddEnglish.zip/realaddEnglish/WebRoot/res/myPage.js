function exeData(num, type) {loadData(num);loadpage();}     
//exeData函数传入两个参数，然后执行另外两个函数loadData(num)（num是指页码数，如第5页，则num为5）和loadpage（作用见下方）

function loadpage() {
    var myPageCount = parseInt($("#PageCount").val());//总的数据量（如有105组数据）
    var myPageSize = parseInt($("#PageSize").val());//每一页有多少组数据（如一页有10组数据）
    var countindex = myPageCount % myPageSize > 0 ? (myPageCount / myPageSize) + 1 : (myPageCount / myPageSize);//计算总共有多少页（105除以10余5，则总共有11页）
    $("#countindex").val(countindex);//ID为countindex的值为countindex（如上面一行计算所得为11）

    $.jqPaginator('#pagination', {
        totalPages: parseInt($("#countindex").val()),//总页数
        visiblePages: parseInt($("#visiblePages").val()),//可显示的页码数
        currentPage: 1,//现在的页码数，指向第一页
        first: '<li class="first"><a href="javascript:;">首页</a></li>',
        prev: '<li class="prev"><a href="javascript:;"><i class="arrow arrow2"></i>上一页</a></li>',
        next: '<li class="next"><a href="javascript:;">下一页<i class="arrow arrow3"></i></a></li>',
        last: '<li class="last"><a href="javascript:;">末页</a></li>',
        page: '<li class="page"><a href="javascript:;">{{page}}</a></li>',//{{page}}代表当前页
        onPageChange: function (num, type) {    //第二个参数type，表示事件类型，可能的值为:  init：初始化    change：点击页码
            if (type == "change") {             //如果type等于change则执行exeData函数
                exeData(num, type);
            }
        }
    });
}
$(function () {loadData(1);loadpage();});