package com.cooper.healthyaide.tools;

/**
 * Tool for operating strings
 * Created by Cooper-S on 2018/2/10.
 */

public class StringTools {
    //Hide the four digit number in the middle of the user ID
    public static String hiddenNum(String num){
        StringBuffer hidden = new StringBuffer();
        for (int i = 0; i < 11; i++) {
            if (i >= 3 && i <= 7) {
                hidden.append("*");
            }else {
                hidden.append(num.charAt(i));
            }
        }
        return hidden.toString();
    }
    public static String getRealUsername(String account) {
        if (!account.contains("@"))
            return account;
        String[] res = account.split("@");
        String userName = res[0];
        return userName;
    }
}
