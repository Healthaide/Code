package com.cooper.healthyaide.net;

import com.cooper.healthyaide.Config;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class RegisterIdent {
    public RegisterIdent(String phone, String code, String password,final SuccessCallBack successCallBack, final FailCallBack failCallBack) {
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            if (successCallBack != null) {
                                successCallBack.onSuccess(jsonObject.getString(Config.KEY_TOKEN));
                            }
                            break;
                        default:
                            if (failCallBack != null) {
                                failCallBack.onFail();
                            }
                            break;
                    }
                } catch (JSONException e) {//JSON Exception
                    e.printStackTrace();
                }

            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                if (failCallBack != null) {
                    failCallBack.onFail();//the call function of NetConnection call the communication of login class
                }
            }
        }, Config.KEY_ACTION, Config.ACTION_REGISTER, Config.KEY_PHONE, phone, Config.KEY_CODE, code,Config.KEY_PASSWORD,password);
    }
    public static interface SuccessCallBack{
        void onSuccess(String token);
    }
    public static interface FailCallBack{
        void onFail();
    }
}
