package com.cooper.healthyaide;

import android.app.Activity;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class ExitApplication {
    private List<Activity> activityList = new LinkedList();
    private static ExitApplication instance;

    private ExitApplication() {

    }
    //Get instance of application
    public static ExitApplication getInstance() {
        if (instance == null) {
            instance = new ExitApplication();
        }
        return instance;
    }

    //Insert activity into container
    public void addActivity(Activity activity) {
        activityList.add(activity);
    }
    //Traver all activities and finish
    public void exit() {
        for (Activity activity : activityList) {
            activity.finish();
        }
        System.exit(0);
    }
}
