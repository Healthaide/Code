package com.cooper.healthyaide.net;

import android.util.Log;

import com.cooper.healthyaide.Config;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Cooper-S on 2018/2/14.
 */

public class GetCode {
    private String TAG="SCW";
    public GetCode(String phone, final SuccessCallBack successCallBack,final FailCallBack failCallBack) {
        new NetConnection(Config.URL_TEST, HttpMethod.POST,new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        try {
                            Log.i(TAG,"GetCode NetConnection onSuccess");
                            JSONObject jsonObject = new JSONObject(result);
                            switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                case Config.RESULLT_STATUS_SUCCESS:
                                    successCallBack.onSuccess();//The call function when GetCode is successful
                                    Log.i(TAG,"success to get json");
                                    break;
                                default:
                                    if (failCallBack != null) {
                                        failCallBack.onFail();//The call function when NetConnection fails
                                    }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            if (failCallBack != null) {
                                failCallBack.onFail();//The call function when NetConnection fails
                            }
                        }
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                if (failCallBack != null) {
                    failCallBack.onFail();//The call function when NetConnection fails
                }
            }
        }, Config.KEY_ACTION, Config.ACTION_GET_CODE, Config.KEY_PHONE, phone);
    }
    public static interface SuccessCallBack{
        void onSuccess();
    }
    public static interface FailCallBack{
        void onFail();
    }
}
