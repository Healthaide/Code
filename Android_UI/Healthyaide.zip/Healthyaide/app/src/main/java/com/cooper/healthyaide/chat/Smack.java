package com.cooper.healthyaide.chat;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public interface Smack {
    public boolean login(String username, String password) throws Exception;
}
