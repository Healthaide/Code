package com.cooper.healthyaide.tools;

import android.util.Log;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class Logs {
    public static boolean isDebug = true;// whether print bug message,can access in function onCreate
    private static final String TAG = "SCW";

    // four default tag functions
    public static void i(String msg) {
        if (isDebug)
            Log.i(TAG, msg);
    }

    public static void d(String msg) {
        if (isDebug)
            Log.d(TAG, msg);
    }

    public static void e(String msg) {
        if (isDebug)
            Log.e(TAG, msg);
    }

    public static void v(String msg) {
        if (isDebug)
            Log.v(TAG, msg);
    }
    //print log message via inputting class name
    public static void i(Class<?> _class,String msg){
        if (isDebug)
            Log.i(_class.getName(), msg);
    }
    public static void d(Class<?> _class,String msg){
        if (isDebug)
            Log.i(_class.getName(), msg);
    }
    public static void e(Class<?> _class,String msg){
        if (isDebug)
            Log.i(_class.getName(), msg);
    }
    public static void v(Class<?> _class,String msg){
        if (isDebug)
            Log.i(_class.getName(), msg);
    }
    // inputting customized tag functions
    public static void i(String tag, String msg) {
        if (isDebug)
            Log.i(tag, msg);
    }

    public static void d(String tag, String msg) {
        if (isDebug)
            Log.i(tag, msg);
    }

    public static void e(String tag, String msg) {
        if (isDebug)
            Log.i(tag, msg);
    }

    public static void v(String tag, String msg) {
        if (isDebug)
            Log.i(tag, msg);
    }
}
