package com.cooper.healthyaide.net;

import android.os.AsyncTask;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.UUID;

/**
 * Created by Cooper-S on 2018/2/14.
 */

public class UploadFile {
    private static final String TAG = "uploadFile";
    private static final int TIME_OUT = 10 * 1000; //Timeout
    private static final String CHARSET = "utf-8"; // Set code
    public static final String SUCCESS = "1";
    public static final String FAILURE = "0";

    public UploadFile(final File file, final String RequestURL, final String fileName,
                      final SuccessCallBack successCallBack, final FailCallBack failCallBack) {
        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {
                String result = null;
                final String BOUNDARY = UUID.randomUUID().toString(); //Random generation of boundary identifier
                final String PREFIX = "--", LINE_END = "\r\n";
                final String CONTENT_TYPE = "multipart/form-data"; // Types of content

                try {
                    URL url = new URL(RequestURL);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setReadTimeout(TIME_OUT);
                    conn.setConnectTimeout(TIME_OUT);
                    conn.setDoInput(true); // Allow input flow
                    conn.setDoOutput(true); // Allow output flow
                    conn.setUseCaches(false); // Not allow to use cache
                    conn.setRequestMethod("POST"); // Required Method
                    conn.setRequestProperty("Charset", CHARSET); // Set Code
                    conn.setRequestProperty("connection", "keep-alive");
                    conn.setRequestProperty("Content-Type", CONTENT_TYPE + ";boundary=" + BOUNDARY);

                    if (file != null) {
                        //Upload uploads when a file is not empty

                        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                        StringBuffer sb = new StringBuffer();
                        sb.append(PREFIX);
                        sb.append(BOUNDARY);
                        sb.append(LINE_END);
                        sb.append("Content-Disposition: form-data; name=\"file\"; filename=\""
                                + fileName + "\"" + LINE_END);
                        sb.append("Content-Type: application/octet-stream; charset="
                                + CHARSET + LINE_END);
                        sb.append(LINE_END);
                        dos.write(sb.toString().getBytes());
                        InputStream is = new FileInputStream(file);
                        byte[] bytes = new byte[1024];
                        int len = 0;
                        while ((len = is.read(bytes)) != -1) {
                            dos.write(bytes, 0, len);
                        }
                        is.close();
                        dos.write(LINE_END.getBytes());
                        byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END)
                                .getBytes();
                        dos.write(end_data);
                        dos.flush();
                        /**
                         * 获取响应码 200=成功 当响应成功，获取响应的流
                         */
                        int res = conn.getResponseCode();
                        Log.e(TAG, "response code:" + res);
                        if (res == 200) {
                            Log.e(TAG, "request success");
                            InputStream input = conn.getInputStream();
                            StringBuffer sb1 = new StringBuffer();
                            int ss;
                            while ((ss = input.read()) != -1) {
                                sb1.append((char) ss);
                            }
                            result = sb1.toString();
                            successCallBack.onSuccess(result);
                            Log.e(TAG, "result : " + result);
                        } else {
                            failCallBack.onFail();
                            Log.e(TAG, "request error");
                        }
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (result != null) {
                    return result.toString();
                }else
                    return null;
            }
        }.execute();
    }
    public static interface SuccessCallBack{
        void onSuccess(String result);
    }
    public static interface FailCallBack{
        void onFail();
    }
}
