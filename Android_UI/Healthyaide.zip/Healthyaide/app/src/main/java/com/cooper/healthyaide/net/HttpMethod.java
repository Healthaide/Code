package com.cooper.healthyaide.net;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public enum HttpMethod {
    POST,GET
}
