package com.cooper.healthyaide.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.cooper.healthyaide.Config;
import com.cooper.healthyaide.MainActivity;
import com.cooper.healthyaide.R;
import com.cooper.healthyaide.adapter.ProvinceAdapter;
import com.cooper.healthyaide.bean.ProvinceDate;
import com.cooper.healthyaide.net.HttpMethod;
import com.cooper.healthyaide.net.NetConnection;
import com.cooper.healthyaide.net.UploadFile;
import com.cooper.healthyaide.tools.Bitmaptool;
import com.cooper.healthyaide.tools.MakeHeadImg;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class ImproveInfo extends Activity implements View.OnClickListener{
    private String TAG = "SCW";
    private ImageView img_back;
    private ImageView img_head;
    private TextView tv_nickname;
    private TextView tv_province;
    private TextView tv_school;
    private EditText et_address;
    private RelativeLayout item_school;
    private Button btn_commit;

    private PopupWindow mPopWindow;//Select School
    private SelectPicPopupWindow menuWindow;//Insert Head Portrait
    private Dialog mDialog;//set nickname
    private Bitmap head;//head portrait Bitmap
    private static String path="/sdcard/HealthMama/UserHead/";//SD path
    private View popView;
    private List<ProvinceDate> dates_pro;
    private List<ProvinceDate> dates_sch;
    private ProvinceAdapter adapter_pro;
    private ProvinceAdapter adapter_sch;
    private ListView listView_pro;
    private ListView listView_sch;
    private RequestQueue mQueue;

    private InfoDate infoArray;
    private String token;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_improve_info);
        token = getIntent().getStringExtra("token");
        initView();
    }

    private void initView() {
        dates_pro = new ArrayList<>();
        dates_sch = new ArrayList<>();
        mQueue = Volley.newRequestQueue(this);

        //pop up popwindow object
        popView = View.inflate(this, R.layout.dialog_school, null);
        listView_pro = (ListView) popView.findViewById(R.id.listview_province);
        listView_sch = (ListView) popView.findViewById(R.id.listview_school);

        //Boundle controller
        img_head = (ImageView) findViewById(R.id.img_head);
        item_school = (RelativeLayout) findViewById(R.id.item_school);
        tv_nickname = (TextView) findViewById(R.id.tv_nickname);
        tv_province = (TextView) findViewById(R.id.tv_province);
        tv_school = (TextView) findViewById(R.id.tv_school);
        btn_commit = (Button) findViewById(R.id.btn_commit);
        et_address = (EditText) findViewById(R.id.et_address);

        infoArray = new InfoDate(null,null,null,null,null,et_address);
        //设置监听事件
        findViewById(R.id.img_toolbar_back).setOnClickListener(this);
        findViewById(R.id.item_head).setOnClickListener(this);
        findViewById(R.id.item_nickname).setOnClickListener(this);
        findViewById(R.id.item_area).setOnClickListener(this);
        findViewById(R.id.item_school).setOnClickListener(this);
        btn_commit.setOnClickListener(this);

        //set province data
        initProvinceDate();
        //set adapter
        adapter_pro = new ProvinceAdapter(dates_pro, ImproveInfo.this);
        listView_pro.setAdapter(adapter_pro);
        adapter_sch = new ProvinceAdapter(dates_sch, ImproveInfo.this);
        listView_sch.setAdapter(adapter_sch);

        //listview item monitor
        listView_pro.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                tv_province.setText(dates_pro.get(position).getProvince_name());//show sselected area
                infoArray.area = dates_pro.get(position).getProvince_name();//store area
                tv_province.setTag(1);
                //Get school data
                initSchoolDate(position + 1);
                //Show school list
                tv_school.setText("Please select");
                item_school.setVisibility(View.VISIBLE);
                //popwindow disappear
                mPopWindow.dismiss();
            }
        });
        listView_sch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                tv_school.setText(dates_sch.get(position).getProvince_name());//show selected school
                infoArray.school = dates_sch.get(position).getProvince_name();//store school
                mPopWindow.dismiss();
            }
        });
        //set listener event
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = (RadioButton) findViewById(checkedId);
                infoArray.sex = radioButton.getText().toString();
                Toast.makeText(ImproveInfo.this, "Choose：" + radioButton.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });
        //Set properties of popwindow
        int width = getResources().getDisplayMetrics().widthPixels * 3 / 4;
        int height = getResources().getDisplayMetrics().heightPixels * 3 / 5;
        mPopWindow = new PopupWindow(popView, width, height);
        ColorDrawable dw = new ColorDrawable(0x30000000);
        mPopWindow.setBackgroundDrawable(dw);
        mPopWindow.setFocusable(true);
        mPopWindow.setTouchable(true);
        mPopWindow.setOutsideTouchable(true);
        mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                setBgAlpha(1.0f);
            }
        });
    }

    private void initProvinceDate() {

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Config.PROVINCE_URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                try {
                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < 34; i++) {
                        ProvinceDate provinceDate = new ProvinceDate(array.getJSONObject(i).getString("province_id"),
                                array.getJSONObject(i).getString("province_name"));
                        dates_pro.add(provinceDate);
                    }
                    adapter_pro.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "fail to get data");
            }
        });
        mQueue.add(jsonObjectRequest);
    }
    private void initSchoolDate(int position) {
        dates_sch.clear();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Config.SCHOOL_URL + position, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                try {
                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        ProvinceDate provinceDate = new ProvinceDate(array.getJSONObject(i).getString("school_id"),
                                array.getJSONObject(i).getString("school_name"));
                        dates_sch.add(provinceDate);
                    }
                    adapter_sch.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "fail to get data");
            }
        });
        mQueue.add(jsonObjectRequest);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_toolbar_back:
                this.finish();
                break;
            case R.id.item_head:
                setBgAlpha(0.5f);

                menuWindow = new SelectPicPopupWindow(ImproveInfo.this, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        menuWindow.dismiss();
                        switch (v.getId()) {

                            case R.id.btn_pick_photo://Choose from alum
                                setBgAlpha(1.0f);

                                Intent intent1 = new Intent(Intent.ACTION_PICK, null);
                                intent1.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                                startActivityForResult(intent1, 1);
                                break;
                            case R.id.btn_take_photo:
                                setBgAlpha(1.0f);

                                Intent intent2 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                intent2.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(Environment.getExternalStorageDirectory(),"head.jpg")));
                                startActivityForResult(intent2, 2);
                                break;
                            default:
                                break;
                        }
                    }
                }, new SelectPicPopupWindow.SetBgAlphaCallBack() {
                    @Override
                    public void setBackgroundAlpha(float alpha) {
                        Log.e(TAG,"Override：");
                        ImproveInfo.this.setBgAlpha(alpha);
                    }
                });
                menuWindow.showAtLocation(ImproveInfo.this.findViewById(R.id.main),
                        Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);//设置layout在PopupWindow中显示的位置
                break;
            case R.id.item_nickname:
                setBgAlpha(0.5f);
                mDialog = new Dialog(this,R.style.Info_Dialog);

                mDialog.setContentView(LayoutInflater.from(this).inflate(R.layout.dialog_info, null));
                mDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        setBgAlpha(1.0f);
                    }
                });
                final EditText editText = (EditText) mDialog.findViewById(R.id.et_input);

                mDialog.findViewById(R.id.btn_save).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (TextUtils.isEmpty(editText.getText().toString())) {
                            Toast.makeText(ImproveInfo.this, "Please enter nick name", Toast.LENGTH_SHORT).show();
                        }else if (editText.getText().length() > 6) {
                            Toast.makeText(ImproveInfo.this, "Too long", Toast.LENGTH_SHORT).show();
                        }else {
                            tv_nickname.setText(editText.getText().toString());
                            infoArray.nickname = editText.getText().toString();//Save nickname
                            mDialog.dismiss();
                        }
                    }
                });
                mDialog.show();
                break;
            case R.id.item_area:
                setBgAlpha(0.5f);
                listView_pro.setVisibility(View.VISIBLE);
                listView_sch.setVisibility(View.GONE);
                mPopWindow.showAtLocation(ImproveInfo.this.findViewById(R.id.main), Gravity.CENTER, 0, 0);

                break;
            case R.id.item_school:
                setBgAlpha(0.5f);
                listView_pro.setVisibility(View.GONE);
                listView_sch.setVisibility(View.VISIBLE);
                mPopWindow.showAtLocation(ImproveInfo.this.findViewById(R.id.main), Gravity.CENTER, 0, 0);
                break;
            case R.id.btn_commit:
                if (infoArray.sex == null) {
                    Toast.makeText(ImproveInfo.this, "Please select gender", Toast.LENGTH_SHORT).show();
                }else if (infoArray.area == null) {
                    Toast.makeText(ImproveInfo.this, "Please select are", Toast.LENGTH_SHORT).show();
                }else if (infoArray.school == null) {
                    Toast.makeText(ImproveInfo.this, "Please select school", Toast.LENGTH_SHORT).show();
                }else {
                    new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
                        @Override
                        public void onSuccess(String result) {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                    case Config.RESULLT_STATUS_SUCCESS:

                                        if (infoArray.getHead() != null) {
                                            setPicToView(infoArray.getHead());//Save in SD card
                                        }else if (infoArray.getHead() == null) {
                                            //制作昵称首字母头像
                                            String nickname = infoArray.getNickname();
                                            Bitmap bitmap = MakeHeadImg.makeHeadImg(Bitmaptool.getBitmap(ImproveInfo.this,R.drawable.pic_head_empty), String.valueOf(nickname.charAt(0)));
                                            Bitmaptool.saveHeadImg(bitmap);
                                        }
                                        Config.cacheUserid(ImproveInfo.this, jsonObject.getString(Config.KEY_PHONE));
                                        Config.cacheNick(ImproveInfo.this, infoArray.getNickname());
                                        Config.cacheSex(ImproveInfo.this, infoArray.sex);
                                        Config.cacheArea(ImproveInfo.this, infoArray.area);
                                        Config.cacheSchool(ImproveInfo.this, infoArray.school);
                                        Config.cacheAddress(ImproveInfo.this, infoArray.getAddress());

                                        new UploadFile(new File(path + "head.jpg"), Config.URL_UPLOAD, Config.getCachedUserid(ImproveInfo.this)+Config.JPG,
                                                new UploadFile.SuccessCallBack() {
                                                    @Override
                                                    public void onSuccess(String result) {

                                                    }
                                                }, new UploadFile.FailCallBack() {
                                            @Override
                                            public void onFail() {

                                            }
                                        });
                                        Intent intentToMian = new Intent(ImproveInfo.this, MainActivity.class);

                                        startActivity(intentToMian);
                                        break;
                                    default:
                                        break;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new NetConnection.FailCallBack() {
                        @Override
                        public void onFail() {

                        }
                    }, Config.KEY_ACTION, Config.KEY_IMPROVE,
                            Config.KEY_TOKEN, token,
                            Config.KEY_HEAD,"",
                            Config.KEY_NICKNAME, infoArray.getNickname(),
                            Config.KEY_SEX, infoArray.sex,
                            Config.KEY_AREA, infoArray.area,
                            Config.KEY_SCHOOL, infoArray.school,
                            Config.KEY_ADDRESS, infoArray.getAddress());
                }
                break;
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    cropPhoto(data.getData());//Clip pictures
                }

                break;
            case 2:
                if (resultCode == RESULT_OK) {
                    File temp = new File(Environment.getExternalStorageDirectory()
                            + "/head.jpg");
                    cropPhoto(Uri.fromFile(temp));//Clip pictures
                }

                break;
            case 3:
                if (data != null) {
                    Bundle extras = data.getExtras();
                    head = extras.getParcelable("data");
                    if(head!=null){
                        /**
                         * Upload Files
                         */
                        //setPicToView(head);//Store in SD card
                        infoArray.head = head;//Save Head Portrait
                        img_head.setImageBitmap(head);//Show ImageView
                    }
                }
                break;
            default:
                break;

        }
        super.onActivityResult(requestCode, resultCode, data);
    };
    public void cropPhoto(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // aspectX aspectY is the ratio of height and width
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY are the height and width of picture
        intent.putExtra("outputX", 150);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 3);
    }
    private void setPicToView(Bitmap mBitmap) {
        String sdStatus = Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // Check if sd is available
            return;
        }
        FileOutputStream b = null;
        File file = new File(path);
        file.mkdirs();// create file directory
        String fileName =path + "head.jpg";//picture name
        try {
            b = new FileOutputStream(fileName);
            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);// input data into file

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                //close flow
                b.flush();
                b.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (mDialog!=null&&mDialog.isShowing()) {
                mDialog.dismiss();
            } else {
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    public void setBgAlpha(float bgAlpha){
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.alpha = bgAlpha;
        getWindow().setAttributes(params);
    }

    private static class InfoDate {
        Bitmap head;
        String nickname;
        String sex;
        String area;
        String school;
        EditText editText;

        public InfoDate(Bitmap head, String nickname, String sex, String area, String school,EditText editText) {
            this.head = head;
            this.nickname = nickname;
            this.sex = sex;
            this.area = area;
            this.school = school;
            this.editText = editText;
        }

        public Bitmap getHead() {
            return head;
        }

        public String getNickname() {
            if (nickname == null) {
                return "None";
            }
            return nickname;
        }
        public String getAddress() {
            if (TextUtils.isEmpty(editText.getText().toString())) {
                return "None";
            }
            return editText.getText().toString();
        }
    }
}
