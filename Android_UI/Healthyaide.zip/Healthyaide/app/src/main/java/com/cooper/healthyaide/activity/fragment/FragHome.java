package com.cooper.healthyaide.activity.fragment;

import android.app.Fragment;
import android.view.View;

/**
 * Created by Cooper-S on 2018/2/2.
 */

public class FragHome extends Fragment implements View.OnClickListener{

    @Override
    public void onClick(View view) {

    }
}
