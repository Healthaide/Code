package com.cooper.healthyaide.tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

/**
 * Created by Cooper-S on 2018/2/14.
 */

public class MakeHeadImg {
    public static Bitmap makeHeadImg(Bitmap bg, String water) {
        Bitmap tarBitmap = bg.copy(Bitmap.Config.ARGB_8888, true);
        int w = tarBitmap.getWidth();
        int h = tarBitmap.getHeight();
        Canvas canvas = new Canvas(tarBitmap);

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DEV_KERN_TEXT_FLAG);

        textPaint.setTextAlign(Paint.Align.CENTER);

        textPaint.setTextSize(300.0f);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setColor(0xff39d067);

        Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
        //Calculate Height of text
        float fontHeight = fontMetrics.bottom -fontMetrics.top;
        //Calculate baseline of text
        float textBaseY = h - (h - fontHeight) / 2 - fontMetrics.bottom;

        //The watermark is added to the picture, which is set at the middle and lower parts.
        canvas.drawText(water, (float) (w * 0.5), textBaseY, textPaint);
        canvas.save(Canvas.ALL_SAVE_FLAG);
        canvas.restore();
        return tarBitmap;
    }
}
