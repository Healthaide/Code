package com.cooper.healthyaide.chat;

import com.cooper.healthyaide.Config;
import com.cooper.healthyaide.tools.Logs;
import com.cooper.healthyaide.tools.StringTools;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class SmackMethod implements Smack{
    private static final int PACKET_TIMEOUT = 30000;

    private ConnectionConfiguration mXMPPConfig;
    private static XMPPConnection mXMPPConnection;


    public SmackMethod() {
        this.mXMPPConfig = new ConnectionConfiguration(Config.URL_IP, 5222); // use SRV

        this.mXMPPConfig.setReconnectionAllowed(false);
        this.mXMPPConfig.setSendPresence(false);
        this.mXMPPConfig.setCompressionEnabled(false); // disable for now
        this.mXMPPConfig.setSecurityMode(ConnectionConfiguration.SecurityMode.required);

        this.mXMPPConnection = new XMPPConnection(mXMPPConfig);
    }

    private static void openConnection() {
        try {
            //url
            ConnectionConfiguration connConfig = new ConnectionConfiguration(Config.URL_IP, 5222);
            mXMPPConnection = new XMPPConnection(connConfig);
            mXMPPConnection.connect();
        }
        catch (XMPPException xe)
        {
            xe.printStackTrace();
        }
    }

    public static XMPPConnection getConnection() {
        if (mXMPPConnection == null) {
            openConnection();
        }
        return mXMPPConnection;
    }

    public static void closeConnection() {
        mXMPPConnection.disconnect();
        mXMPPConnection = null;
    }

    @Override
    public boolean login(String username, String password) throws Exception {
        if (mXMPPConnection.isConnected()) {
            try {
                mXMPPConnection.disconnect();
            } catch (Exception e) {
                Logs.d("conn.disconnect() failed: " + e);
            }
        }
        SmackConfiguration.setPacketReplyTimeout(PACKET_TIMEOUT);
        SmackConfiguration.setKeepAliveInterval(-1);
        SmackConfiguration.setDefaultPingInterval(0);

        mXMPPConnection.connect();
        if (!mXMPPConnection.isConnected()) {
            throw new Exception("SMACK connect failed without exception!");
        }
        mXMPPConnection.addConnectionListener(new ConnectionListener() {
            public void connectionClosedOnError(Exception e) {
            }

            public void connectionClosed() {
            }

            public void reconnectingIn(int seconds) {
            }

            public void reconnectionFailed(Exception e) {
            }

            public void reconnectionSuccessful() {
            }
        });

        registerMessageListener(username);// listen message event
        return mXMPPConnection.isAuthenticated();
    }
    private void registerMessageListener(final String username) {

        PacketTypeFilter filter = new PacketTypeFilter(Message.class);
        Logs.i("before");
        PacketListener mPacketListener = new PacketListener() {
            public void processPacket(Packet packet) {
                try {
                    if (packet instanceof Message) {// if it is message type
                        Message msg = (Message) packet;
                        Logs.i("12:" + msg.toString() + ":" + msg.toXML());

                        String chatMessage = msg.getBody();
                        String from = StringTools.getRealUsername(msg.getFrom());
                        String to = StringTools.getRealUsername(msg.getTo());
                        Logs.i("from:" + from + "to:" + to);

                        if (chatMessage == null) {
                            Logs.i("Null  Return");
                            return;// If it is empty message, then return
                        }else if (msg.getType() == Message.Type.error) {
                            Logs.i("Wrong type");
                            chatMessage = "<Error> " + chatMessage;// Wrong type of message
                        }else if (to.equals(username)) {
                            Logs.i("Message:" + chatMessage);
                        }
                    }
                } catch (Exception e) {
                    Logs.i("failed to process packet:");
                    e.printStackTrace();
                }
            }
        };
        Logs.i("after");
        getConnection().addPacketListener(mPacketListener, filter);
    }
}
