package com.cooper.healthyaide.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.cooper.healthyaide.Config;
import com.cooper.healthyaide.MainActivity;
import com.cooper.healthyaide.R;
import com.cooper.healthyaide.net.HttpMethod;
import com.cooper.healthyaide.net.NetConnection;
import com.cooper.healthyaide.tools.Bitmaptool;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Cooper-S on 2018/2/2.
 */

public class Login extends Activity implements View.OnClickListener{
    private String TAG = "SCW";
    private TextView tv_register;//Registration
    private TextView tv_forget_password;//Recover password

    private Button btn_login;//login button
    private EditText et_username;//username field
    private EditText et_password;//password field

    private RequestQueue mQueue;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initView();
    }

    public void initView(){
        mQueue= Volley.newRequestQueue(this);
        tv_register = findViewById(R.id.tv_register);
        tv_forget_password = findViewById(R.id.tv_forget_password);
        btn_login = findViewById(R.id.btn_login);
        et_username = findViewById(R.id.et_input_username);
        et_password = findViewById(R.id.et_input_password);

        tv_register.setOnClickListener(this);
        tv_forget_password.setOnClickListener(this);
        btn_login.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.tv_register:
                Intent intent_Regist = new Intent(Login.this, Register.class);
                startActivity(intent_Regist);
                break;
            case R.id.tv_forget_password:
                Intent intent_recover = new Intent(Login.this, RecoverPassword.class);
                startActivity(intent_recover);
                break;
            case R.id.btn_login:
                if(TextUtils.isEmpty(et_username.getText()))
                    Toast.makeText(Login.this,getString(R.string.pleaseInputUsername),Toast.LENGTH_LONG).show();
                else if(TextUtils.isEmpty(et_password.getText()))
                    Toast.makeText(Login.this,getString(R.string.pleaseInputPassword),Toast.LENGTH_LONG).show();
                new NetConnection(Config.URL_TEST, HttpMethod.POST,new NetConnection.SuccessCallBack(){

                    @Override
                    public void onSuccess(String result) {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            Log.i(TAG, "status:" + jsonObject.toString());
                            Intent intent = new Intent(Login.this, MainActivity.class);
                            startActivity(intent);
                            /*switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                case Config.RESULLT_STATUS_SUCCESS:
                                    JSONObject body = jsonObject.getJSONObject(Config.KEY_BODY);

                                    //Cache User information
                                    Config.cacheHead(Login.this, null);

                                    //token
                                    Config.cacheToken(Login.this, jsonObject.getString(Config.KEY_TOKEN));
                                    //head
                                    Config.cacheHead(Login.this, Config.URL_HEAD + body.getString(Config.KEY_HEAD));
                                    //userid
                                    Config.cacheUserid(Login.this, et_username.getText().toString());
                                    //password
                                    Config.cachePassword(Login.this, et_password.getText().toString());
                                    //Nickname
                                    Config.cacheNick(Login.this, body.getString(Config.KEY_NICKNAME));
                                    //Gender
                                    Config.cacheSex(Login.this, body.getString(Config.KEY_SEX));
                                    //Area
                                    Config.cacheArea(Login.this, body.getString(Config.KEY_AREA));
                                    //Address
                                    Config.cacheAddress(Login.this, body.getString(Config.KEY_ADDRESS));
                                    Log.i(TAG, body.getString(Config.KEY_ADDRESS));
                                    //School
                                    Config.cacheSchool(Login.this, body.getString(Config.KEY_SCHOOL));

                                    getHeadFromNet(Config.URL_HEAD + body.getString(Config.KEY_HEAD));

                                    //page jump when login success
                                    Intent intent = new Intent(Login.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                    break;
                                default:
                                    Toast.makeText(Login.this, "No User or Wrong Password", Toast.LENGTH_LONG).show();
                                    break;

                            }*/
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },new NetConnection.FailCallBack(){
                    @Override
                    public void onFail() {

                    }
                },Config.KEY_ACTION,Config.ACTION_LOGIN,Config.KEY_PHONE,et_username.getText().toString(),
                        Config.KEY_PASSWORD,et_password.getText().toString());
                break;
                    }
                }

    private void getHeadFromNet(String url) {
        Log.i(TAG, "url:" + url);
        ImageRequest imageRequest = new ImageRequest(
                url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        Log.i(TAG, "download head success");
                        Bitmaptool.saveHeadImg(bitmap);
                    }
                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "download head fail");
            }
        });
        mQueue.add(imageRequest);
    }

}
