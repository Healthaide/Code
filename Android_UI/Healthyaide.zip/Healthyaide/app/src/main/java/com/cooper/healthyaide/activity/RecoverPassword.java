package com.cooper.healthyaide.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cooper.healthyaide.R;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class RecoverPassword extends Activity implements View.OnClickListener{
    private String TAG="SCW";
    private String str_title;
    private ImageView img_toolbar_back;
    private Button btn_register;
    private Button btn_getcode;
    private EditText et_phone_num;
    private EditText et_code;
    private EditText et_password;
    private EditText et_password_again;
    private TextView tv_title;

    private int count = 60;//获取验证码的时间间隔为60s
    private TimerTask timerTask;
    private Timer timer;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recover_pass);
        initView();

    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_register_toolbar_title);
        img_toolbar_back = (ImageView) findViewById(R.id.img_toolbar_back);
        btn_register = (Button) findViewById(R.id.btn_register);
        btn_getcode = (Button) findViewById(R.id.btn_register_getcode);
        et_phone_num = (EditText) findViewById(R.id.et_input_phone_num);
        et_code = (EditText) findViewById(R.id.et_input_code);
        et_password = (EditText) findViewById(R.id.et_input_password);
        et_password_again = (EditText) findViewById(R.id.et_input_password_again);

        tv_title.setText("找回密码");
        btn_register.setText("重新设置");
        btn_register.setOnClickListener(this);
        btn_getcode.setOnClickListener(this);
        img_toolbar_back.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

    }
}
