package com.cooper.healthyaide;

import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.cooper.healthyaide.activity.fragment.FragFind;
import com.cooper.healthyaide.activity.fragment.FragHome;
import com.cooper.healthyaide.activity.fragment.FragUser;
import com.cooper.healthyaide.chat.SmackMethod;

public class MainActivity extends AppCompatActivity {

    //Record time of exit
    private long exitTime = 0l;
    //Define FragmentTabHost object
    private FragmentTabHost mTabHost;
    //Define a layout
    private LayoutInflater layoutInflater;
    //Define an array to store Fragment layout
    private Class fragmentArray[]={FragHome.class, FragFind.class,FragUser.class};
    //Deine an arrray to store button
    private int mImageViewArray[]={R.drawable.tab_home_btn,R.drawable.tab_find_btn,R.drawable.tab_user_btn};
    //Define text in tab options
    private String mTextViewArray[]= {"Home","Find","Me"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ExitApplication.getInstance().addActivity(this);

        SmackMethod mMethod = new SmackMethod();
        try {
            mMethod.login(Config.getCachedUserid(MainActivity.this), Config.getCachedPassword(MainActivity.this));
        } catch (Exception e) {
            e.printStackTrace();
        }
        initView();
    }

    private void initView() {
        //Initialize layout object
        layoutInflater = LayoutInflater.from(this);
        //Initialize Tabhost object to get Tabhost
        mTabHost = (FragmentTabHost) findViewById(R.id.tab_host);
        mTabHost.setup(this, getSupportFragmentManager(), R.id.frag_content);

        //Get the number of fragment
        int count = fragmentArray.length;

        for (int i = 0; i < count; i++) {
            //Set Tab button's icon, text and content
            TabHost.TabSpec tabSpec = mTabHost.newTabSpec(mTextViewArray[i]).setIndicator(getTabItemView(i));

            //Insert Tab button into Tab options
            mTabHost.addTab(tabSpec, fragmentArray[i], null);
        }

    }

    private View getTabItemView(int i) {
        View view = layoutInflater.inflate(R.layout.item_tab_view, null);

        ImageView imageView = (ImageView) view.findViewById(R.id.iv_tab);
        imageView.setImageResource(mImageViewArray[i]);

        TextView textView = (TextView) view.findViewById(R.id.tv_tab);
        textView.setText(mTextViewArray[i]);

        return view;

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                Toast.makeText(this, "Push again before exit App", Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
                System.exit(0);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
