package com.cooper.healthyaide;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class Config {
    public static final String URL_IP = "127.0.0.1";
    public static final String URL_ROOT = "http://127.0.0.1";
    public static final String URL_HEAD = URL_ROOT + ":8080/";
    public static final String URL_TEST = URL_ROOT + ":8080/HelloServer/LoginServlet";
    public static final String URL_UPLOAD = URL_ROOT + ":8080/HelloServer/UploadfileServlet";

    public static final String PROVINCE_URL = "http://www.hisihi.com/app.php?s=/school/province";
    public static final String SCHOOL_URL = "http://www.hisihi.com/app.php?s=/school/school/provinceid/";

    public static final String JPG = ".jpg";
    //parameters
    //一、Request
    //1、data required method
    //(1)、key
    public static final String KEY_ACTION = "action";
    public static final String ACTION_GET_CODE = "send_pass";//Get verified code
    public static final String ACTION_LOGIN = "login";//Login
    public static final String ACTION_REGISTER = "register";//Registration

    //2、Operations in registration
    //(1)、Key
    public static final String KEY_PHONE = "phone";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_CODE = "code";
    public static final String KEY_IMPROVE = "improve";
    //二、Back
    //1、acquire verified code,register operation
    //(1)、key
    public static final String KEY_STATUS = "status";
    //(2)、value
    public static final int RESULLT_STATUS_SUCCESS = 0;
    public static final int RESULT_STATUS_NO_USER = 1;
    public static final int RESULT_STATUS_PASS_WRONG = 2;

    //2.Login Operation

    public static final String KEY_TOKEN = "token";
    //Get user information via login in JSON key name.
    public static final String KEY_BODY = "body";
    public static final String KEY_NICKNAME = "nickname";
    public static final String KEY_USERID = "userid";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_SEX = "sex";
    public static final String KEY_AREA = "area";
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_SCHOOL = "school";
    public static final String KEY_HEAD = "head";
    public static final String APP_ID = "com.cooper.healthyaide";

    //  Get head
    public static String getCachedHead(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_HEAD, null);
    }
    //Cache head
    public static void cacheHead(Context context,String head) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_HEAD, head);
        e.commit();
    }

    //Get Token
    public static String getCachedToken(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
    }
    //Cache token
    public static void cacheToken(Context context,String token) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_TOKEN, token);
        e.commit();
    }

    //cache password
    public static void cachePassword(Context context,String password) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_PASSWORD, password);
        e.commit();
    }
    //Get password
    public static String getCachedPassword(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_PASSWORD, null);
    }

    //Get Phone number as user name
    public static String getCachedUserid(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_USERID, null);
    }
    //cache user name
    public static void cacheUserid(Context context,String userid) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_USERID, userid);
        e.commit();
    }

    //Get nickname
    public static String getCachedNick(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_NICKNAME, null);
    }
    //Cache nickname
    public static void cacheNick(Context context,String nick) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_NICKNAME, nick);
        e.commit();
    }

    //Get sex
    public static String getCachedSex(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_SEX, null);
    }
    //Cache sex
    public static void cacheSex(Context context,String sex) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_SEX, sex);
        e.commit();
    }
    //Get area
    public static String getCachedArea(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_AREA, null);
    }
    //Cache area
    public static void cacheArea(Context context,String area) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_AREA, area);
        e.commit();
    }

    //Get address
    public static String getCachedAddress(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_ADDRESS, null);
    }
    //Cache address
    public static void cacheAddress(Context context,String address) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_ADDRESS, address);
        e.commit();
    }

    //Get school
    public static String getCachedSchool(Context context) {
        return context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).getString(KEY_SCHOOL, null);
    }
    //Cache school
    public static void cacheSchool(Context context,String school) {
        SharedPreferences.Editor e = context.getSharedPreferences(APP_ID, Context.MODE_PRIVATE).edit();
        e.putString(KEY_SCHOOL, school);
        e.commit();
    }
}
