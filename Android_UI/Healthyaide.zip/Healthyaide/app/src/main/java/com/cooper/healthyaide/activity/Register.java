package com.cooper.healthyaide.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cooper.healthyaide.R;
import com.cooper.healthyaide.net.GetCode;
import com.cooper.healthyaide.net.RegisterIdent;
import com.cooper.healthyaide.tools.Logs;
import com.cooper.healthyaide.tools.Toasts;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Cooper-S on 2018/2/10.
 */

public class Register extends Activity implements View.OnClickListener{
    private String TAG ="SCW";
    private String str_title;
    private ImageView img_toolbar_back;
    private Button btn_register;
    private Button btn_getcode;
    private EditText et_phone_num;
    private EditText et_code;
    private EditText et_password;
    private EditText et_password_again;
    private TextView tv_title;

    private int count = 60;//The time interval for getting the verifying code is 60s

    private TimerTask timerTask;
    private Timer timer;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        initView();
    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_register_toolbar_title);
        img_toolbar_back = (ImageView) findViewById(R.id.img_toolbar_back);
        btn_register = (Button) findViewById(R.id.btn_register);
        btn_getcode = (Button) findViewById(R.id.btn_register_getcode);
        et_phone_num = (EditText) findViewById(R.id.et_input_phone_num);
        et_code = (EditText) findViewById(R.id.et_input_code);
        et_password = (EditText) findViewById(R.id.et_input_password);
        et_password_again = (EditText) findViewById(R.id.et_input_password_again);

        tv_title.setText("USer Register");
        btn_register.setOnClickListener(this);
        btn_getcode.setOnClickListener(this);
        img_toolbar_back.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //Event in Registration
            case R.id.btn_register:
                if (TextUtils.isEmpty(et_phone_num.getText())) {
                    Toast.makeText(Register.this, getString(R.string.str_phoneNumCannotBeEmpty), Toast.LENGTH_SHORT).show();
                    return;
                } else if (TextUtils.isEmpty(et_code.getText())) {
                    Toast.makeText(Register.this, getString(R.string.str_codeCannotBeEmpty), Toast.LENGTH_SHORT).show();
                    return;
                } else if (TextUtils.isEmpty(et_password.getText())) {
                    Toast.makeText(Register.this, getString(R.string.str_passwordCannotBeWmpty), Toast.LENGTH_SHORT).show();
                    return;
                } else if (TextUtils.isEmpty(et_password_again.getText())) {
                    Toast.makeText(Register.this, getString(R.string.str_passwordAgainCannotBeEmpty), Toast.LENGTH_SHORT).show();
                    return;
                } else if (et_password.getText().equals(et_password_again.getText())) {
                    Toast.makeText(Register.this, getString(R.string.str_password_error), Toast.LENGTH_SHORT).show();
                    return;
                }
                new RegisterIdent(et_phone_num.getText().toString(), et_code.getText().toString(),
                        et_password.getText().toString(), new RegisterIdent.SuccessCallBack() {
                    @Override
                    public void onSuccess(String token) {

                        Intent intentToImprove = new Intent(Register.this, ImproveInfo.class);
                        intentToImprove.putExtra("token", token);
                        startActivity(intentToImprove);
                    }
                }, new RegisterIdent.FailCallBack() {
                    @Override
                    public void onFail() {
                        Toasts.s(Register.this, "Fail, Try Again");
                        Logs.i(TAG, "fail");
                    }
                });
                break;
            //Event that backs to upper level
            case R.id.img_toolbar_back:
                this.finish();
                break;
            //Event that gets verified code
            case R.id.btn_register_getcode:

                if (btn_getcode.getText().equals("Get")) {
                    if (TextUtils.isEmpty(et_phone_num.getText())) {
                        Toast.makeText(Register.this, getString(R.string.str_phoneNumCannotBeEmpty), Toast.LENGTH_LONG).show();
                        return;
                    }
                    final ProgressDialog pd = ProgressDialog.show(Register.this, getString(R.string.str_connecting), getString(R.string.str_successToConnect));
                    pd.setCancelable(true);
                    new GetCode(et_phone_num.getText().toString(),
                            new GetCode.SuccessCallBack() {
                                @Override
                                public void onSuccess() {
                                    pd.dismiss();
                                    Toast.makeText(Register.this, getString(R.string.str_successToGetCode), Toast.LENGTH_SHORT).show();
                                    startCount();
                                }
                            }, new GetCode.FailCallBack() {
                        @Override
                        public void onFail() {
                            pd.dismiss();
                            Toast.makeText(Register.this, getString(R.string.str_failToGetCode), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    return;
                }
        }
    }
    public void startCount() {
        count = 60;
        timer = new Timer();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                if (count > 0) {
                    btn_getcode.setText("" + count + getString(R.string.str_secondsLaterReGet));
                    Log.i(TAG, "Countdown：" + count);
                } else {
                    btn_getcode.setText("Get");
                    Log.i(TAG,"End Countdown");
                    timerTask.cancel();
                }
                count--;
            }
        };
        timer.schedule(timerTask, 0, 1000);
    }
}
