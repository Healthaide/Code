package com.zsx.healthassistant.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class ComplaintArticle extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_title;
    private TextView tv_commint;
    private EditText et_judge_content;
    private ImageView img_toolbar_reminder;

    private RequestQueue mQueue;
    private String doc_id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_quick_ask);
        initView();
    }

    private void initView() {
        mQueue = Volley.newRequestQueue(this);

        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_commint = (TextView) findViewById(R.id.tv_toolbar_other);
        et_judge_content = (EditText) findViewById(R.id.et_content);
        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);

        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("投诉");
        tv_commint.setText("提交");
        et_judge_content.setHint("请详细写明投诉本文章的原因");
        tv_commint.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_toolbar_other:
                Long curDate = System.currentTimeMillis();
                Log.i(Config.TAG, "send;" + curDate);
                new NetConnection(Config.URL_TEST, HttpMethod.POST,
                        new NetConnection.SuccessCallBack() {
                            @Override
                            public void onSuccess(String result) {
                                try {
                                    JSONObject jsonObject = new JSONObject(result);
                                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                        case Config.RESULLT_STATUS_SUCCESS:
                                            Toast.makeText(ComplaintArticle.this, "投诉成功", Toast.LENGTH_SHORT).show();
                                            et_judge_content.setText("");
                                            finish();
                                            break;
                                        default:
                                            Toast.makeText(ComplaintArticle.this, "投诉失败", Toast.LENGTH_SHORT).show();
                                            break;
                                    }
                                } catch (JSONException e) {
                                    Log.i("ZSX", "connection failed");
                                    e.printStackTrace();
                                }
                            }
                        }, new NetConnection.FailCallBack() {
                    @Override
                    public void onFail() {

                    }
                }, Config.KEY_ACTION, Config.ACTION_COMPLAINT_COMMIT,
                        Config.KEY_TOKEN, Config.getCachedToken(ComplaintArticle.this),
                        Config.KEY_PHONE, doc_id,
                        Config.KEY_DATE, curDate.toString(),
                        Config.KEY_CONTENT, et_judge_content.getText().toString());
                break;
        }
    }
}
