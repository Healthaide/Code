package com.zsx.healthassistant.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class JudgeDoctor extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_title;
    private TextView tv_commint;
    private EditText et_judge_content;
    private ImageView img_toolbar_reminder;

    private String doc_id;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_quick_ask);
        doc_id = getIntent().getStringExtra(Config.DOC_ID);
        initView();
    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_commint = (TextView) findViewById(R.id.tv_toolbar_other);
        et_judge_content = (EditText) findViewById(R.id.et_content);
        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);

        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("评价");
        tv_commint.setText("提交");
        et_judge_content.setHint("评价内容");
        tv_commint.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_toolbar_other:
                Long curDate = System.currentTimeMillis();
                Log.i(Config.TAG, "send;" + curDate);
                new NetConnection(Config.URL_TEST, HttpMethod.POST,
                        new NetConnection.SuccessCallBack() {
                            @Override
                            public void onSuccess(String result) {
                                try {
                                    JSONObject jsonObject = new JSONObject(result);
                                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                        case Config.RESULLT_STATUS_SUCCESS:
                                            Toast.makeText(JudgeDoctor.this, "评价成功", Toast.LENGTH_SHORT).show();
                                            et_judge_content.setText("");
                                            finish();
                                            break;
                                        default:
                                            Toast.makeText(JudgeDoctor.this, "评价失败", Toast.LENGTH_SHORT).show();
                                            break;
                                    }
                                } catch (JSONException e) {
                                    Log.i("ZSX", "connection failed");
                                    e.printStackTrace();
                                }
                            }
                        }, new NetConnection.FailCallBack() {
                    @Override
                    public void onFail() {

                    }
                }, Config.KEY_ACTION, Config.ACTION_JUDGE_COMMIT,
                        Config.KEY_TOKEN, Config.getCachedToken(JudgeDoctor.this),
                        Config.KEY_PHONE, doc_id,
                        Config.KEY_DATE, curDate.toString(),
                        Config.KEY_CONTENT, et_judge_content.getText().toString());
                break;
        }
    }
}
