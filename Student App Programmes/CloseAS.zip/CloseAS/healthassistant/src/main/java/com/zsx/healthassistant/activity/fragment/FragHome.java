package com.zsx.healthassistant.activity.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.ArticleContent;
import com.zsx.healthassistant.activity.ListArticle;
import com.zsx.healthassistant.activity.ListReminder;
import com.zsx.healthassistant.activity.ListTopic;
import com.zsx.healthassistant.activity.QuickAsk;
import com.zsx.healthassistant.activity.SearchView;
import com.zsx.healthassistant.activity.SelfDiag;
import com.zsx.healthassistant.activity.TopicDetail;
import com.zsx.healthassistant.activity.searchview.Search;
import com.zsx.healthassistant.adapter.ArticleAdapter;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.BitmapTools;
import com.zsx.healthassistant.tools.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class FragHome extends Fragment implements View.OnClickListener{
    private String TAG = "ZSX";
    private View rootView;
    private EditText et_search;
    private ImageView img_reminder;
    private RelativeLayout block_quick_ask;
    private RelativeLayout block_self_diag;
    private RelativeLayout block_new_article;
    private RelativeLayout block_hot_article;
    private RelativeLayout block_topic_more;

    private RelativeLayout item_topic_1;
    private RelativeLayout item_topic_2;
    private RelativeLayout item_topic_3;

    private ListView listview_last;
    private ListView listview_hot;
    private ArticleAdapter adapter_last;
    private ArticleAdapter adapter_hot;
    private List<ArticleDate> dates_last;
    private List<ArticleDate> dates_hot;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.i(TAG, "");
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.frag_home, null);
            Log.i(TAG,"FragFind:new");
        }
        //缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootView已经有parent的错误
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null) {
            parent.removeView(rootView);
            Log.i(TAG,"FragFind:remove");
        }
        initView(rootView);

//        init();
//        initTest(rootView);
        return rootView;
    }

//    private void initTest(final View view) {
//        new NetConnection(Config.URL_TEST, HttpMethod.POST,
//                new NetConnection.SuccessCallBack() {
//                    @Override
//                    public void onSuccess(String result) {
//                        try {
//                            JSONObject jsonObject = new JSONObject(result);
//                            switch (jsonObject.getInt(Config.KEY_STATUS)) {
//                                case Config.RESULLT_STATUS_SUCCESS:
//                                    ((TextView) view.findViewById(R.id.tv_test)).setText(jsonObject.toString());
//                                    break;
//                                default:
//                                    ((TextView) view.findViewById(R.id.tv_test)).setText("status 不为 0");
//                                    break;
//                            }
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//
//                    }
//                }, new NetConnection.FailCallBack() {
//            @Override
//            public void onFail() {
//
//            }
//        }, Config.KEY_ACTION, Config.ACTION_DISEASE_DETAIL,
//                Config.KEY_TOKEN, Config.getCachedToken(getActivity()),
//                Config.KEY_ID,"1");
//    }

    private void init() {
        Log.i(TAG, "init");
        new NetConnection(Config.URL_TEST, HttpMethod.POST,
                new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        Log.i(TAG, "success+" + result.toString());
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Log.i(TAG, "fail");
            }
        }, Config.KEY_ACTION, Config.ACTION_ARTICLE_SEARCH,
                Config.KEY_SEARCHWORDS, Config.KEY_ACTION);
    }

    private void initView(View view) {
        dates_last = new ArrayList<>();
        dates_hot = new ArrayList<>();

        et_search = (EditText) view.findViewById(R.id.et_search_input);
        img_reminder = (ImageView) view.findViewById(R.id.img_toolbar_reminder);
        block_quick_ask = (RelativeLayout) view.findViewById(R.id.block_quick_ask);
        block_self_diag = (RelativeLayout) view.findViewById(R.id.block_self_diag);
        block_new_article = (RelativeLayout) view.findViewById(R.id.block_new_article_more);
        block_hot_article = (RelativeLayout) view.findViewById(R.id.block_hot_article_more);
        block_topic_more = (RelativeLayout) view.findViewById(R.id.block_topic_more);
        listview_last = (ListView) view.findViewById(R.id.listview_article_last);
        listview_hot = (ListView) view.findViewById(R.id.listview_article_hot);

        initTopic(view);

        et_search.setOnClickListener(this);
        img_reminder.setOnClickListener(this);
//        block_quick_ask.setOnClickListener(this);
        block_self_diag.setOnClickListener(this);
        block_new_article.setOnClickListener(this);
        block_hot_article.setOnClickListener(this);
        block_topic_more.setOnClickListener(this);

        //设置设配器
        adapter_last = new ArticleAdapter(dates_last, getContext());
        adapter_hot = new ArticleAdapter(dates_hot, getContext());

        listview_last.setAdapter(adapter_last);
        listview_hot.setAdapter(adapter_hot);

        initArticleDate();

        listview_last.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(getActivity(), ArticleContent.class);

                L.i("position size" + dates_last.size() + "position:" + position);
                intentToArticle.putExtra(Config.ARTICLE_ID,dates_last.get(position).getKey());
                startActivity(intentToArticle);
            }
        });
        listview_hot.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(getActivity(), ArticleContent.class);

                intentToArticle.putExtra(Config.ARTICLE_ID,dates_hot.get(position).getKey());
                startActivity(intentToArticle);
            }
        });
    }

    private void initTopic(View view) {
        item_topic_1 = (RelativeLayout)view.findViewById(R.id.item_topic_detail_1);
        item_topic_2 = (RelativeLayout)view.findViewById(R.id.item_topic_detail_2);
        item_topic_3 = (RelativeLayout)view.findViewById(R.id.item_topic_detail_3);

//        ((ImageView)item_topic_2.findViewById(R.id.img_head)).setImageBitmap(BitmapTools.getBitmap(getActivity(), R.drawable.topic1));
//        ((TextView) item_topic_2.findViewById(R.id.tv_title)).setText("#你有压力吗#");
//        ((TextView) item_topic_2.findViewById(R.id.tv_floor)).setText("140人跟帖");
//        ((ImageView)item_topic_3.findViewById(R.id.img_head)).setImageBitmap(BitmapTools.getBitmap(getActivity(), R.drawable.topic2));
//        ((TextView) item_topic_3.findViewById(R.id.tv_title)).setText("#大学生整容#");
//        ((TextView) item_topic_3.findViewById(R.id.tv_floor)).setText("354人跟帖");

        item_topic_1.setOnClickListener(this);
        item_topic_2.setOnClickListener(this);
        item_topic_3.setOnClickListener(this);
    }


    public void initArticleDate() {

        //想服务器请求获取最新文章数据
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    Log.i(TAG, "result json:" + result);
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < 3; i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                Log.i(TAG, "no" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                dates_last.add(articleDate);
                            }
                            adapter_last.notifyDataSetChanged();
                            setListViewHeightBasedOnChildren(listview_last);
                            break;
                        default:
                            Log.i(TAG, "status error");
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(getActivity(), "网络连接失败，请检查网络", Toast.LENGTH_SHORT).show();
            }
        },Config.KEY_ACTION,Config.ACTION_LAST_ARTICLE_3,
                Config.KEY_TOKEN, Config.getCachedToken(getActivity()));

        //向服务器请求获取最热文章数据
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < 3; i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                dates_hot.add(articleDate);
                            }
                            adapter_hot.notifyDataSetChanged();
                            setListViewHeightBasedOnChildren(listview_hot);
                            break;
                        default:
                            Toast.makeText(getActivity(), getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(getActivity(), getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(getActivity(), getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_HOT_ARTICLE_3,
                Config.KEY_TOKEN, Config.getCachedToken(getActivity()));
    }

    //根据当前的ListView的列表项计算列表的尺寸,
    // 解决ScrollView嵌套ListView时，会无法正确的计算ListView的大小
    public void setListViewHeightBasedOnChildren(ListView listView) {
         /**
          * by zsx
          * 获取ListView对应的Adapter
          * 这里的adapter是你为listview所添加的adapter，可以是原始adapter，
          * 也可以是自己定义的adapter，本人这里的articleadpter是自己定义的adapter
         */
        ArticleAdapter listAdapter = (ArticleAdapter) listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            // listAdapter.getCount()返回数据项的数目
            View listItem = null;
            try {
                listItem = listAdapter.getView(i, null, listView);
                // 计算子项View 的宽高
                listItem.measure(0, 0);
                // 统计所有子项的总高度
                totalHeight += listItem.getMeasuredHeight();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.et_search_input:
                Intent intentToSearch = new Intent(getActivity(), SearchView.class);

                startActivity(intentToSearch);
                break;
            case R.id.img_toolbar_reminder:
                Intent intentToReminder = new Intent(getActivity(), ListReminder.class);

                startActivity(intentToReminder);
                break;
            case R.id.block_quick_ask:
                Intent intentToQuickAsk = new Intent(getActivity(), QuickAsk.class);

                startActivity(intentToQuickAsk);
                break;
            case R.id.block_self_diag:
                Intent intentToSelfDiag = new Intent(getActivity(), SelfDiag.class);

                startActivity(intentToSelfDiag);
                break;
            case R.id.block_topic_more:
                Intent intentToTopic = new Intent(getActivity(), ListTopic.class);

                startActivity(intentToTopic);
                break;
            case R.id.block_new_article_more:
                Intent intentToNewArticleMore = new Intent(getActivity(), ListArticle.class);

                intentToNewArticleMore.putExtra("kind","last");
                startActivity(intentToNewArticleMore);
                break;
            case R.id.block_hot_article_more:
                Intent intentToHotArticleMore = new Intent(getActivity(), ListArticle.class);

                intentToHotArticleMore.putExtra("kind", "hot");
                startActivity(intentToHotArticleMore);
                break;
            case R.id.item_topic_detail_1:
            case R.id.item_topic_detail_2:
            case R.id.item_topic_detail_3:
                Intent intent = new Intent(getActivity(), TopicDetail.class);

                startActivity(intent);
                break;
        }
    }
}