package com.zsx.healthassistant;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
//import android.os.PersistableBundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;

import com.zsx.healthassistant.activity.Login;
import com.zsx.healthassistant.tools.BitmapTools;

/**
 * Created by 酸奶 on 2016/5/3.
 */
public class SplashActivity extends Activity{

    private Handler mHandler;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_splash);
        initView();
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
    }

    private void initView() {
        mHandler = new Handler();
        ImageView img_start = (ImageView) findViewById(R.id.img_start);

        final ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, 1.2f, 1.0f, 1.2f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scaleAnimation.setFillAfter(true);
        scaleAnimation.setDuration(3000);
        scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        img_start.startAnimation(scaleAnimation);

        mHandler.postDelayed(goToNext, 1500);
    }

    Runnable goToNext = new Runnable() {
        @Override
        public void run() {
            if (Config.getCachedToken(SplashActivity.this) != null) {

                SplashActivity.this.startActivity(new Intent(SplashActivity.this, MainActivity.class));

            } else {
                SplashActivity.this.startActivity(new Intent(SplashActivity.this, Login.class));
            }
           // overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            SplashActivity.this.finish();
        }
    };
}
