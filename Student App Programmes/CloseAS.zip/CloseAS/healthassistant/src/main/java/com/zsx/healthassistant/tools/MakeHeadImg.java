package com.zsx.healthassistant.tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;

/**
 * Created by 酸奶 on 2016/4/20.
 */
public class MakeHeadImg {
    public static Bitmap makeHeadImg(Bitmap bg, String water) {
        Bitmap tarBitmap = bg.copy(Bitmap.Config.ARGB_8888, true);
        int w = tarBitmap.getWidth();
        int h = tarBitmap.getHeight();
        Canvas canvas = new Canvas(tarBitmap);
        //启用抗锯齿和使用设备的文本字距
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DEV_KERN_TEXT_FLAG);
        //水平居中
        textPaint.setTextAlign(Paint.Align.CENTER);

        //字体的相关设置
        textPaint.setTextSize(300.0f);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setColor(0xff39d067);
//        textPaint.setShadowLayer(3f, 1, 1, 0xff000000);

        Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
        //计算文字高度
        float fontHeight = fontMetrics.bottom -fontMetrics.top;
        //计算文字baseline
        float textBaseY = h - (h - fontHeight) / 2 - fontMetrics.bottom;

        //图片上添加水印的位置，这里设置的是中下部处
        canvas.drawText(water, (float) (w * 0.5), textBaseY, textPaint);
        canvas.save(Canvas.ALL_SAVE_FLAG);
        canvas.restore();
        return tarBitmap;
    }
}
