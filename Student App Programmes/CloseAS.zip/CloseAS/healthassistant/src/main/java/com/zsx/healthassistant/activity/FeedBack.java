package com.zsx.healthassistant.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.T;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class FeedBack extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private EditText et_feedback;
    private Button btn_commit;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_feedback);
        initView();
    }

    private void initView() {
        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        tv_title = (TextView) findViewById(R.id.tv_title);
        et_feedback = (EditText) findViewById(R.id.et_feedback_content);
        btn_commit = (Button) findViewById(R.id.btn_commit);

        tv_title.setText("意见反馈");
        btn_commit.setClickable(false);
        btn_commit.setBackgroundColor(0xffdddddd);

        btn_commit.setOnClickListener(this);
        et_feedback.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!"".equals(s.toString())) {
                    btn_commit.setClickable(true);
                    btn_commit.setBackgroundResource(R.drawable.btn_login);
                } else {
                    btn_commit.setClickable(false);
                    btn_commit.setBackgroundColor(0xffdddddd);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_commit:
                new NetConnection(Config.URL_TEST, HttpMethod.POST,
                        new NetConnection.SuccessCallBack() {
                            @Override
                            public void onSuccess(String result) {
                                try {
                                    JSONObject jsonObject = new JSONObject(result);
                                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                        case Config.RESULLT_STATUS_SUCCESS:
                                            Toast.makeText(FeedBack.this, "提交成功", Toast.LENGTH_SHORT).show();
                                            break;
                                        default:
                                            Toast.makeText(FeedBack.this, "提交失败", Toast.LENGTH_SHORT).show();
                                            break;
                                    }
                                } catch (JSONException e) {
                                    Log.i("ZSX","connection failed");
                                    T.s(FeedBack.this, "网络连接失败");
                                    e.printStackTrace();

                                }
                            }
                        }, new NetConnection.FailCallBack() {
                    @Override
                    public void onFail() {

                    }
                }, Config.KEY_ACTION, Config.ACTION_FEEDBACK,
                        Config.KEY_TOKEN, Config.getCachedToken(FeedBack.this),
                        Config.KEY_CONTENT, et_feedback.getText().toString());
                break;

        }
    }
}
