package com.zsx.healthassistant.tools;

/**
 * 字符工具类
 * Created by 酸奶 on 2016/4/27.
 */
public class StringTools {
    //隐藏用户id中间四位数字
    public static String hiddenNum(String num){
        StringBuffer hidden = new StringBuffer();
        for (int i = 0; i < 11; i++) {
            if (i >= 3 && i <= 7) {
                hidden.append("*");
            }else {
                hidden.append(num.charAt(i));
            }
        }
        return hidden.toString();
    }
    public static String getRealUsername(String account) {
        if (!account.contains("@"))
            return account;
        String[] res = account.split("@");
        String userName = res[0];
        return userName;
    }
}
