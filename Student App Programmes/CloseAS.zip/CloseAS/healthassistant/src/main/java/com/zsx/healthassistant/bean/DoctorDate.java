package com.zsx.healthassistant.bean;

import android.graphics.Bitmap;

/**
 * Created by 酸奶 on 2016/4/12.
 */
public class DoctorDate {
    private Bitmap head;
    private String name;
    private String info;
    private String phone;

    public DoctorDate(Bitmap head, String name, String info,String phone) {
        this.head = head;
        this.name = name;
        this.info = info;
        this.phone = phone;
    }

    public Bitmap getHead() {
        return head;
    }

    public void setHead(Bitmap head) {
        this.head = head;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
