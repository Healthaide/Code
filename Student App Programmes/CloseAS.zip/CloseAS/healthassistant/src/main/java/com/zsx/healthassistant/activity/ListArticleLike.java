package com.zsx.healthassistant.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.customView.RefreshableView;
import com.zsx.healthassistant.activity.customView.refreshView.XListView;
import com.zsx.healthassistant.adapter.ArticleAdapter;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListArticleLike extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;
    private ArticleAdapter mAdapter;
    private List<ArticleDate> mDates;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_article);
        initView();
        initArticleDate();
    }

    private void initView() {
        mDates = new ArrayList<>();

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("文章收藏");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);

        //设置设配器
        mAdapter = new ArticleAdapter(mDates, this);
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(ListArticleLike.this, ArticleContent.class);
                intentToArticle.putExtra(Config.ARTICLE_ID, mDates.get(position-1).getKey());
                startActivity(intentToArticle);
            }
        });

        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initArticleDate();
                    }
                },2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initArticleDate();
                    }
                },2000);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("刚刚");
    }

    public void initArticleDate() {
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                mDates.add(articleDate);
                            }
                            mAdapter.notifyDataSetChanged();
                            onLoad();
                            break;
                        default:
                            Toast.makeText(ListArticleLike.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(ListArticleLike.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(ListArticleLike.this, getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_ARTICLE_LIKE,
                Config.KEY_TOKEN, Config.getCachedToken(ListArticleLike.this));
    }
    public void getDate() {
        Drawable drawable = getResources().getDrawable(R.drawable.pic_article_empty);
        BitmapDrawable bd = (BitmapDrawable) drawable;
        Bitmap head = bd.getBitmap();
        String title = "李克强批示非法经营疫苗案";
        String classify = "其他";
        int like = 100;
        int browse = 2403;
        ArticleDate articleDate = new ArticleDate("123",head,title, classify, like, browse);
        mDates.add(articleDate);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
