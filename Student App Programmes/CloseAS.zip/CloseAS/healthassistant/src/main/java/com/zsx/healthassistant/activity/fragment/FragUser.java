package com.zsx.healthassistant.activity.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.ArticleContent;
import com.zsx.healthassistant.activity.FeedBack;
import com.zsx.healthassistant.activity.ListArticleLike;
import com.zsx.healthassistant.activity.ListMyDoctor;
import com.zsx.healthassistant.activity.ListReminder;
import com.zsx.healthassistant.activity.ListTopic;
import com.zsx.healthassistant.activity.Login;
import com.zsx.healthassistant.activity.SetUp;
import com.zsx.healthassistant.activity.info.InfoDoctor;
import com.zsx.healthassistant.activity.info.InfoPerson;
import com.zsx.healthassistant.activity.talk.TalkMain;
import com.zsx.healthassistant.tools.BitmapTools;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class FragUser extends Fragment implements View.OnClickListener{
    private String TAG = "ZSX";
    private static final int INTENT_INFO_PERSON = 1;
    private View rootView;
    private ImageView img_head;
    private ImageView img_reminder;
    private TextView tv_nickname;
    private RelativeLayout item_to_article;
    private RelativeLayout item_to_doctor;
    private RelativeLayout item_to_topic;
    private RelativeLayout item_to_feedback;
    private RelativeLayout item_to_setup;
    private static String path_head="/sdcard/HealthMama/UserHead/";//sd路径

    private RequestQueue mQueue;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (rootView == null) {
            rootView = inflater.inflate(R.layout.frag_user, null);
            Log.i(TAG,"FragUser:new");
        }
        //缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootView已经有parent的错误
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null) {
            parent.removeView(rootView);
            Log.i(TAG,"FragUser:remove");
        }

        initView(rootView);

        return rootView;
    }

    private void initView(View view) {
        mQueue = Volley.newRequestQueue(getActivity());

        img_head = (ImageView) view.findViewById(R.id.img_head);
        img_reminder = (ImageView) view.findViewById(R.id.img_toolbar_reminder);
        tv_nickname = (TextView) view.findViewById(R.id.tv_nickname);
        item_to_article = (RelativeLayout) view.findViewById(R.id.item_to_article);
        item_to_doctor = (RelativeLayout) view.findViewById(R.id.item_to_doctor);
        item_to_topic = (RelativeLayout) view.findViewById(R.id.item_to_topic);
        item_to_feedback = (RelativeLayout) view.findViewById(R.id.item_to_feedback);
        item_to_setup = (RelativeLayout) view.findViewById(R.id.item_to_setup);

        //设置nickname
        if (Config.getCachedNick(getActivity()) == null) {
            tv_nickname.setText("设置昵称");
        } else {
            tv_nickname.setText(Config.getCachedNick(getActivity()));
        }
        initHead();

        img_head.setOnClickListener(this);
        img_reminder.setOnClickListener(this);
        tv_nickname.setOnClickListener(this);
        item_to_setup.setOnClickListener(this);
        item_to_doctor.setOnClickListener(this);
        item_to_topic.setOnClickListener(this);
        item_to_article.setOnClickListener(this);
        item_to_feedback.setOnClickListener(this);


    }
    public void initHead() {
        Bitmap bt = BitmapFactory.decodeFile(path_head + "head.jpg");//从ad中找头像，转化成Bitmap
        if(bt!=null){
            Drawable drawable = new BitmapDrawable(bt);//转换成drawable
            img_head.setImageDrawable(drawable);
        }else {
            ImageRequest imageRequest = new ImageRequest(
                    Config.getCachedHead(getActivity()),
                    new Response.Listener<Bitmap>() {
                        @Override
                        public void onResponse(Bitmap bitmap) {
                            BitmapTools.saveHeadImg(bitmap);
                            img_head.setImageBitmap(bitmap);
                        }
                    }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Log.i(TAG, "fail");
                    img_head.setImageBitmap(BitmapTools.getBitmap(getActivity(), R.drawable.pic_user_head_empty));
                }
            });
            mQueue.add(imageRequest);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.item_to_doctor:
                Intent intentToInfoDoctor = new Intent(getActivity(), ListMyDoctor.class);

                startActivity(intentToInfoDoctor);
                break;
            case R.id.item_to_article:
                Intent intentToArticle = new Intent(getActivity(), ListArticleLike.class);

                startActivity(intentToArticle);
                break;
            case R.id.item_to_topic:
                Intent intentToTopic = new Intent(getActivity(), ListTopic.class);

                startActivity(intentToTopic);
                break;
            case R.id.item_to_setup:
                Intent intentToSetUp = new Intent(getActivity(), SetUp.class);

                startActivity(intentToSetUp);
                break;
            case R.id.item_to_feedback:
                Intent intentToFeedback = new Intent(getActivity(), FeedBack.class);

                startActivity(intentToFeedback);
                break;
            case R.id.tv_nickname:
            case R.id.img_head:
                Intent intentToInfoPerson = new Intent(getActivity(), InfoPerson.class);

                startActivityForResult(intentToInfoPerson, INTENT_INFO_PERSON);
                break;
            case R.id.img_toolbar_reminder:
                Intent intentToReminder = new Intent(getActivity(), ListReminder.class);

                startActivity(intentToReminder);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode ) {
            case INTENT_INFO_PERSON:
                if (Config.getCachedNick(getActivity()) == null) {
                    tv_nickname.setText("设置昵称");
                } else {
                    tv_nickname.setText(Config.getCachedNick(getActivity()));
                }
                initHead();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
