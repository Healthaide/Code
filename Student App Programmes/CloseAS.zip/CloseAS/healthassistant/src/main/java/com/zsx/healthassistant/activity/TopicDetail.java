package com.zsx.healthassistant.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.customView.RefreshableView;
import com.zsx.healthassistant.activity.customView.refreshView.XListView;
import com.zsx.healthassistant.activity.info.InfoDoctor;
import com.zsx.healthassistant.adapter.DoctorAdapter;
import com.zsx.healthassistant.adapter.FollowAdapter;
import com.zsx.healthassistant.bean.DoctorDate;
import com.zsx.healthassistant.bean.FollowDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.BitmapTools;
import com.zsx.healthassistant.tools.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class TopicDetail extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;
    private Button btn_add_like;
    private FollowAdapter mAdapter;
    private List<FollowDate> mDates;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private String depart;
    private String classify;
    private RequestQueue mQueue;

    //test
    private Random random = new Random();
    private int[] mHead = {R.drawable.head1,
            R.drawable.head2,R.drawable.head3,R.drawable.head4,
            R.drawable.head5,R.drawable.head6,R.drawable.head7,
            R.drawable.head8,R.drawable.head9,R.drawable.head10,
            R.drawable.head11,R.drawable.head12,R.drawable.head13,
            R.drawable.head14};
    private String mNickname[] = {"萌鼠","大熊","卡布奇诺","笑笑","海阔天空","咖啡杯里的糖","冰河时代","丑小鸭",
            "留不住的时光","幸福被搁浅","深夜漫步","爱笑的眼睛","背着书包上学去"};
    private String mSchool[] = {"南京大学", "东南大学", "江南大学", "南京航空航天大学", "南京理工大学",
            "中国矿业大学","河海大学","南京农业大学","中国药科大学","南京森林警察学院","江苏大学","扬州大学",
            "苏州大学","江苏科技大学"};
    private String mContent[] = {"水一水","这么年轻，可惜了","这个世界真可怕","这个事件的来龙去脉是什么，没看新闻","百度上了百度热搜了","百度摊上事儿了","揭露了竞价排序的黑幕"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.layout_topic);
        initView();
//        initDoctorDate(depart);
        initFollowDate();
    }

    private void initView() {
        mDates = new ArrayList<>();
        mHandler = new Handler();
        mQueue = Volley.newRequestQueue(this);

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_follow);
        btn_add_like = (Button) findViewById(R.id.btn_add_like);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("话题");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);
        btn_add_like.setTag(0);

        btn_add_like.setOnClickListener(this);

        //设置设配器
        mAdapter = new FollowAdapter(mDates, TopicDetail.this);
        mListView.setAdapter(mAdapter);
        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initFollowDate();
                        onLoad();
                    }
                }, 1500);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initFollowDate();
                        onLoad();
                    }
                }, 1500);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("刚刚");
    }

    public void initFollowDate() {
        for (int i = 0; i < 13; i++) {
            getDate(i);
            mAdapter.notifyDataSetChanged();
        }
    }

    private void getDate(int i) {
        FollowDate followDate = new FollowDate(
//                BitmapTools.getBitmap(TopicDetail.this, mHead[random.nextInt(mHead.length)]),
//                mNickname[random.nextInt(mNickname.length)],
                BitmapTools.getBitmap(TopicDetail.this, mHead[i]),
                mNickname[i],
                random.nextBoolean(),
                i+1,
                (20-i)+"小时前",
                mSchool[random.nextInt(mSchool.length)],
                random.nextBoolean(),
                mContent[random.nextInt(mContent.length)]);
        mDates.add(followDate);
    }
    private void setLikeBtnStatus(String likeBtnStatus) {
        if (likeBtnStatus.equals("y")) {
            btn_add_like.setText("取消关注");
            btn_add_like.setBackgroundResource(R.drawable.btn_doc_cancel_like);
            btn_add_like.setTag(1);
        }else {
            btn_add_like.setText("关注");
            btn_add_like.setBackgroundResource(R.drawable.btn_doc_add_like);
            btn_add_like.setTag(0);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_add_like:
                if ((Integer)btn_add_like.getTag() != 0) {
                    setLikeBtnStatus("n");
                } else if ((Integer)btn_add_like.getTag() == 0) {
                    setLikeBtnStatus("y");
                }
                break;
        }
    }

}
