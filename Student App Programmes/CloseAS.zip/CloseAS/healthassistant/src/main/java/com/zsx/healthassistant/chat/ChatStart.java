package com.zsx.healthassistant.chat;

import android.os.AsyncTask;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.activity.Login;
import com.zsx.healthassistant.tools.L;
import com.zsx.healthassistant.tools.StringTools;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;

/**
 * Created by 酸奶 on 2016/5/8.
 */
public class ChatStart {
    public ChatStart(final String username, final String password, final MessageCallback messageCallback) {
        new AsyncTask<Void, Void, String>(){

            @Override
            protected String doInBackground(Void... params) {
                try {
                    //登录
                    L.i("step to login ");
                    try {
                        XmppTool.getConnection().login(username, password);
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }

                    Presence presence = new Presence(Presence.Type.available);
                    Presence.Mode mode = Presence.Mode.valueOf("available");
                    presence.setMode(mode);
                    presence.setStatus("在线");
                    presence.setPriority(0);
                    XmppTool.getConnection().sendPacket(presence);


                    PacketTypeFilter filter = new PacketTypeFilter(Message.class);
                    L.i("before");
                    PacketListener mPacketListener = new PacketListener() {
                        public void processPacket(Packet packet) {
                            try {
                                if (packet instanceof Message) {// 如果是消息类型
                                    Message msg = (Message) packet;
                                    L.i("12:" + msg.toString() + ":" + msg.toXML());

                                    String chatMessage = msg.getBody();
                                    String from = msg.getFrom();
                                    L.i("message:"+chatMessage);

                                    if (chatMessage == null) {
                                        L.i("null  return");
                                        return;// 如果消息为空，直接返回了
                                    } else if (msg.getType() == Message.Type.error) {
                                        L.i("error type");
                                        chatMessage = "<Error> " + chatMessage;// 错误的消息类型
                                    }else if (from.equals(Config.CHAT_SERVER_NAME)) {
                                        //消息广播
                                        messageCallback.onReceive(chatMessage, Config.CHAT_ALL);
                                    } else if (StringTools.getRealUsername(msg.getTo()).equals(username)) {
                                        String[] res = chatMessage.toString().split("@");

                                        L.i("indexof:"+chatMessage.indexOf("@"));
                                        if (chatMessage.indexOf("@") != -1 && chatMessage.substring(0, chatMessage.indexOf("@")).equals(Config.URL_ADD_KEY_WORD)) {
                                            if (chatMessage.substring(0, chatMessage.indexOf("@")).equals(Config.URL_ADD_KEY_WORD)) {
                                                L.i("key word:" + chatMessage.substring(0, chatMessage.indexOf("@")) + "\nurl" + chatMessage.substring(chatMessage.indexOf("@") + 1));
                                                messageCallback.onReceive(chatMessage.substring(chatMessage.indexOf("@") + 1), Config.CHAT_IMAGE);
                                            }
                                        } else {
                                            L.i("message:" + chatMessage);
                                            messageCallback.onReceive(chatMessage, Config.CHAT_MESSAGE);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                L.i("failed to process packet:");
                                e.printStackTrace();
                            }
                        }
                    };
                    L.i("after");
                    XmppTool.getConnection().addPacketListener(mPacketListener, filter);// 这是最关健的了，少了这句，前面的都是白费功夫

                } catch (XMPPException e) {
                    XmppTool.closeConnection();
                }

                return null;
            }
        }.execute();
    }
    public interface MessageCallback{
        void onReceive(String message,int type);
    }
}
