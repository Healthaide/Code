package com.zsx.healthassistant.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by 酸奶 on 2016/5/3.
 */
public class DBChat extends SQLiteOpenHelper{

    public static final String TABLE_NAME = "chatdates";
    public static final String ID = "_id";
    public static final String CONTENT = "content";
    public static final String TIME = "time";
    public static final String FROM = "from";
    public static final String TO = "to";
    public static final String KIND = "kind";//1:文字2:图片3:语音
    public static final String DELIVERY_STATUS = "read";
    public DBChat(Context context) {
        super(context, "chatdates", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " ("//表名
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"//一则消息的id
                + FROM + "TEXT NOT NULL,"//消息来源
                + TO + "TEXT NOT NULL,"//消息去向
                + TIME + "INTEGER NOT NULL,"//消息时间
                + KIND + "INTEGER NOT NULL,"//消息类型
                + CONTENT + "TEXT NOT NULL,"//消息内容
                + DELIVERY_STATUS + "INTEGER);");//消息状态
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
