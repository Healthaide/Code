package com.zsx.healthassistant.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.adapter.ArticleAdapter;
import com.zsx.healthassistant.adapter.ConmentAdapter;
import com.zsx.healthassistant.bean.ConmentDate;
import com.zsx.healthassistant.bean.DoctorDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.L;
import com.zsx.healthassistant.tools.StringTools;
import com.zsx.healthassistant.tools.T;
import com.zsx.healthassistant.tools.TimeUtil;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class ArticleContent extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";

    private String articleId;
    private ImageView img_reminder;
    private ImageView img_favo;
    private ImageView img_complaint;
    private RatingBar mRatingbar;
    private TextView tv_title;
    private TextView tv_complaint;
    private TextView tv_article_title;
    private TextView tv_data;
    private TextView tv_kind;
    private TextView tv_content;
    private EditText et_comment;
    private ListView mListView;
    private RelativeLayout block_conment_more;

    private ConmentAdapter mAdapter;
    private List<ConmentDate> mDates;

    private RequestQueue mQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_article);

        //获取文章id
        articleId = getIntent().getStringExtra(Config.ARTICLE_ID);
        Log.i("zsx",articleId);

        initView();
        initArticle();//初始化文章内容
//        initConmentDate();//初始化评论信息
    }

    private void initView() {
        mDates = new ArrayList<>();
        mQueue = Volley.newRequestQueue(this);

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        img_favo = (ImageView) findViewById(R.id.img_favo);
        img_complaint = (ImageView) findViewById(R.id.img_complaint);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_complaint = (TextView) findViewById(R.id.tv_complaint);
        tv_article_title = (TextView) findViewById(R.id.tv_article_title);
        tv_data = (TextView) findViewById(R.id.tv_article_data);
        tv_kind = (TextView) findViewById(R.id.tv_article_kind);
        tv_content = (TextView) findViewById(R.id.tv_article_content);
        et_comment = (EditText) findViewById(R.id.et_comment);

        mRatingbar = (RatingBar) findViewById(R.id.ratingBar);
        mListView = (ListView) findViewById(R.id.listview_conment);
        block_conment_more = (RelativeLayout) findViewById(R.id.block_conment_more);

        img_favo.setTag(0);

        img_reminder.setVisibility(View.GONE);
        tv_title.setText("文章");


        img_favo.setOnClickListener(this);
        img_complaint.setOnClickListener(this);
        tv_complaint.setOnClickListener(this);
        block_conment_more.setOnClickListener(this);
        //设置评论提交事件

        et_comment.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) {

                    Long curDate = System.currentTimeMillis();
                    Log.i(Config.TAG, "send;" + curDate);
                    new NetConnection(Config.URL_TEST, HttpMethod.POST,
                            new NetConnection.SuccessCallBack() {
                                @Override
                                public void onSuccess(String result) {
                                    try {
                                        JSONObject jsonObject = new JSONObject(result);
                                        switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                            case Config.RESULLT_STATUS_SUCCESS:
                                                Toast.makeText(ArticleContent.this, "提交成功", Toast.LENGTH_SHORT).show();
                                                et_comment.setText("");
                                                break;
                                            default:
                                                Toast.makeText(ArticleContent.this, "提交失败", Toast.LENGTH_SHORT).show();
                                                break;
                                        }
                                    } catch (JSONException e) {
                                        Log.i("ZSX", "connection failed");
                                        e.printStackTrace();

                                    }
                                }
                            }, new NetConnection.FailCallBack() {
                        @Override
                        public void onFail() {

                        }
                    }, Config.KEY_ACTION, Config.ACTION_COMMENT_COMMIT,
                            Config.KEY_TOKEN, Config.getCachedToken(ArticleContent.this),
                            Config.KEY_ID, articleId,
                            Config.KEY_DATE, curDate.toString(),
                            Config.KEY_CONTENT, et_comment.getText().toString());
                }
                return false;
            }
        });
        //设置收藏事件
        //设置评分事件
        mRatingbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Toast.makeText(ArticleContent.this,rating+"分",Toast.LENGTH_SHORT).show();
            }
        });

        //设置设配器
        mAdapter = new ConmentAdapter(mDates, this);
        mListView.setAdapter(mAdapter);

    }
    private void initArticle() {
        new NetConnection(Config.URL_TEST, HttpMethod.POST,
                new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            Log.i(TAG, "article:" + result.toString());
                            switch (jsonObject.getInt(Config.KEY_STATUS)){
                                case Config.RESULLT_STATUS_SUCCESS:
                                    JSONObject body = jsonObject.getJSONObject("body");
                                    tv_article_title.setText(body.getString(Config.KEY_TITLE));
                                    Long time = Long.parseLong(body.getString(Config.KEY_DATE));
                                    tv_data.setText(TimeUtil.getTime(time) + " " + body.getString(Config.KEY_SOURCE));
                                    tv_kind.setText("来源:"+body.getString(Config.KEY_KIND));
                                    tv_content.setText(body.getString(Config.KEY_ARTICLE));
                                    setLikeBtnStatus(body.getString(Config.KEY_LIKE));
                                    Log.i(TAG,"like:"+body.getString(Config.KEY_LIKE));
                                    initComment(body.getJSONObject(Config.KEY_COMMENT).toString());
                                    break;
                                default:
                                    T.s(ArticleContent.this,"文章获取失败");
                                    break;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Log.i(TAG,"netConnection failed");
            }
        },Config.KEY_ACTION,Config.ACTION_ARTICLE_DETAIL,
                Config.KEY_ID,articleId,
                Config.KEY_TOKEN,Config.getCachedToken(ArticleContent.this));
    }
    //根据获取的信息完善文章信息
    public void initComment(String comment) {
        final RelativeLayout item_comment = (RelativeLayout) findViewById(R.id.item_conment);
        try {
            JSONObject jsonObject = new JSONObject(comment);
            //设置头像，userid（phone），评论内容，时间
            ImageRequest imageRequest = new ImageRequest(
                    Config.URL_HEAD+jsonObject.getString(Config.KEY_HEAD),
                    new Response.Listener<Bitmap>() {
                        @Override
                        public void onResponse(Bitmap bitmap) {
                            L.i("download head success");
                            ((ImageView) item_comment.findViewById(R.id.img_conment_head)).setImageBitmap(bitmap);
                        }
                    }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    L.i("download head fail");
                }
            });
            mQueue.add(imageRequest);
            ((TextView) item_comment.findViewById(R.id.tv_conment_userid)).setText(StringTools.hiddenNum(jsonObject.getString(Config.KEY_PHONE)));
            ((TextView) item_comment.findViewById(R.id.tv_conment_content)).setText(jsonObject.getString(Config.KEY_CONTENT));
            Long time = Long.parseLong(jsonObject.getString(Config.KEY_DATE));
            ((TextView) item_comment.findViewById(R.id.tv_conment_time)).setText(TimeUtil.getChatTime(time));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //手动添加
    public void initConmentDate() {
        RelativeLayout item_conment = (RelativeLayout) findViewById(R.id.item_conment);
        //设置头像，userid（phone），评论内容，时间
        ((ImageView) item_conment.findViewById(R.id.img_conment_head)).setImageBitmap(null);
        ((TextView) item_conment.findViewById(R.id.tv_conment_userid)).setText(StringTools.hiddenNum("17826833449"));
        ((TextView) item_conment.findViewById(R.id.tv_conment_content)).setText(getString(R.string.conment_example));
        ((TextView) item_conment.findViewById(R.id.tv_conment_time)).setText("10" + "小时前");

    }

    //根据当前的ListView的列表项计算列表的尺寸,
    // 解决ScrollView嵌套ListView时，会无法正确的计算ListView的大小
    public void setListViewHeightBasedOnChildren(ListView listView) {
        /**
         * by zsx
         * 获取ListView对应的Adapter
         * 这里的adapter是你为listview所添加的adapter，可以是原始adapter，
         * 也可以是自己定义的adapter，本人这里的ConmentAdapter是自己定义的adapter
         */
        ConmentAdapter listAdapter = (ConmentAdapter) listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_toolbar_back:
                finish();
                break;
            case R.id.block_conment_more:
                Intent intentToMoreConment = new Intent(this, ListConment.class);

                intentToMoreConment.putExtra("id", articleId);
                startActivity(intentToMoreConment);
                break;
            case R.id.img_favo:
                if ((Integer)img_favo.getTag() != 0) {
                    likeCommit("n");
                } else if ((Integer)img_favo.getTag() == 0) {
                    likeCommit("y");
                }
                break;
            case R.id.img_complaint:
            case R.id.tv_complaint:
                Intent intentToComplaint = new Intent(ArticleContent.this, ComplaintArticle.class);

                startActivity(intentToComplaint);
                break;
        }
    }

    private void setLikeBtnStatus(String likeBtnStatus) {
        if (likeBtnStatus.equals("y")) {
            Log.i(TAG, "set like:y");
            img_favo.setImageResource(R.drawable.icon_collection_sel);
            img_favo.setTag(1);
        } else {
            Log.i(TAG, "set like:n");
            img_favo.setImageResource(R.drawable.icon_collection_nor);
            img_favo.setTag(0);
        }
    }
    private void likeCommit(final String like) {
        new NetConnection(Config.URL_TEST, HttpMethod.POST,
                new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                case Config.RESULLT_STATUS_SUCCESS:
                                    if (like.equals("y")) {
                                        setLikeBtnStatus(like);
                                        Toast.makeText(ArticleContent.this, "收藏成功", Toast.LENGTH_SHORT).show();
                                    }else if (like.equals("n")) {
                                        setLikeBtnStatus(like);
                                        Toast.makeText(ArticleContent.this, "取消收藏", Toast.LENGTH_SHORT).show();
                                    }
                                    break;
                                default:
                                    Toast.makeText(ArticleContent.this, "操作失败", Toast.LENGTH_SHORT).show();
                                    break;
                            }
                        } catch (JSONException e) {
                            Log.i(TAG, "Json error");
                            e.printStackTrace();
                        }
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Log.i(TAG, "net fail");
            }
        }, Config.KEY_ACTION, Config.ACTION_LIKE_COMMIT,
                Config.KEY_TOKEN, Config.getCachedToken(ArticleContent.this),
                Config.KEY_ID, articleId,
                Config.KEY_LIKE, like);
    }
}
