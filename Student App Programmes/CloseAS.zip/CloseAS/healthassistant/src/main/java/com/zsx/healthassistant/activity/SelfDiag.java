package com.zsx.healthassistant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.info.InfoDisease;
import com.zsx.healthassistant.adapter.DiagResultAdapter;
import com.zsx.healthassistant.bean.DiagResultDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class SelfDiag extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private ImageView img_toolbar_reminder;
    private TextView tv_title;
    private EditText et_search;
    private ListView mListView;

    private List<DiagResultDate> mDates;
    private DiagResultAdapter mAdapter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_self_diag);
        initView();
    }
    private void initView() {
        mDates = new ArrayList<>();

        tv_title = (TextView) findViewById(R.id.tv_title);

        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (ListView) findViewById(R.id.listview_diag);
        et_search = (EditText) findViewById(R.id.et_search);


        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("自我诊断");
        et_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    new NetConnection(Config.URL_SEARCH, HttpMethod.POST,
                            new NetConnection.SuccessCallBack() {
                                @Override
                                public void onSuccess(String result) {
                                    try {
                                        JSONObject jsonObject = new JSONObject(result);
                                        switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                            case Config.RESULLT_STATUS_SUCCESS:
                                                L.i("result:" + result.toString());
                                                mDates.clear();
                                                mListView.setVisibility(View.VISIBLE);
                                                for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                                    JSONObject body = jsonObject.getJSONObject(Config.KEY_BODY + (i + 1));
                                                    DiagResultDate date = new DiagResultDate(
                                                            body.getInt(Config.KEY_ID),
                                                            body.getString(Config.KEY_TITLE) + "("+
                                                                    body.getString(Config.KEY_KIND)+")",
                                                            body.getInt(Config.KEY_CLICK));
                                                    mDates.add(date);
                                                    mAdapter.notifyDataSetChanged();
                                                }
                                                break;
                                            default:
                                                L.i("result fail");
                                                break;
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, new NetConnection.FailCallBack() {
                        @Override
                        public void onFail() {

                        }
                    },Config.KEY_ACTION,Config.ACTION_SELF_DIAGNOSE,
                            Config.KEY_SEARCHWORDS, et_search.getText().toString());
                }
                return false;
            }
        });
        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mListView.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mAdapter = new DiagResultAdapter(mDates, this);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(SelfDiag.this, InfoDisease.class);

                intent.putExtra(Config.DISEASE_ID, mDates.get(position).getId());
                startActivity(intent);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
