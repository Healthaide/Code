package com.zsx.healthassistant.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.bean.ConmentDate;
import com.zsx.healthassistant.tools.StringTools;
import com.zsx.healthassistant.tools.TimeUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ConmentAdapter extends BaseAdapter{
    private List<ConmentDate> mDates;
    private RelativeLayout mLayout;
    private Context mContext;

    public ConmentAdapter(List<ConmentDate> dates, Context context) {
        this.mDates = dates;
        this.mContext = context;
    }
    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (RelativeLayout) inflater.inflate(R.layout.inc_conment, null);

        ((ImageView) mLayout.findViewById(R.id.img_conment_head)).setImageBitmap(mDates.get(position).getHead());
        ((TextView) mLayout.findViewById(R.id.tv_conment_userid)).setText(StringTools.hiddenNum(mDates.get(position).getUserid()));
        ((TextView) mLayout.findViewById(R.id.tv_conment_content)).setText(mDates.get(position).getContent());
        Long time = Long.parseLong(mDates.get(position).getTime());
        ((TextView) mLayout.findViewById(R.id.tv_conment_time)).setText(TimeUtil.getChatTime(time));

        return mLayout;
    }
    //隐藏用户id中间四位数字
    public String hiddenNum(String num){
        StringBuffer hidden = new StringBuffer();
        for (int i = 0; i < 11; i++) {
            if (i >= 3 && i <= 7) {
                hidden.append("*");
            }else {
                hidden.append(num.charAt(i));
            }
        }
        return hidden.toString();
    }
}
