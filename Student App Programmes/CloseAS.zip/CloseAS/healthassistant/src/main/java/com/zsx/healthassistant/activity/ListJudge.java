package com.zsx.healthassistant.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.customView.RefreshableView;
import com.zsx.healthassistant.activity.customView.refreshView.XListView;
import com.zsx.healthassistant.adapter.ConmentAdapter;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.bean.ConmentDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListJudge extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_judge;
    private ConmentAdapter mAdapter;
    private List<ConmentDate> mDates;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private String doc_id;
    private RequestQueue mQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_article);
        doc_id = getIntent().getStringExtra(Config.DOC_ID);
        initView();
    }

    private void initView() {
        mQueue = Volley.newRequestQueue(this);
        mDates = new ArrayList<>();

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_judge = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("评价列表");
        tv_judge.setText("评价");
        img_reminder.setVisibility(View.GONE);

        tv_judge.setOnClickListener(this);

        //设置设配器
        mAdapter = new ConmentAdapter(mDates, this);
        mListView.setAdapter(mAdapter);
        initJudgeDate();
        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initJudgeDate();
                    }
                },2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initJudgeDate();
                    }
                },2000);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("刚刚");
    }

    public void initJudgeDate() {
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                final JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                final String head = Config.URL_HEAD+body.getString(Config.KEY_HEAD);
                                ImageRequest imageRequest = new ImageRequest(
                                        head,
                                        new Response.Listener<Bitmap>() {
                                            @Override
                                            public void onResponse(Bitmap bitmap) {
                                                L.i("download head success");
                                                try {
                                                    ConmentDate articleDate = new ConmentDate(
                                                            bitmap,
                                                            body.getString(Config.KEY_PHONE),
                                                            body.getString(Config.KEY_CONTENT),
                                                            body.getString(Config.KEY_TIME));
                                                    mDates.add(articleDate);
                                                    mAdapter.notifyDataSetChanged();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError volleyError) {
                                        L.i("download head fail");
                                    }
                                });
                                mQueue.add(imageRequest);
                            }
                            onLoad();
                            break;
                        default:
                            Toast.makeText(ListJudge.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(ListJudge.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(ListJudge.this, getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_JUDGE_GET,
                Config.KEY_TOKEN, Config.getCachedToken(ListJudge.this),
                Config.KEY_PHONE,doc_id);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_toolbar_other:
                Intent intentToJudgeDoctor = new Intent(this, JudgeDoctor.class);
                intentToJudgeDoctor.putExtra(Config.DOC_ID, doc_id);
                startActivity(intentToJudgeDoctor);
                break;
        }
    }
}
