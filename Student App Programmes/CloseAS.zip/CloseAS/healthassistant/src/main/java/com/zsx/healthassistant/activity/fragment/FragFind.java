package com.zsx.healthassistant.activity.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.ListDoctor;
import com.zsx.healthassistant.activity.ListReminder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class FragFind extends Fragment implements View.OnClickListener{
    private String TAG = "ZSX";
    private View rootView;
    private ImageView img_reminder;

    private String[] departments = {"妇科","男科","外科","内科","皮肤科","骨伤科",
            "精神心理科","口腔颌面科","眼科","耳鼻咽喉科","营养科"};
    private int mDepartmentsImg[] = {R.drawable.icon_department_w, R.drawable.icon_department_m,
            R.drawable.icon_department_knife,R.drawable.icon_department_inside,
            R.drawable.icon_department_skin,R.drawable.icon_department_gu,
            R.drawable.icon_department_mind,R.drawable.icon_department_tooth,
            R.drawable.icon_department_eye,R.drawable.icon_department_ear,
            R.drawable.icon_department_veg};
    private int[] resId = new int[departments.length];
    private ExpandableListView expandableListView;

    private ArrayList<String> groupList;
    private List<List<Map<String,String>>> childList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.i(TAG, "");
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.frag_find, null);
            Log.i(TAG,"FragFind:new");
        }
        //缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootView已经有parent的错误
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null) {
            parent.removeView(rootView);
            Log.i(TAG,"FragFind:remove");
        }
        initView(rootView);
        return rootView;
    }

    private void initView(View view) {

        for (int i = 0; i < departments.length; i++) {
            resId[i] = getContext().getResources().getIdentifier("block_" + (i + 1), "id", getContext().getPackageName());
        }


        for (int i = 0; i < departments.length; i++) {
            //为各科室block设置点击事件
            final int finalI = i;
            view.findViewById(resId[i]).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intentToDoctor = new Intent(getActivity(), ListDoctor.class);
                    intentToDoctor.putExtra("depart",departments[finalI]);
                    startActivity(intentToDoctor);
                }
            });

            TextView tv = (TextView) view.findViewById(resId[i]).findViewById(R.id.tv_tab);
            ImageView img = (ImageView) view.findViewById(resId[i]).findViewById(R.id.img_tab);
            img_reminder = (ImageView) view.findViewById(R.id.img_toolbar_reminder);

            img_reminder.setOnClickListener(this);

            tv.setText(departments[i]);
            img.setImageResource(mDepartmentsImg[i]);

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_toolbar_reminder:
                Intent intentToReminder = new Intent(getActivity(), ListReminder.class);

                startActivity(intentToReminder);
                break;
        }
    }
}
