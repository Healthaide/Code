package com.zsx.healthassistant.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.customView.RefreshableView;
import com.zsx.healthassistant.activity.customView.refreshView.XListView;
import com.zsx.healthassistant.adapter.ArticleAdapter;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListArticle extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private String article_kind;

    private ArticleAdapter mAdapter;
    private List<ArticleDate> mDates;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_article);

        article_kind = getIntent().getStringExtra("kind");
        initView();
        initArticleDate(article_kind);
    }

    private void initView() {
        mDates = new ArrayList<>();

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText("Article List");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);



        //设置设配器
        mAdapter = new ArticleAdapter(mDates, this);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(ListArticle.this, ArticleContent.class);
//                intentToArticle.putExtra(Config.ARTICLE_ID,mDates.get(position).getKey());
                intentToArticle.putExtra(Config.ARTICLE_ID, mDates.get(position - 1).getKey());
                startActivity(intentToArticle);

            }
        });

        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initArticleDate(article_kind);
                    }
                },2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initArticleDate(article_kind);
                    }
                },2000);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("Just");
    }
    public void initArticleDate(String kind) {
        String action = kind + "_article_10";
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                ArticleDate articleDate = new ArticleDate(
                                        body.getString(Config.KEY_ID).toString(),
                                        null,
                                        body.getString(Config.KEY_TITLE).toString(),
                                        body.getString(Config.KEY_KIND),
                                        0,
                                        body.getInt(Config.KEY_BROWSE));
                                mDates.add(articleDate);
                            }
                            mAdapter.notifyDataSetChanged();
                            onLoad();
                            break;
                        default:
                            Toast.makeText(ListArticle.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(ListArticle.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(ListArticle.this, getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, action,
                Config.KEY_TOKEN, Config.getCachedToken(ListArticle.this));
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
