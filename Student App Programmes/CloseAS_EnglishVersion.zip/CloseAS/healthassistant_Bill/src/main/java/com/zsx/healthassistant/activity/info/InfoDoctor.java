package com.zsx.healthassistant.activity.info;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.BaseActivityWithBell;
import com.zsx.healthassistant.activity.ListJudge;
import com.zsx.healthassistant.activity.talk.TalkMain;
import com.zsx.healthassistant.adapter.ConmentAdapter;
import com.zsx.healthassistant.bean.ConmentDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.BitmapTools;
import com.zsx.healthassistant.tools.L;
import com.zsx.healthassistant.tools.StringTools;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class InfoDoctor extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_title;
    private Button btn_to_talk;
    private Button btn_add_like;
    private RelativeLayout block_judge_more;
    private ListView mListView;
    private ImageView img_head;
    private TextView tv_name;
    private TextView tv_hospital;
    private TextView tv_department;
    private TextView tv_position;

    private String doc_id;
    private String doc_head;
    private JudgeHead judgeHead;

    private ConmentAdapter mAdapter;
    private List<ConmentDate> mDates;

    private RequestQueue mQueue;
    private Handler mHandler;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_doctor);

        doc_id = getIntent().getStringExtra(Config.DOC_ID);

        initView();
        initDoctorInfo();
    }

    private void initDoctorInfo() {
        new NetConnection(Config.URL_TEST, HttpMethod.POST,
                new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                case Config.RESULLT_STATUS_SUCCESS:
                                    doc_head = Config.URL_HEAD + jsonObject.getString(Config.KEY_HEAD);
                                    initDoctorHead(doc_head);
                                    tv_name.setText(jsonObject.getString(Config.KEY_NAME));
                                    tv_title.setText(jsonObject.getString(Config.KEY_NAME)+"doctor");
                                    tv_hospital.setText(jsonObject.getString(Config.KEY_HOSPITAL));
                                    tv_department.setText(jsonObject.getString(Config.KEY_DEPARTMENT));
                                    tv_position.setText(jsonObject.getString(Config.KEY_POSITION));
                                    setLikeBtnStatus(jsonObject.getString(Config.KEY_LIKE));
                                    for (int i = 0; i < 3; i++) {
                                        final JSONObject body = jsonObject.getJSONObject(Config.KEY_BODY + (i + 1));
                                        final String head = Config.URL_HEAD+body.getString(Config.KEY_HEAD);
                                        ImageRequest imageRequest = new ImageRequest(
                                                head,
                                                new Response.Listener<Bitmap>() {
                                                    @Override
                                                    public void onResponse(Bitmap bitmap) {
                                                        Log.i(TAG, "download head success");
                                                        try {
                                                            ConmentDate articleDate = new ConmentDate(
                                                                    bitmap,
                                                                    body.getString(Config.KEY_PHONE),
                                                                    body.getString(Config.KEY_CONTENT),
                                                                    body.getString(Config.KEY_TIME));
                                                            mDates.add(articleDate);
                                                            mAdapter.notifyDataSetChanged();
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError volleyError) {
                                                Log.i(TAG, "download head fail");
                                            }
                                        });
                                        mQueue.add(imageRequest);
                                    }
                                    break;
                                default:
                                    break;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {

            }
        }, Config.KEY_ACTION, Config.ACTION_DOCTOR_DETAIL,
                Config.KEY_TOKEN, Config.getCachedToken(InfoDoctor.this),
                Config.KEY_PHONE, doc_id);
    }

    private void initView() {
        mQueue = Volley.newRequestQueue(this);
        mHandler = new Handler();
        mDates = new ArrayList<>();

        tv_title = (TextView) findViewById(R.id.tv_title);
        btn_to_talk = (Button) findViewById(R.id.btn_to_talk);
        btn_add_like = (Button) findViewById(R.id.btn_add_like);
        block_judge_more = (RelativeLayout) findViewById(R.id.block_judge_more);
        img_head = (ImageView) findViewById(R.id.img_doctor_head);
        tv_name = (TextView) findViewById(R.id.tv_doctor_name);
        tv_hospital = (TextView) findViewById(R.id.tv_doctor_hospital);
        tv_department = (TextView) findViewById(R.id.tv_doctor_department);
        tv_position = (TextView) findViewById(R.id.tv_doctor_position);
        mListView = (ListView) findViewById(R.id.listview_judge);

        setLikeBtnStatus("n");

        btn_to_talk.setOnClickListener(this);
        btn_add_like.setOnClickListener(this);
        block_judge_more.setOnClickListener(this);
        //设置设配器
        mAdapter = new ConmentAdapter(mDates, this);
        mListView.setAdapter(mAdapter);
    }

    public void initDoctorHead(String url) {
        ImageRequest imageRequest = new ImageRequest(
                url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        Log.i(TAG, "download head success");
                        img_head.setImageBitmap(bitmap);
                    }
                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "download head fail");
            }
        });
        mQueue.add(imageRequest);
    }
    public void initJudgeDate() {
        for (int i = 0; i < 3;i++){
            getDate();
            mAdapter.notifyDataSetChanged();
        }
    }
    public void getDate() {
        Drawable drawable = getResources().getDrawable(R.drawable.pic_user_example);
        BitmapDrawable bd = (BitmapDrawable) drawable;
        Bitmap head = bd.getBitmap();
        String userid = "17826833449";
        String content = getString(R.string.judge_example);
        String time = "10";
        ConmentDate articleDate = new ConmentDate(head,userid, content, time);
        mDates.add(articleDate);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_to_talk:
                Intent intentToTalk = new Intent(this, TalkMain.class);
                intentToTalk.putExtra(Config.DOC_HEAD, doc_head);
                intentToTalk.putExtra(Config.DOC_NAME, tv_name.getText().toString());
                intentToTalk.putExtra(Config.DOC_ID, doc_id);
                startActivity(intentToTalk);
                break;
            case R.id.btn_add_like:
                if ((Integer)btn_add_like.getTag() != 0) {
                    likeCommit("n");
                } else if ((Integer)btn_add_like.getTag() == 0) {
                    likeCommit("y");
                }
                break;
            case R.id.block_judge_more:
                Intent intentToMoreJudge = new Intent(this, ListJudge.class);
                intentToMoreJudge.putExtra(Config.DOC_ID, doc_id);
                startActivity(intentToMoreJudge);
                break;
        }
    }
    private void setLikeBtnStatus(String likeBtnStatus) {
        if (likeBtnStatus.equals("y")) {
            btn_add_like.setText("Cancel");
            btn_add_like.setBackgroundResource(R.drawable.btn_doc_cancel_like);
            btn_add_like.setTag(1);
        }else {
            btn_add_like.setText("Concern");
            btn_add_like.setBackgroundResource(R.drawable.btn_doc_add_like);
            btn_add_like.setTag(0);
        }
    }
    private void getHeadFromNet(String url, final int num) {
        Log.i(TAG, "url:" + url);
        ImageRequest imageRequest = new ImageRequest(
                url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        Log.i(TAG, "download head success");
                        judgeHead.setHead(bitmap, num);
                    }
                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "download head fail");
            }
        });
        mQueue.add(imageRequest);
    }
    private void likeCommit(final String like) {
        new NetConnection(Config.URL_TEST, HttpMethod.POST,
                new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                case Config.RESULLT_STATUS_SUCCESS:
                                    if (like.equals("y")) {
                                        setLikeBtnStatus(like);
                                        Toast.makeText(InfoDoctor.this, "Successfully", Toast.LENGTH_SHORT).show();
                                    }else if (like.equals("n")) {
                                        setLikeBtnStatus(like);
                                        Toast.makeText(InfoDoctor.this, "Cancel", Toast.LENGTH_SHORT).show();
                                    }
                                    break;
                                default:
                                    Toast.makeText(InfoDoctor.this, "Failure", Toast.LENGTH_SHORT).show();
                                    break;
                            }
                        } catch (JSONException e) {
                            Log.i(TAG, "Json error");
                            e.printStackTrace();
                        }
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Log.i(TAG, "net fail");
            }
        }, Config.KEY_ACTION, Config.ACTION_LIKE_COMMIT_DOC,
                Config.KEY_TOKEN, Config.getCachedToken(InfoDoctor.this),
                Config.KEY_PHONE, doc_id,
                Config.KEY_LIKE, like);
    }
    private static class JudgeHead{
        Bitmap[] head;
        Bitmap head_first;
        Bitmap head_second;
        Bitmap head_third;

        void setHead(Bitmap bitmap,int num) {
            head[num] = bitmap;
        }
    }
//    private Handler mHandler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            switch (msg.what) {
//                case 1:
//
//                    break;
//                case 2:
//                    break;
//                case 3:
//                    break;
//                default:
//                    break;
//            }
//            super.handleMessage(msg);
//        }
//    };
}
