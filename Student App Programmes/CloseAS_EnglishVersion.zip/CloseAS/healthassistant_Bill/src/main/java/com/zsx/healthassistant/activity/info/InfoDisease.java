package com.zsx.healthassistant.activity.info;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.BaseActivityWithBell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class InfoDisease extends BaseActivityWithBell implements
        ExpandableListView.OnGroupClickListener{
    private String TAG = "ZSX";
    private TextView tv_title;
    private ImageView img_toolbar_reminder;

    private int disease_id;

    private String[] departments = {"Brief introduction","Pathogeny","Prevention","Nursing"};
    private int depart_logo[] = {
            R.drawable.icon_disease_intro, R.drawable.icon_disease_cause,
            R.drawable.icon_disease_prevent, R.drawable.icon_disease_nursing};

    private ExpandableListView expandableListView;

    private ArrayList<String> groupList;

    private MyExpandableListAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_disease);
        disease_id = getIntent().getIntExtra(Config.DISEASE_ID, -1);
        initView();
    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_title);
        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);

        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("Disease");

        expandableListView = (ExpandableListView) findViewById(R.id.expandListView);
        InitData();
        adapter = new MyExpandableListAdapter(this);
        expandableListView.setAdapter(adapter);

        expandableListView.setOnGroupClickListener(this);


    }

    /***
     * InitData
     */
    void InitData() {
        //添加
        groupList = new ArrayList<>();
        for (int i = 0; i < departments.length; i++) {
            groupList.add(departments[i]);
        }
    }

    /***
     * 重写设配器
     *
     * @author zsx
     *
     */
    class MyExpandableListAdapter extends BaseExpandableListAdapter {
        private Context context;
        private LayoutInflater inflater;

        public MyExpandableListAdapter(Context context) {
            this.context = context;
            inflater = LayoutInflater.from(context);
        }

        //获取group数
        @Override
        public int getGroupCount() {
            return groupList.size();
        }

        //获取child数
        @Override
        public int getChildrenCount(int groupPosition) {
            return 1;
        }

        //根据groupPosition获取group数据
        @Override
        public Object getGroup(int groupPosition) {
            return groupList.get(groupPosition);
        }

        //根据groupPosition、childPosition获取child数据
        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return null;
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {

            return true;
        }

        //逐个设置group的内容
        @Override
        public View getGroupView(int groupPosition, boolean isExpanded,
                                 View convertView, ViewGroup parent) {
            GroupHolder groupHolder = null;
            //获取group信息,且一个group只获取一次
            if (convertView == null) {
                groupHolder = new GroupHolder();
                //获取布局文件
                convertView = inflater.inflate(R.layout.groups, null);

                //获取group的textview和imageview
                groupHolder.img_logo = (ImageView) convertView.findViewById(R.id.img_logo);
                groupHolder.textView = (TextView) convertView.findViewById(R.id.tv_group);
                groupHolder.imageView = (ImageView) convertView.findViewById(R.id.image);

                convertView.setTag(groupHolder);
            } else {
                groupHolder = (GroupHolder) convertView.getTag();
            }

            //设置group内容
            groupHolder.img_logo.setImageResource(depart_logo[groupPosition]);
            groupHolder.textView.setText(getGroup(groupPosition).toString());

            if (isExpanded)
                groupHolder.imageView.setImageDrawable(getResources().getDrawable(R.drawable.icon_arrow_top));
            else
                groupHolder.imageView.setImageDrawable(getResources().getDrawable(R.drawable.icon_arrow_bottom));
            return convertView;
        }

        //逐个设置child的内容
        @Override
        public View getChildView(int groupPosition, int childPosition,
                                 boolean isLastChild, View convertView, ViewGroup parent) {

            convertView = inflater.inflate(R.layout.childs, null);
            ((TextView) convertView.findViewById(R.id.tv_content)).setText(getString(R.string.disease_example));

            return convertView;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
    }

    //group点击事件
    @Override
    public boolean onGroupClick(final ExpandableListView parent, final View v,
                                int groupPosition, final long id) {
        return false;
    }

    class GroupHolder {
        ImageView img_logo;
        TextView textView;
        ImageView imageView;
    }
}
