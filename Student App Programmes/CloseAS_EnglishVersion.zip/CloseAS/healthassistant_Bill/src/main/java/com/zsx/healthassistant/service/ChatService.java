package com.zsx.healthassistant.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Created by 酸奶 on 2016/5/8.
 */
public class ChatService extends Service{
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
