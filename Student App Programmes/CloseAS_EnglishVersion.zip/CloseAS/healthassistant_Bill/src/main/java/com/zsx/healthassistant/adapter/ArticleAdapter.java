package com.zsx.healthassistant.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.talk.ListData;
import com.zsx.healthassistant.bean.ArticleDate;

import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ArticleAdapter extends BaseAdapter{
    private List<ArticleDate> mDates;
    private RelativeLayout mLayout;
    private Context mContext;

    public ArticleAdapter(List<ArticleDate> dates,Context context) {
        this.mDates = dates;
        this.mContext = context;
    }
    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (RelativeLayout) inflater.inflate(R.layout.inc_article, null);

//        ((ImageView) mLayout.findViewById(R.id.img_article)).setImageBitmap(mDates.get(position).getHead());
        ((TextView) mLayout.findViewById(R.id.tv_article_title)).setText(mDates.get(position).getTitle());
        ((TextView) mLayout.findViewById(R.id.tv_article_classify)).setText(mDates.get(position).getClassify());

//        ((TextView) mLayout.findViewById(R.id.tv_article_like)).setText(mDates.get(position).getLike() + "人赞");
        ((TextView) mLayout.findViewById(R.id.tv_article_like)).setVisibility(View.GONE);

        ((TextView) mLayout.findViewById(R.id.tv_article_browse)).setText(mDates.get(position).getBrowse() + " People have seen");

        return mLayout;
    }
}
