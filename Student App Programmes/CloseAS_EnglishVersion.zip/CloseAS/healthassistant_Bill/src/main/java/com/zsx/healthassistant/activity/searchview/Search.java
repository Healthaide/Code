package com.zsx.healthassistant.activity.searchview;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.adapter.SearchAdapter;
import com.zsx.healthassistant.bean.SearchViewBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class Search extends Activity
//        implements SearchView.SearchViewListener
{
    private String TAG = "ZSX";
    /**
     * 搜索结果列表view
     */
    private ListView lvResults;

    /**
     * 搜索view
     */
    private SearchView searchView;


    /**
     * 热搜框列表adapter
     */
    private ArrayAdapter hintAdapter;

    /**
     * 自动补全列表adapter
     */
    private ArrayAdapter autoCompleteAdapter;

    /**
     * 搜索结果列表adapter
     */
    private SearchAdapter resultAdapter;

    private List<SearchViewBean> dbData;

    /**
     * 热搜版数据
     */
    private List<String> hintData;

    /**
     * 搜索过程中自动补全数据
     */
    private List<String> autoCompleteData;

    /**
     * 搜索结果的数据
     */
    private List<SearchViewBean> resultData;

    /**
     * 默认提示框显示项的个数
     */
    private static int DEFAULT_HINT_SIZE = 4;

    /**
     * 提示框显示项的个数
     */
    private static int hintSize = DEFAULT_HINT_SIZE;

    /**
     * 设置提示框显示项的个数
     *
     * @param hintSize 提示框显示个数
     */
    public static void setHintSize(int hintSize) {
        Search.hintSize = hintSize;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_search);
//        initView();
    }
    //初始化视图
//    private void initView() {
//
//        lvResults = (ListView) findViewById(R.id.fragment_lv_search_results);
//        searchView = (SearchView) findViewById(R.id.fragment_search_layout);
//        //设置监听
//        searchView.setSearchViewListener(this);
//        //设置adapter
//        searchView.setTipsHintAdapter(hintAdapter);
//        searchView.setAutoCompleteAdapter(autoCompleteAdapter);
//
//        lvResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(Search.this, position + "", Toast.LENGTH_SHORT).show();
//
//            }
//        });
//    }
//    //初始化数据
//
//    private void initData() {
//
//        //从数据库获取数据
//        getDbData();
//        //初始化热搜版数据
//        getHintData();
//        //初始化自动补全数据
//        getAutoCompleteData("1");
//        //初始化搜索结果数据
//        getResultData("1");
//    }
//
//    public void getDbData() {
//        int size = 100;
//        dbData = new ArrayList<>(size);
//        for (int i = 0; i < size; i++) {
//            dbData.add(new SearchViewBean(R.drawable.pic_search_example,
//                    "android开发必备技能" + (i + 1), "Android自定义view——自定义搜索view", i * 20 + 2 + ""));
//        }
//    }
//
//    public void getHintData() {
//        hintData = new ArrayList<>(hintSize);
//        for (int i = 1; i <= hintSize; i++) {
//            hintData.add("热搜版" + i + "：Android自定义View");
//        }
//        hintAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
//                hintData);
//    }
//    private void getResultData(String text) {
//
//        if (resultData == null) {
//            // 初始化
//            resultData = new ArrayList<>();
//        } else {
//            resultData.clear();
//            for (int i = 0; i < dbData.size(); i++) {
//                if (dbData.get(i).getTitle().contains(text.trim())) {
//                    resultData.add(dbData.get(i));
//                }
//
//            }
//        }
//        if (resultAdapter == null) {
//            resultAdapter = new SearchAdapter(this, resultData, R.layout.item_bean_list);
//        } else {
//            resultAdapter.notifyDataSetChanged();
//        }
//    }
//
//    private void getAutoCompleteData(String text) {
//        if (autoCompleteData == null) {
//            //初始化
//            autoCompleteData = new ArrayList<>(hintSize);
//        } else {
//            // 根据text 获取auto data
//            autoCompleteData.clear();
//            for (int i = 0, count = 0; i < dbData.size()
//                    && count < hintSize; i++) {
//                if (dbData.get(i).getTitle().contains(text.trim())) {
//                    autoCompleteData.add(dbData.get(i).getTitle());
//                    count++;
//                }
//            }
//        }
//        if (autoCompleteAdapter == null) {
//            autoCompleteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, autoCompleteData);
//        } else {
//            autoCompleteAdapter.notifyDataSetChanged();
//        }
//
//    }
//
//    /**
//     * 当搜索框 文本改变时 触发的回调 ,更新自动补全数据
//     * @param text
//     */
//    @Override
//    public void onRefreshAutoComplete(String text) {
//
//        //更新数据
//        getAutoCompleteData(text);
//    }
//
//    /**
//     * 点击搜索键时edit text触发的回调
//     *
//     * @param text
//     */
//    @Override
//    public void onSearch(String text) {
//
//        //更新result数据
//        getResultData(text);
//        lvResults.setVisibility(View.VISIBLE);
//        //第一次获取结果 还未配置适配器
//        if (lvResults.getAdapter() == null) {
//            //获取搜索数据 设置适配器
//            lvResults.setAdapter(resultAdapter);
//        } else {
//            //更新搜索数据
//            resultAdapter.notifyDataSetChanged();
//        }
//        Toast.makeText(Search.this, "完成搜索", Toast.LENGTH_SHORT).show();
//    }
}
