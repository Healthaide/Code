package com.zsx.healthassistant.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.customView.RefreshableView;
import com.zsx.healthassistant.activity.customView.refreshView.XListView;
import com.zsx.healthassistant.activity.info.InfoDoctor;
import com.zsx.healthassistant.adapter.DoctorAdapter;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.bean.ConmentDate;
import com.zsx.healthassistant.bean.DoctorDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListDoctor extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;
    private DoctorAdapter mAdapter;
    private List<DoctorDate> mDates;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private String depart;
    private String classify;
    private RequestQueue mQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        depart = getIntent().getStringExtra("depart");

        setContentView(R.layout.list_article);
        initView();
        initDoctorDate(depart);
    }

    private void initView() {
        mDates = new ArrayList<>();
        mHandler = new Handler();
        mQueue = Volley.newRequestQueue(this);

        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);

        tv_title.setText(depart + "");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);


        //设置设配器
        mAdapter = new DoctorAdapter(mDates, ListDoctor.this);
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToDoctor = new Intent(ListDoctor.this, InfoDoctor.class);
                L.i("position size" + mDates.size() + "position:" + position);
                //handerListVIew占去第0个position，因此此处用position-1
                intentToDoctor.putExtra(Config.DOC_ID, mDates.get(position-1).getPhone());
                startActivity(intentToDoctor);
            }
        });
        mHandler = new Handler();
        mListView.setPullLoadEnable(true);
        mListView.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        start = ++refreshCnt;
                        mDates.clear();
                        initDoctorDate(depart);
                    }
                }, 2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initDoctorDate(depart);
                    }
                }, 2000);
            }
        });
    }
    private void onLoad() {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime("Just");
    }

    public void initDoctorDate(String department) {
        new NetConnection(Config.URL_TEST, HttpMethod.POST, new NetConnection.SuccessCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                        case Config.RESULLT_STATUS_SUCCESS:
                            for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                final JSONObject body = jsonObject.getJSONObject("body" + (i + 1));
                                final String head = Config.URL_HEAD+body.getString(Config.KEY_HEAD);
                                ImageRequest imageRequest = new ImageRequest(
                                        head,
                                        new Response.Listener<Bitmap>() {
                                            @Override
                                            public void onResponse(Bitmap bitmap) {
                                                L.i("download head success");
                                                try {
                                                    DoctorDate doctorDate = new DoctorDate(
                                                            bitmap,
                                                            body.getString(Config.KEY_NAME),
                                                            body.getString(Config.KEY_HOSPITAL) + " " +
                                                                    body.getString(Config.KEY_DEPARTMENT) + " " +
                                                                    body.getString(Config.KEY_POSITION),
                                                            body.getString(Config.KEY_PHONE));
                                                    mDates.add(doctorDate);
                                                    mAdapter.notifyDataSetChanged();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError volleyError) {
                                        L.i("download head fail");
                                    }
                                });
                                mQueue.add(imageRequest);
                            }
                            onLoad();
                            break;
                        default:
                            Toast.makeText(ListDoctor.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (JSONException e) {
                    Toast.makeText(ListDoctor.this, getString(R.string.str_failToGetData), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                Toast.makeText(ListDoctor.this, getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
            }
        }, Config.KEY_ACTION, Config.ACTION_DOCTOR_LIST,
                Config.KEY_TOKEN, Config.getCachedToken(ListDoctor.this),
                Config.KEY_DEPARTMENT,department);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

}
