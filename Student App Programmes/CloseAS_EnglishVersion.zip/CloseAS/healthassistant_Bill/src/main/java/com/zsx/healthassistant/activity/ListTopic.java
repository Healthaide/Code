package com.zsx.healthassistant.activity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.customView.RefreshableView;
import com.zsx.healthassistant.activity.customView.refreshView.XListView;
import com.zsx.healthassistant.adapter.ReminderAdapter;
import com.zsx.healthassistant.bean.ReminderDate;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ListTopic extends BaseActivityWithBell implements View.OnClickListener{
    private ImageView img_reminder;
    private TextView tv_title;
    private TextView tv_other;

    private static Class instance;

    private RefreshableView refreshableView;
    private XListView mListView;
    private Handler mHandler;
    private int start = 0;
    private static int refreshCnt = 0;

    private ReminderAdapter mAdapter;
    private List<ReminderDate> mDates;

    private Random random = new Random();
    private String mReminder[] = {"[Health reminder] Long time to sit on the chair, light damage bone and spine, weight affects blood circulation, even induce cancer, can not be taken lightly. " +
            "Daily attention should be paid to more exercise and less sitting.",
    "[Common disease] Long time sit on the chair, light damage bone and spine, weight affects blood circulation, even induce cancer, can not be taken lightly. Daily attention should be paid to more exercise and less sitting."};

    public static Class getInstance() {
        if (instance != null) {
            instance = ListTopic.class;
        }
        return instance;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_topic);


        initView();
//        initReminderDate();
    }

    private void initView() {
//        mDates = new ArrayList<>();
//
        img_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);
//        mListView = (XListView) findViewById(R.id.listview_article);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_other = (TextView) findViewById(R.id.tv_toolbar_other);
//
        tv_title.setText("Topic Center");
        tv_other.setVisibility(View.GONE);
        img_reminder.setVisibility(View.GONE);
//
//        //设置设配器
//        mAdapter = new ReminderAdapter(mDates, this);
//        mListView.setAdapter(mAdapter);
//
//        mHandler = new Handler();
//        mListView.setPullLoadEnable(true);
//        mListView.setXListViewListener(new XListView.IXListViewListener() {
//            @Override
//            public void onRefresh() {
//                mHandler.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        start = ++refreshCnt;
//                        mDates.clear();
//                        initReminderDate();
//                        onLoad();
//                    }
//                }, 2000);
//            }
//
//            @Override
//            public void onLoadMore() {
//                mHandler.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        initReminderDate();
//                    }
//                }, 2000);
//                onLoad();
//            }
//        });
    }
//    private void onLoad() {
//        mListView.stopRefresh();
//        mListView.stopLoadMore();
//        mListView.setRefreshTime("刚刚");
//    }
//
//    public void initReminderDate() {
//        for (int i = 0; i < 10; i++) {
//            getDate(i);
//            mAdapter.notifyDataSetChanged();
//        }
//    }
//
//    private void getDate(int i) {
//        ReminderDate reminderDate = new ReminderDate(
//                mReminder[random.nextInt(mReminder.length)],
//                "05-"+(12-i));
//        mDates.add(reminderDate);
//    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
}
