package com.zsx.healthassistant.activity.talk;

import android.graphics.Bitmap;

/**
 * Created by 酸奶 on 2016/2/29.
 */
public class ListData {
    //文字内容
    private String content;
    //图片内容
    private Bitmap bitmap;
    //用户
    public static final int USER = 1;
    //机器人
    public static final int RECEIVER = 2;
    //发出者标识符
    private int flag;
    //消息类别标识符 1为文字  2为图片
    private int classify;
    //时间
    private String time;


    public ListData(String content,int flag,String time) {
        this.content = content;
        this.flag = flag;
        this.time = time;
        this.classify = 1;
    }
    public ListData(Bitmap bitmap, int flag,String time){
        this.bitmap = bitmap;
        this.flag = flag;
        this.time = time;
        this.classify = 2;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public int getClassify() {
        return classify;
    }

    public void setClassify(int classify) {
        this.classify = classify;
    }
}
