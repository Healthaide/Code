package com.zsx.healthassistant.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.R;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class QuickAsk extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_title;
    private TextView tv_commit;
    private ImageView img_toolbar_reminder;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_quick_ask);
        initView();
    }

    private void initView() {
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_commit = (TextView) findViewById(R.id.tv_toolbar_other);
        img_toolbar_reminder = (ImageView) findViewById(R.id.img_toolbar_reminder);

        img_toolbar_reminder.setVisibility(View.GONE);
        tv_title.setText("Quilk question");
        tv_commit.setText("Submission");
        tv_commit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_toolbar_other:
                Toast.makeText(this, "Question success", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}
