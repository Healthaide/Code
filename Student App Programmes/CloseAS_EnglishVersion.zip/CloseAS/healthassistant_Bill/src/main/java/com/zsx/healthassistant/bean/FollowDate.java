package com.zsx.healthassistant.bean;

import android.graphics.Bitmap;

/**
 * Created by 酸奶 on 2016/5/13.
 */
public class FollowDate {
    private Bitmap head;
    private String nickname;
    private boolean sex;
    private int floor;
    private String date;
    private String school;
    private boolean like;
    private String content;

    public FollowDate(Bitmap head, String nickname, boolean sex, int floor, String date, String school, boolean like, String content) {
        this.head = head;
        this.nickname = nickname;
        this.sex = sex;//true为男，false为女
        this.floor = floor;
        this.date = date;
        this.school = school;
        this.like = like;
        this.content = content;
    }

    public Bitmap getHead() {
        return head;
    }

    public void setHead(Bitmap head) {
        this.head = head;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public boolean isSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public boolean isLike() {
        return like;
    }

    public void setLike(boolean like) {
        this.like = like;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
