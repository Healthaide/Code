package com.zsx.healthassistant.chat;

/**
 * Created by 酸奶 on 2016/5/8.
 */
public interface Smack {
    public boolean login(String username, String password) throws Exception;
}
