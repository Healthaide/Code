package com.zsx.healthassistant.chat;

import android.util.Log;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.tools.L;
import com.zsx.healthassistant.tools.StringTools;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

/**
 * Created by 酸奶 on 2016/5/8.
 */
public class SmackMethod implements Smack {

    private static final int PACKET_TIMEOUT = 30000;

    private ConnectionConfiguration mXMPPConfig;
    private static XMPPConnection mXMPPConnection;


    public SmackMethod() {
        this.mXMPPConfig = new ConnectionConfiguration(Config.URL_IP, 5222); // use SRV

        this.mXMPPConfig.setReconnectionAllowed(false);
        this.mXMPPConfig.setSendPresence(false);
        this.mXMPPConfig.setCompressionEnabled(false); // disable for now
        this.mXMPPConfig.setSecurityMode(ConnectionConfiguration.SecurityMode.required);

        this.mXMPPConnection = new XMPPConnection(mXMPPConfig);
    }

    private static void openConnection() {
        try {
            //url
            ConnectionConfiguration connConfig = new ConnectionConfiguration(Config.URL_IP, 5222);
            mXMPPConnection = new XMPPConnection(connConfig);
            mXMPPConnection.connect();
        }
        catch (XMPPException xe)
        {
            xe.printStackTrace();
        }
    }

    public static XMPPConnection getConnection() {
        if (mXMPPConnection == null) {
            openConnection();
        }
        return mXMPPConnection;
    }

    public static void closeConnection() {
        mXMPPConnection.disconnect();
        mXMPPConnection = null;
    }

    @Override
    public boolean login(String username, String password) throws Exception {
        if (mXMPPConnection.isConnected()) {
            try {
                mXMPPConnection.disconnect();
            } catch (Exception e) {
                L.d("conn.disconnect() failed: " + e);
            }
        }
        SmackConfiguration.setPacketReplyTimeout(PACKET_TIMEOUT);
        SmackConfiguration.setKeepAliveInterval(-1);
        SmackConfiguration.setDefaultPingInterval(0);

        mXMPPConnection.connect();
        if (!mXMPPConnection.isConnected()) {
            throw new Exception("SMACK connect failed without exception!");
        }
        mXMPPConnection.addConnectionListener(new ConnectionListener() {
            public void connectionClosedOnError(Exception e) {
//                mService.postConnectionFailed(e.getMessage());
            }

            public void connectionClosed() {
            }

            public void reconnectingIn(int seconds) {
            }

            public void reconnectionFailed(Exception e) {
            }

            public void reconnectionSuccessful() {
            }
        });
//        initServiceDiscovery();// 与服务器交互消息监听,发送消息需要回执，判断是否发送成功

        registerMessageListener(username);// 注册监听消息事件
        return mXMPPConnection.isAuthenticated();
    }
    private void registerMessageListener(final String username) {

        PacketTypeFilter filter = new PacketTypeFilter(Message.class);
        L.i("before");
        PacketListener mPacketListener = new PacketListener() {
            public void processPacket(Packet packet) {
                try {
                    if (packet instanceof Message) {// 如果是消息类型
                        Message msg = (Message) packet;
                        L.i("12:" + msg.toString() + ":" + msg.toXML());

                        String chatMessage = msg.getBody();
                        String from = StringTools.getRealUsername(msg.getFrom());
                        String to = StringTools.getRealUsername(msg.getTo());
                        L.i("from:" + from + "to:" + to);

                        if (chatMessage == null) {
                            L.i("null  return");
                            return;// 如果消息为空，直接返回了
                        }else if (msg.getType() == Message.Type.error) {
                            L.i("error type");
                            chatMessage = "<Error> " + chatMessage;// 错误的消息类型
                        }else if (to.equals(username)) {
                            L.i("message:" + chatMessage);
                        }
                    }
                } catch (Exception e) {
                    L.i("failed to process packet:");
                    e.printStackTrace();
                }
            }
        };
        L.i("after");
        XmppTool.getConnection().addPacketListener(mPacketListener, filter);// 这是最关健的了，少了这句，前面的都是白费功夫
    }
}
