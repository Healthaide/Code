package com.zsx.healthassistant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zsx.healthassistant.bean.ProvinceDate;
import com.zsx.healthassistant.R;

import java.util.List;

/**
 * Created by 酸奶 on 2016/4/18.
 */
public class ProvinceAdapter extends BaseAdapter {
    private List<ProvinceDate> mDates;
    private Context mContext;
    private LinearLayout mLayout;

    public ProvinceAdapter(List<ProvinceDate> mDates, Context mContext) {
        this.mDates = mDates;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (LinearLayout) inflater.inflate(R.layout.inc_select_school, null);
        ((TextView) mLayout.findViewById(R.id.tv_name)).setText(mDates.get(position).getProvince_name());
        return mLayout;
    }
}
