package com.zsx.healthassistant.bean;

import android.graphics.Bitmap;

/**
 * Created by 酸奶 on 2016/4/7.
 */
public class ConmentDate {
    private Bitmap head;
    private String userid;
    private String content;
    private String time;

    public ConmentDate(Bitmap head, String userid, String content, String time) {
        this.head = head;
        this.userid = userid;
        this.content = content;
        this.time = time;
    }

    public Bitmap getHead() {
        return head;
    }

    public void setHead(Bitmap head) {
        this.head = head;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
