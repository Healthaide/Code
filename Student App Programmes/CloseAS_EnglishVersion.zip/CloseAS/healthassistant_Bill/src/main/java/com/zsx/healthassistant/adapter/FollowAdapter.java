package com.zsx.healthassistant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.bean.ConmentDate;
import com.zsx.healthassistant.bean.FollowDate;
import com.zsx.healthassistant.tools.StringTools;
import com.zsx.healthassistant.tools.TimeUtil;

import java.util.List;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class FollowAdapter extends BaseAdapter{
    private List<FollowDate> mDates;
    private RelativeLayout mLayout;
    private Context mContext;

    public FollowAdapter(List<FollowDate> dates, Context context) {
        this.mDates = dates;
        this.mContext = context;
    }
    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (RelativeLayout) inflater.inflate(R.layout.inc_follow, null);

        ((ImageView) mLayout.findViewById(R.id.img_head)).setImageBitmap(mDates.get(position).getHead());
        ((TextView) mLayout.findViewById(R.id.tv_nickname)).setText(mDates.get(position).getNickname());
        if (!mDates.get(position).isSex()) {
            ((ImageView) mLayout.findViewById(R.id.img_sex)).setBackgroundResource(R.drawable.icon_sex_woman);
        }
        ((TextView) mLayout.findViewById(R.id.tv_floor)).setText(mDates.get(position).getFloor() + "floor");
        ((TextView) mLayout.findViewById(R.id.tv_date)).setText(mDates.get(position).getDate());
        ((TextView) mLayout.findViewById(R.id.tv_school)).setText("From[" + mDates.get(position).getSchool() + "]");
        if (!mDates.get(position).isLike()) {
            ((ImageView) mLayout.findViewById(R.id.img_favo)).setBackgroundResource(R.drawable.icon_collection_sel);
        }
        ((TextView) mLayout.findViewById(R.id.tv_content)).setText(mDates.get(position).getContent());

        return mLayout;
    }
}
