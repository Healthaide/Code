package com.zsx.healthassistant.net;

import android.util.Log;

import com.zsx.healthassistant.Config;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by zsx on 2016/3/25.
 */
public class GetCode {
    private String TAG = "ZSX";
    public GetCode(String phone, final SuccessCallBack successCallBack,
                   final FailCallBack failCallBack) {
        new NetConnection(Config.URL_TEST, HttpMethod.POST,
                new NetConnection.SuccessCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        try {
                            Log.i(TAG,"GetCode NetConnection onSuccess");
                            JSONObject jsonObject = new JSONObject(result);
                            switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                case Config.RESULLT_STATUS_SUCCESS:
                                    successCallBack.onSuccess();//GetCode 成功时的回调函数
                                    Log.i(TAG,"success to get json");
                                    break;
                                default:
                                    if (failCallBack != null) {
                                        failCallBack.onFail();//NetConnection 失败时的回调函数
                                    }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            if (failCallBack != null) {
                                failCallBack.onFail();//NetConnection 失败时的回调函数
                            }
                        }
                    }
                }, new NetConnection.FailCallBack() {
            @Override
            public void onFail() {
                if (failCallBack != null) {
                    failCallBack.onFail();//NetConnection 失败时的回调函数
                }
            }
        }, Config.KEY_ACTION, Config.ACTION_GET_CODE, Config.KEY_PHONE, phone);
    }
    public static interface SuccessCallBack{
        void onSuccess();
    }
    public static interface FailCallBack{
        void onFail();
    }
}
