package com.zsx.healthassistant.activity.info;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.MainActivity;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.BaseActivityWithBell;
import com.zsx.healthassistant.activity.SelectPicPopupWindow;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.LoginIdent;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.net.UploadFile;
import com.zsx.healthassistant.tools.BitmapTools;
import com.zsx.healthassistant.tools.MakeHeadImg;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by 酸奶 on 2016/3/26.
 */
public class InfoPerson extends BaseActivityWithBell implements View.OnClickListener{
    private String TAG = "zsx";
    private ImageView btn_toolbar_back;
    private TextView tv_title;
    private TextView tv_nickname;
    private TextView tv_userid;
    private TextView tv_sex;
    private TextView tv_area;
    private TextView tv_address;
    private TextView tv_school;

    private LinearLayout item_head;
    private LinearLayout item_nickname;
    private SelectPicPopupWindow menuWindow;

    private Dialog mDialog;

    private RequestQueue mQueue;
    private Handler mHandler;

    private ImageView img_head;//头像显示
    private Bitmap head;//头像Bitmap
    private static String path="/sdcard/HealthMama/UserHead/";//sd路径
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_user);
        initView();
    }

    private void initView() {
        mQueue = Volley.newRequestQueue(this);
        mHandler = new Handler();

        btn_toolbar_back = (ImageView) findViewById(R.id.img_toolbar_back);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_nickname = (TextView) findViewById(R.id.tv_info_nickname);
        tv_userid = (TextView) findViewById(R.id.tv_info_userid);
        tv_sex = (TextView) findViewById(R.id.tv_info_sex);
        tv_area = (TextView) findViewById(R.id.tv_info_area);
        tv_address = (TextView) findViewById(R.id.tv_info_address);
        tv_school = (TextView) findViewById(R.id.tv_info_school);
        item_head = (LinearLayout) findViewById(R.id.info_user_item_head);
        item_nickname = (LinearLayout) findViewById(R.id.info_user_item_nickname);
        img_head = (ImageView) findViewById(R.id.img_head);

        tv_title.setText("个人信息");

        btn_toolbar_back.setOnClickListener(this);
        item_head.setOnClickListener(this);
        item_nickname.setOnClickListener(this);

        initInfo();

    }

    private void initInfo() {
        //设置头像
        Bitmap bt = BitmapFactory.decodeFile(path+"head.jpg");//从ad中找头像，转化成Bitmap
        if(bt!=null){
            Drawable drawable = new BitmapDrawable(bt);//转换成drawable
            img_head.setImageDrawable(drawable);
        }else{
            ImageRequest imageRequest = new ImageRequest(
                    Config.getCachedHead(InfoPerson.this),
                    new Response.Listener<Bitmap>() {
                        @Override
                        public void onResponse(Bitmap bitmap) {
                            BitmapTools.saveHeadImg(bitmap);
                            img_head.setImageBitmap(bitmap);
                        }
                    }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Log.i(TAG, "fail");
                    img_head.setImageBitmap(BitmapTools.getBitmap(InfoPerson.this,R.drawable.pic_user_head_empty));
                }
            });
            mQueue.add(imageRequest);
        }
        //设置nickname
        if (Config.getCachedNick(this) == null) {
            tv_nickname.setText("Set nickname");
        } else {
            tv_nickname.setText(Config.getCachedNick(this));
        }
        //设置userid
        if (Config.getCachedUserid(this) == null) {
            tv_userid.setText("Empty");
        } else {
            tv_userid.setText(Config.getCachedUserid(this));
        }
        //设置sex
        if (Config.getCachedSex(this) == null) {
            tv_sex.setText("Empty");
        } else {
            tv_sex.setText(Config.getCachedSex(this));
        }
        //设置area
        if (Config.getCachedArea(this) == null) {
            tv_area.setText("Empty");
        } else {
            tv_area.setText(Config.getCachedArea(this));
        }
        //设置address
        if (Config.getCachedAddress(this) == null) {
            tv_address.setText("Empty");
        } else {
            tv_address.setText(Config.getCachedAddress(this));
        }
        //设置school
        if (Config.getCachedSchool(this) == null) {
            tv_school.setText("Empty");
        } else {
            tv_school.setText(Config.getCachedSchool(this));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_toolbar_back:
                finish();
                break;
            case R.id.info_user_item_head:

                setBgAlpha(0.5f);//背景虚化

                menuWindow = new SelectPicPopupWindow(InfoPerson.this, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        menuWindow.dismiss();
                        switch (v.getId()) {

                            case R.id.btn_pick_photo://从相册里面取照片
                                setBgAlpha(1.0f);

                                Intent intent1 = new Intent(Intent.ACTION_PICK, null);
                                intent1.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                                startActivityForResult(intent1, 1);
                                break;
                            case R.id.btn_take_photo://调用相机拍照
                                setBgAlpha(1.0f);

                                Intent intent2 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                intent2.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(Environment.getExternalStorageDirectory(),
                                        "head.jpg")));
                                startActivityForResult(intent2, 2);//采用ForResult打开
                                break;
                            default:
                                break;
                        }
                    }
                }, new SelectPicPopupWindow.SetBgAlphaCallBack() {
                    @Override
                    public void setBackgroundAlpha(float alpha) {
                        Log.e(TAG,"Rewrite the callback:");
                        InfoPerson.this.setBgAlpha(alpha);
                    }
                });
                menuWindow.showAtLocation(InfoPerson.this.findViewById(R.id.main),
                        Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,0);//设置layout在PopupWindow中显示的位置
                break;
            case R.id.info_user_item_nickname:

                setBgAlpha(0.5f);//背景虚化
                mDialog = new Dialog(this,R.style.Info_Dialog);

                mDialog.setContentView(LayoutInflater.from(this)
                        .inflate(R.layout.dialog_info, null));
                mDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        setBgAlpha(1.0f);//背景虚化恢复
                    }
                });
                final EditText editText = (EditText) mDialog.findViewById(R.id.et_input);

                mDialog.findViewById(R.id.btn_save).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (TextUtils.isEmpty(editText.getText().toString())) {
                            Toast.makeText(InfoPerson.this, "Please enter the nickname", Toast.LENGTH_SHORT).show();
                        }else if (editText.getText().length() > 6) {
                            Toast.makeText(InfoPerson.this, "Character exceeding restriction", Toast.LENGTH_SHORT).show();
                        }else {
                            modifyInfo(Config.KEY_NICKNAME,editText.getText().toString());
                            mDialog.dismiss();
                        }

                    }
                });
                mDialog.show();
                break;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (mDialog!=null&&mDialog.isShowing()) {
                mDialog.dismiss();
            } else {
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    cropPhoto(data.getData());//裁剪图片
                }

                break;
            case 2:
                if (resultCode == RESULT_OK) {
                    File temp = new File(Environment.getExternalStorageDirectory()
                            + "/head.jpg");
                    cropPhoto(Uri.fromFile(temp));//裁剪图片
                }

                break;
            case 3:
                if (data != null) {
                    Bundle extras = data.getExtras();
                    head = extras.getParcelable("data");
                    if(head!=null){
                        setPicToView(head);//保存在SD卡中
                        img_head.setImageBitmap(head);//用ImageView显示出来
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                new UploadFile(new File(path + "head.jpg"), Config.URL_UPLOAD, Config.getCachedUserid(InfoPerson.this)+Config.JPG,
                                        new UploadFile.SuccessCallBack() {
                                            @Override
                                            public void onSuccess(String result) {
                                                Log.i(TAG, "update head success");
                                            }
                                        }, new UploadFile.FailCallBack() {
                                    @Override
                                    public void onFail() {
                                        Log.i(TAG, "update head failed");
                                    }
                                });
                            }
                        },1000);
                    }
                }
                break;
            default:
                break;

        }
        super.onActivityResult(requestCode, resultCode, data);
    };
    /**
     * 调用系统的裁剪
     * @param uri
     */
    public void cropPhoto(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 150);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 3);
    }
    private void setPicToView(Bitmap mBitmap) {
        String sdStatus = Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // 检测sd是否可用
            return;
        }
        FileOutputStream b = null;
        File file = new File(path);
        file.mkdirs();// 创建文件夹
        String fileName =path + "head.jpg";//图片名字
        try {
            b = new FileOutputStream(fileName);
            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);// 把数据写入文件
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                //关闭流
                b.flush();
                b.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    public void setBgAlpha(float bgAlpha){
        Log.e(TAG, "bgAlpha = " + bgAlpha);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.alpha = bgAlpha;
        getWindow().setAttributes(params);
    }
    public void modifyInfo(String key, final String value) {
        if (key == Config.KEY_NICKNAME) {
//            Config.cacheNick(InfoPerson.this, value);
//            ((TextView) this.findViewById(R.id.tv_info_nickname)).setText(value);


            new NetConnection(Config.URL_TEST, HttpMethod.POST,new NetConnection.SuccessCallBack() {
                @Override
                public void onSuccess(String result) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        switch (jsonObject.getInt(Config.KEY_STATUS)) {
                            case Config.RESULLT_STATUS_SUCCESS:
                                Log.i(TAG, "success");
                                //制作首字符图片，保存替换
                                Bitmap bitmap = MakeHeadImg.makeHeadImg(BitmapTools.getBitmap(InfoPerson.this,
                                        R.drawable.pic_head_empty), String.valueOf(value.charAt(0)));
                                BitmapTools.saveHeadImg(bitmap);

                                Toast.makeText(InfoPerson.this, "Nickname modification success", Toast.LENGTH_SHORT).show();
                                Config.cacheNick(InfoPerson.this, value);
                                ((TextView) InfoPerson.this.findViewById(R.id.tv_info_nickname)).setText(value);
                                break;
                            default:
                                Toast.makeText(InfoPerson.this, getString(R.string.str_failToModifyNickname), Toast.LENGTH_SHORT).show();
                                Log.i(TAG, "status = 1");
                                break;
                        }
                    } catch (JSONException e) {
                        Toast.makeText(InfoPerson.this, getString(R.string.str_failToModifyNickname), Toast.LENGTH_SHORT).show();
                        Log.i(TAG,"Json error"+e.toString());
                        e.printStackTrace();
                    }
                }
            }, new NetConnection.FailCallBack() {
                @Override
                public void onFail() {
                    Toast.makeText(InfoPerson.this, getString(R.string.str_failToConnectNet), Toast.LENGTH_SHORT).show();
                }
            },Config.KEY_ACTION,Config.KEY_MODIFY_NICKNAME,
                    Config.KEY_TOKEN,Config.getCachedToken(InfoPerson.this),
                    Config.KEY_NICKNAME,value);
        } else {
            //TODO:other modification
        }
    }
}
