package com.zsx.healthassistant.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.MainActivity;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.LoginIdent;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.BitmapTools;
import com.zsx.healthassistant.tools.MakeHeadImg;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by 酸奶 on 2016/3/24.
 */
public class Login extends Activity implements View.OnClickListener{
    private String TAG = "ZSX";
    private TextView tv_register;//转到注册
    private TextView tv_forget_password;//忘记密码

    private Button btn_login;//登录按钮
    private EditText et_username;//用户名输入框
    private EditText et_password;//密码输入框

    //test
    private EditText et_modify;
    private TextView tv_ip;
    private Button btn_modify;

    private RequestQueue mQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initView();
    }

    private void initView() {
        mQueue = Volley.newRequestQueue(this);

        tv_register = (TextView) findViewById(R.id.tv_register);
        tv_forget_password = (TextView) findViewById(R.id.tv_forget_password);
        btn_login = (Button) findViewById(R.id.btn_login);
        et_username = (EditText) findViewById(R.id.et_input_username);
        et_password = (EditText) findViewById(R.id.et_input_password);

        tv_register.setOnClickListener(this);
        tv_forget_password.setOnClickListener(this);
        btn_login.setOnClickListener(this);
//        forTest();
    }

    private void forTest() {
//        et_modify = (EditText) findViewById(R.id.et_modify);
//        tv_ip = (TextView) findViewById(R.id.tv_ip);
//        btn_modify = (Button) findViewById(R.id.btn_modify);

//        if (Config.getCachedIp(Login.this) != null) {
//            tv_ip.setText(Config.getCachedIp(Login.this));
//        } else {
//            tv_ip.setText("无");
//        }

        btn_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(et_modify.getText())) {
                    Toast.makeText(Login.this, "Can not be empty", Toast.LENGTH_SHORT).show();

                } else {
                    Config.cacheIp(Login.this, "http://" + et_modify.getText().toString() + Config.URL_SERVLET);
                    tv_ip.setText(Config.getCachedIp(Login.this));
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_forget_password:
                Intent intentTo = new Intent(Login.this, RecoverPassword.class);
                startActivity(intentTo);
                break;
            case R.id.tv_register:
                Intent intentToRegister = new Intent(Login.this, Register.class);
                startActivity(intentToRegister);
                break;
            case R.id.btn_login:
                if (TextUtils.isEmpty(et_username.getText().toString())) {
                    Toast.makeText(Login.this, getString(R.string.str_pleaseInputUsername), Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(et_password.getText().toString())) {
                    Toast.makeText(Login.this, getString(R.string.str_pleaseInputPassword), Toast.LENGTH_SHORT).show();
                    return;
                }
                new NetConnection(Config.URL_TEST, HttpMethod.POST,
                        new NetConnection.SuccessCallBack() {
                            @Override
                            public void onSuccess(String result) {
                                try {
                                    JSONObject jsonObject = new JSONObject(result);
                                    Log.i(TAG, "status:" + jsonObject.toString());

                                    switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                        case Config.RESULLT_STATUS_SUCCESS:
                                            JSONObject body = jsonObject.getJSONObject(Config.KEY_BODY);

                                            //缓存用户信息
                                            Config.cacheHead(Login.this, null);

                                            //token
                                            Config.cacheToken(Login.this, jsonObject.getString(Config.KEY_TOKEN));
                                            //head
                                            Config.cacheHead(Login.this, Config.URL_HEAD + body.getString(Config.KEY_HEAD));
                                            //userid
                                            Config.cacheUserid(Login.this, et_username.getText().toString());
                                            //密码
                                            Config.cachePassword(Login.this, et_password.getText().toString());
                                            //昵称
                                            Config.cacheNick(Login.this, body.getString(Config.KEY_NICKNAME));
                                            //性别
                                            Config.cacheSex(Login.this, body.getString(Config.KEY_SEX));
                                            //地区
                                            Config.cacheArea(Login.this, body.getString(Config.KEY_AREA));
                                            //地址
                                            Config.cacheAddress(Login.this, body.getString(Config.KEY_ADDRESS));
                                            Log.i(TAG, body.getString(Config.KEY_ADDRESS));
                                            //学校
                                            Config.cacheSchool(Login.this, body.getString(Config.KEY_SCHOOL));

                                            getHeadFromNet(Config.URL_HEAD + body.getString(Config.KEY_HEAD));

                                            //登录成功，页面跳转
                                            Intent intent = new Intent(Login.this, MainActivity.class);
                                            startActivity(intent);
                                            finish();
                                            break;
//                                        case Config.RESULT_STATUS_NO_USER:
//                                            Toast.makeText(Login.this, "用户不存在", Toast.LENGTH_SHORT).show();
//                                            break;
//                                        case Config.RESULT_STATUS_PASS_WRONG:
//                                            Toast.makeText(Login.this, "密码错误", Toast.LENGTH_SHORT).show();
//                                            break;
                                        default:
                                            Toast.makeText(Login.this, "User does not exist or password error", Toast.LENGTH_SHORT).show();
                                            break;

                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        }, new NetConnection.FailCallBack() {
                    @Override
                    public void onFail() {

                    }
                }, Config.KEY_ACTION, Config.ACTION_LOGIN,
                        Config.KEY_PHONE, et_username.getText().toString(),
                        Config.KEY_PASSWORD, et_password.getText().toString());
                break;

        }
    }
    private void getHeadFromNet(String url) {
        Log.i(TAG, "url:" + url);
        ImageRequest imageRequest = new ImageRequest(
                url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        Log.i(TAG, "download head success");
                        BitmapTools.saveHeadImg(bitmap);
                    }
                }, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.i(TAG, "download head fail");
            }
        });
        mQueue.add(imageRequest);
    }
}
