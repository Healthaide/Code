package com.zsx.healthassistant.net;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public enum HttpMethod {
    POST,GET
}
