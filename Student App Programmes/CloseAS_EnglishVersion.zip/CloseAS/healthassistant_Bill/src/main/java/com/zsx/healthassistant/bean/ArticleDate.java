package com.zsx.healthassistant.bean;

import android.graphics.Bitmap;

/**
 * Created by 酸奶 on 2016/4/6.
 */
public class ArticleDate {
    private Bitmap head;
    private String title;
    private String classify;
    private String key;
    private int like;
    private int browse;

    public ArticleDate(String key,Bitmap head, String title, String classify, int like, int browse) {
        this.key = key;
        this.head = head;
        this.title = title;
        this.classify = classify;
        this.like = like;
        this.browse = browse;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Bitmap getHead() {
        return head;
    }

    public void setHead(Bitmap head) {
        this.head = head;
    }

    public int getLike() {
        return like;
    }

    public void setLike(int like) {
        this.like = like;
    }

    public String getClassify() {
        return classify;
    }

    public void setClassify(String classify) {
        this.classify = classify;
    }

    public int getBrowse() {
        return browse;
    }

    public void setBrowse(int browse) {
        this.browse = browse;
    }
}
