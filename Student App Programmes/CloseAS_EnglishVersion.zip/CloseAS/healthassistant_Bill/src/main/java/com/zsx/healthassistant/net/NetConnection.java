package com.zsx.healthassistant.net;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.tools.L;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by 酸奶 on 2016/3/25.
 */
public class NetConnection {
    private String TAG = "ZSX";
    private JSONObject result = new JSONObject();

    public NetConnection(final  String url, final HttpMethod method,
                         final SuccessCallBack successCallBack,
                         final FailCallBack failCallBack,
                         final String ... kvs){
        new AsyncTask<Void, Void, String>(){
            @Override
            protected String doInBackground(Void... params) {
                JSONObject jsonObject = new JSONObject();
                for (int i = 0; i < kvs.length; i += 2) {
                    try {
                        jsonObject.put(kvs[i], kvs[i + 1]);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                JSONArray jsonArray = new JSONArray().put(jsonObject);

                L.i(jsonArray.toString());

                HttpParams httpParams = new BasicHttpParams();
                httpParams.setParameter("charset", "UTF-8");
                HttpClient httpClient = new DefaultHttpClient(httpParams);
                HttpPost httpPost = new HttpPost(url);
                Log.i(TAG, "url:" + url);
                try {
                    httpPost.setEntity(new StringEntity(jsonArray.toString(), "UTF-8"));
                    HttpResponse httpResponse = httpClient.execute(httpPost);
                    if (httpResponse.getStatusLine().getStatusCode() == 200) {
                        String returnValue = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
                        JSONArray res = new JSONArray(returnValue);
                        result = res.getJSONObject(0);
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
                if (httpClient != null) {
                    httpClient.getConnectionManager().shutdown();

                }
                return result.toString();
//                try {
//                    URLConnection uc;
//                    switch (method) {
//                        case POST:
//                            uc = new URL(url).openConnection();
//                            Log.i(TAG, "Connection open...");
//                            uc.setDoOutput(true);
//                            BufferedWriter bw = new BufferedWriter(
//                                    new OutputStreamWriter(uc.getOutputStream(), Config.CHARSET));
//                            Log.i(TAG,"BufferedWriter bw");
//                            bw.write(paramsStr.toString());
//                            Log.i(TAG, "bw.write(paramsStr.toString());");
//                            bw.flush();
//                            Log.i(TAG,"bw.flush();");
//                            break;
//                        default:
//                            uc = new URL(url + "?" + paramsStr.toString()).openConnection();
//                            break;
//                    }
//                    Log.i(TAG, "Requst:" + uc.getURL());
//                    Log.i(TAG, "Requst:" + paramsStr);
//
//                    BufferedReader br = new BufferedReader(
//                            new InputStreamReader(uc.getInputStream(), Config.CHARSET));
//                    String line = null;
//
//                    StringBuffer result = new StringBuffer();
//                    while ((line = br.readLine()) != null) {
//                        result.append(line);
//                    }
//                    Log.i(TAG, "Result:" + result);
//                    return result.toString();
//                } catch (MalformedURLException e) {
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                return null;
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    if (successCallBack != null) {
                        successCallBack.onSuccess(result);
                    }
                }else {
                    if (failCallBack != null) {
                        failCallBack.onFail();
                    }
                }
                super.onPostExecute(result);
            }
        }.execute();
    }
    public static interface SuccessCallBack{
        void onSuccess(String result);
    }
    public static interface FailCallBack{
        void onFail();
    }
}
