package com.zsx.healthassistant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.bean.DiagResultDate;

import java.util.List;

/**
 * Created by 酸奶 on 2016/4/13.
 */
public class DiagResultAdapter extends BaseAdapter {
    private List<DiagResultDate> mDates;
    private RelativeLayout mLayout;
    private Context mContext;

    public DiagResultAdapter(List<DiagResultDate> mDates, Context mContext) {
        this.mDates = mDates;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (RelativeLayout) inflater.inflate(R.layout.inc_diag_result, null);
        ((TextView) mLayout.findViewById(R.id.tv_illness)).setText(mDates.get(position).getIllness());
        ((ProgressBar) mLayout.findViewById(R.id.progressbar)).setProgress(mDates.get(position).getPercent());
        return mLayout;
    }
}
