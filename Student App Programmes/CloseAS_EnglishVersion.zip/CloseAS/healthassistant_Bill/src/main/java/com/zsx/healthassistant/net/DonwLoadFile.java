package com.zsx.healthassistant.net;

/**
 * Created by 酸奶 on 2016/5/9.
 */
public class DonwLoadFile {
    public DonwLoadFile(String url) {
    }
}
