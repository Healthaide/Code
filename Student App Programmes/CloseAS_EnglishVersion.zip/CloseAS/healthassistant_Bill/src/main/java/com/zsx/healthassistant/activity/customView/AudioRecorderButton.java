package com.zsx.healthassistant.activity.customView;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.recoder.AudioManager;
import com.zsx.healthassistant.activity.recoder.DialogManager;

import java.lang.ref.WeakReference;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by 酸奶 on 2016/4/17.
 */
public class AudioRecorderButton extends Button implements AudioManager.AudioStateListener{

    private static String TAG = "ZSX";
    private static final int DISTANCE_Y_CANCEL = 50;
    private static final int STATE_NORMAL = 1;
    private static final int STATE_RECORDING = 2;
    private static final int STATE_WANT_TO_CANCEL = 3;

    private Context mContext;
    //记录当前button的状态
    private int mCurState = STATE_NORMAL;
    //记录是否开始录音
    private boolean isRecording = false;
    //是否触发longclick
    private boolean mReady;

    private Timer timer = null;
    private TimerTask timerTask = null;

    private DialogManager mDialogManager;

    private AudioManager mAudioManager;

    //录音计时
    private float mTime = 0;
    private String path="/sdcard/HealthMama/RecoderFile/";

    public AudioRecorderButton(Context context) {
        this(context, null);
    }

    public AudioRecorderButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;

        mDialogManager = new DialogManager(getContext());

        String sdStatus = Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // 检测sd是否可用
            Toast.makeText(getContext(), "sd卡不可用", Toast.LENGTH_SHORT).show();
            return;
        }
        mAudioManager = AudioManager.getInstance(path);
        mAudioManager.setOnAudioStateListener(this);

        setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mReady = true;
                mAudioManager.prepareAudio();
                return false;
            }
        });
    }

    public interface AudioFinishRecorderListener{
        void onFinish(float seconds, String filePath);
    }
    private AudioFinishRecorderListener mListener;

    //提供方法，修改listener
    public void setAudioFinishRecorderListener(AudioFinishRecorderListener listener) {
        mListener = listener;
    }

    //获取音量大小的Runnable
    private Runnable mGetVoiceLevelRunnable = new Runnable() {
        @Override
        public void run() {
            Log.i(TAG, "Run");
            while (isRecording) {
                try {
                    Thread.sleep(100);
                    mTime += 0.1f;
                    Log.i(TAG, "mHandler.sendEmptyMessage(MSG_VOICE_CHANGED); time = " + mTime);
                    mHandler.sendEmptyMessage(MSG_VOICE_CHANGED);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    private static final int MSG_AUDIO_PREPARED = 0x110;
    private static final int MSG_VOICE_CHANGED = 0x111;
    private static final int MSG_DIALOG_DIMISS = 0x112;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_AUDIO_PREPARED:
                    //显示应该在audio end parpeard之后
                    Log.i(TAG, "handler:MSG_AUDIO_PREPARED");
                    mDialogManager.showRecordingDialog();
                    isRecording = true;
//                    updateVoice();
                    new Thread(mGetVoiceLevelRunnable).start();
                    break;
                case MSG_VOICE_CHANGED:
                    Log.i(TAG,"handler:MSG_VOICE_CHANGED");
                    mDialogManager.updateVoiceLevel(mAudioManager.getVoiceLevel(7));
                    break;
                case MSG_DIALOG_DIMISS:
                    Log.i(TAG,"handler:MSG_DIALOG_DIMISS");
                    mDialogManager.dimissDialog();
                    break;
                default:
                    break;
            }
            super.handleMessage(msg);
        }
    };
//    private void updateVoice() {
//        timer = new Timer();
//        timerTask = new TimerTask() {
//            @Override
//            public void run() {
//                Log.i(TAG, "run" + mTime);
//                mDialogManager.updateVoiceLevel(mAudioManager.getVoiceLevel(7));
//
//            }
//        };
//        timer.schedule(timerTask,100);
//        mTime += 0.1f;
//    }
    //重写回调
    @Override
    public void wellPrepared() {
        mHandler.sendEmptyMessage(MSG_AUDIO_PREPARED);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //TODO
                Log.i(TAG, "down");
                changeState(STATE_RECORDING);
                break;
            case MotionEvent.ACTION_MOVE:
                if (isRecording) {
                    //根据x,y的坐标，判断是否想要取消
                    if (wantToCancel(x,y)) {
                        changeState(STATE_WANT_TO_CANCEL);

                    }else {
                        changeState(STATE_RECORDING);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                //longclick未触发
                if (!mReady) {
                    Log.i(TAG, "longclick did not happen");
                    reset();
                    super.onTouchEvent(event);
                }
                //longclick触发，audio未准备完毕
                if (!isRecording) {
                    Log.i(TAG, "audio unready");
                    mDialogManager.tooShort();
                    mAudioManager.cancelAudio();
                    mHandler.sendEmptyMessageDelayed(MSG_DIALOG_DIMISS, 1300);
                }else if (mTime < 0.6f) {
                    Log.i(TAG,"mTime < 0.6");
                    mDialogManager.tooShort();
                    isRecording = false;
                    mAudioManager.cancelAudio();
                    mHandler.sendEmptyMessageDelayed(MSG_DIALOG_DIMISS, 1300);
                }
                //正常录制结束
                if (mCurState == STATE_RECORDING) {
                    //release
                    mDialogManager.dimissDialog();
                    mAudioManager.releaseAudio();
                    if (mListener != null) {
                        mListener.onFinish(mTime, mAudioManager.getCurrentFilePath());
                    }

                    //callbackToAct
                }else if (mCurState == STATE_WANT_TO_CANCEL) {
                    mDialogManager.dimissDialog();
                    mAudioManager.cancelAudio();
                    //cancel
                }
                reset();
                break;
        }
        return super.onTouchEvent(event);
    }

    //恢复状态及标志位
    private void reset() {
        isRecording = false;
        mTime = 0;
        mReady = false;
        changeState(STATE_NORMAL);
    }

    private boolean wantToCancel(int x, int y) {
        if (x < 0 || x > getWidth()) {
            return true;
        }
        if (y < -DISTANCE_Y_CANCEL || y > getHeight() + DISTANCE_Y_CANCEL) {
            return true;
        }
        return false;
    }

    private void changeState(int state) {
        if (mCurState != state) {
            mCurState = state;
            switch (state) {
                case STATE_NORMAL:
                    setBackgroundResource(R.drawable.btn_recorder_normal);
                    setText(R.string.str_recorder_normal);
                    break;
                case STATE_RECORDING:
                    setBackgroundResource(R.drawable.btn_recorder_recording);
                    setText(R.string.str_recorder_recording);
                    if (isRecording) {
                        mDialogManager.recording();
                    }
                    break;
                case STATE_WANT_TO_CANCEL:
                    setBackgroundResource(R.drawable.btn_recorder_recording);
                    setText(R.string.str_recorder_want_cancel);
                    mDialogManager.wantToCancel();
                    break;
            }
        }
    }
}

