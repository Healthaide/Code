package com.zsx.healthassistant.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.zsx.healthassistant.Config;
import com.zsx.healthassistant.R;
import com.zsx.healthassistant.activity.searchview.Search;
import com.zsx.healthassistant.adapter.ArticleAdapter;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.net.HttpMethod;
import com.zsx.healthassistant.net.NetConnection;
import com.zsx.healthassistant.tools.L;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 酸奶 on 2016/4/8.
 */
public class SearchView extends BaseActivityWithBell implements View.OnClickListener{
    private Button btn_cancel;
    private EditText et_search;

    private ListView mListView;
    private ArticleAdapter mAdapter;
    private List<ArticleDate> mDates;

    private JSONArray jsonArray;

    //为测试
    private String[] example = {"The first article","The second article","The third article","The fourth article"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_layout);

        initView();
    }

    private void initView() {
        mDates = new ArrayList<>();

        btn_cancel = (Button) findViewById(R.id.btn_cancel);
        mListView = (ListView) findViewById(R.id.listview_search);
        et_search = (EditText) findViewById(R.id.et_search);

        btn_cancel.setOnClickListener(this);
        mListView.setVisibility(View.GONE);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentToArticle = new Intent(SearchView.this, ArticleContent.class);

                Log.i("zsx","pos:"+position);
                Log.i("zsx",mDates.get(position).getKey());
                intentToArticle.putExtra(Config.ARTICLE_ID,mDates.get(position).getKey());
                startActivity(intentToArticle);
            }
        });
        et_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                    new NetConnection(Config.URL_SEARCH, HttpMethod.POST,
                            new NetConnection.SuccessCallBack() {
                                @Override
                                public void onSuccess(String result) {
                                    Log.i("ZSX", "result" + result.toString());
                                    try {
                                        JSONObject jsonObject = new JSONObject(result);
                                        switch (jsonObject.getInt(Config.KEY_STATUS)) {
                                            case Config.RESULLT_STATUS_SUCCESS:
                                                mDates.clear();
                                                mListView.setVisibility(View.VISIBLE);
//                                                jsonArray = jsonObject.getJSONArray(Config.KEY_LIST);

                                                for (int i = 0; i < jsonObject.getInt(Config.KEY_NUM); i++) {
                                                    JSONObject body = jsonObject.getJSONObject(Config.KEY_BODY + (i + 1));
                                                    ArticleDate articleDate = new ArticleDate(
                                                            body.getString(Config.KEY_ID),
                                                            null,
                                                            body.getString(Config.KEY_TITLE),
                                                            body.getString(Config.KEY_KIND),
                                                            0,
                                                            body.getInt(Config.KEY_CLICK));
                                                    Log.i("zsx init",articleDate.getKey());
                                                    mDates.add(articleDate);
                                                }
                                                mAdapter.notifyDataSetChanged();
                                                break;
                                            default:
                                                L.i("result fail");
                                                break;
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }, new NetConnection.FailCallBack() {
                        @Override
                        public void onFail() {
                            Log.i("ZSX", "error");
                        }
                    }, Config.KEY_ACTION, Config.ACTION_ARTICLE_SEARCH,
                            Config.KEY_SEARCHWORDS, et_search.getText().toString());
                    Log.i("ZSX", "down");
                }
                return false;
            }
        });

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mListView.setVisibility(View.GONE);
//                if ("".equals(s.toString())) {
//                    mListView.setVisibility(View.GONE);
//                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //设置设配器
        mAdapter = new ArticleAdapter(mDates, this);
        mListView.setAdapter(mAdapter);

    }

    public void initResultDate() {
        mDates.clear();

        for (int i = 0; i < 4; i++) {
            getDate();
            mAdapter.notifyDataSetChanged();
        }
    }
    public void getDate() {
        Drawable drawable = getResources().getDrawable(R.drawable.pic_article_empty);
        BitmapDrawable bd = (BitmapDrawable) drawable;
        Bitmap head = bd.getBitmap();
        String title = "Li Keqiang's approval of the illegal operation of the vaccine";
        String classify = "Other";
        int like = 100;
        int browse = 2403;
        ArticleDate articleDate = new ArticleDate("123",head,title, classify, like, browse);
        mDates.add(articleDate);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_cancel:
                this.finish();
                break;
        }
    }
}
