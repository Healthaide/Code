package com.zsx.healthassistant.bean;

/**
 * Created by 酸奶 on 2016/4/13.
 */
public class DiagResultDate {
    private int id;
    private String illness;
    private int percent;

    public DiagResultDate(int id,String illness, int percent) {
        this.id = id;
        this.illness = illness;
        this.percent = percent;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIllness() {
        return illness;
    }

    public void setIllness(String illness) {
        this.illness = illness;
    }

    public int getPercent() {
        return percent;
    }

    public void setPercent(int percent) {
        this.percent = percent;
    }
}
