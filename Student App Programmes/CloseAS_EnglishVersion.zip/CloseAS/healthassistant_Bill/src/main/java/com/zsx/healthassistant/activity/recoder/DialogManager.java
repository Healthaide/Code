package com.zsx.healthassistant.activity.recoder;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.zsx.healthassistant.R;

/**
 * Created by zsx on 2016/1/31.
 */
public class DialogManager {
    private String TAG = "ZSX";
    private Dialog mDialog;

    private ImageView mIcon;
    private ImageView mVoice;
    private ImageView mAlone;

    private TextView mLable;
    private Context mContext;

    private int voiceLevelImg[] = {R.drawable.recorder_voice1,
            R.drawable.recorder_voice2,R.drawable.recorder_voice3,
            R.drawable.recorder_voice4,R.drawable.recorder_voice5,
            R.drawable.recorder_voice6,R.drawable.recorder_voice7};

    public DialogManager(Context context){
        mContext = context;
    }
    //显示dialog
    public void showRecordingDialog() {
        mDialog = new Dialog(mContext, R.style.Theme_AudioDialog);
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.dialog_recorder, null);
        mDialog.setContentView(view);

        mIcon = (ImageView) mDialog.findViewById(R.id.img_icon);
        mVoice = (ImageView) mDialog.findViewById(R.id.img_voice);
        mAlone = (ImageView) mDialog.findViewById(R.id.img_alone);
        mLable = (TextView) mDialog.findViewById(R.id.tv_lable);

        mDialog.show();
    }
    //dialog设置为正在录音
    public void recording(){
        if(mDialog != null&&mDialog.isShowing()){
            mIcon.setVisibility(View.VISIBLE);
            mVoice.setVisibility(View.VISIBLE);
            mAlone.setVisibility(View.GONE);
            mLable.setVisibility(View.VISIBLE);

            mIcon.setImageResource(R.drawable.recorder);
            mLable.setText(R.string.str_dialog_cancel);
        }
    }
    //dialog设置为cancel
    public void wantToCancel(){
        if(mDialog != null&&mDialog.isShowing()){
            mIcon.setVisibility(View.GONE);
            mVoice.setVisibility(View.GONE);
            mAlone.setVisibility(View.VISIBLE);
            mLable.setVisibility(View.VISIBLE);

            mAlone.setImageResource(R.drawable.recorder_cancel);
            mLable.setText(R.string.str_dialog_want_cancel);
        }
    }
    //录音时间过短
    public void tooShort(){
        if(mDialog != null&&mDialog.isShowing()){
            mIcon.setVisibility(View.GONE);
            mVoice.setVisibility(View.GONE);
            mAlone.setVisibility(View.VISIBLE);
            mLable.setVisibility(View.VISIBLE);

            mAlone.setImageResource(R.drawable.recorder_too_short);
            mLable.setText(R.string.str_dialog_too_short);
        }
    }
    //dimiss掉dialog
    public void dimissDialog(){
        if(mDialog != null&&mDialog.isShowing()){
            mDialog.dismiss();
            mDialog = null;
        }
    }
    //
    //通过level去更新voice上的图片
    //@param level 1-7
    public void updateVoiceLevel(int level){
        if(mDialog != null&&mDialog.isShowing()) {
            int resId = mContext.getResources()
                    .getIdentifier("recorder_voice" + level, "drawable", mContext.getPackageName());
            Log.i(TAG, "drawable id" + resId);

//            mVoice.setImageResource(voiceLevelImg[level]);
            Log.i(TAG, "success to set voice level img");

        }
    }

    public static int dip2px(Context context, float dipValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dipValue * scale + 0.5f);
    }
}
