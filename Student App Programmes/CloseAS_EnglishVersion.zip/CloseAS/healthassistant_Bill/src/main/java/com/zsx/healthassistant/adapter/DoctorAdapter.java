package com.zsx.healthassistant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zsx.healthassistant.R;
import com.zsx.healthassistant.bean.ArticleDate;
import com.zsx.healthassistant.bean.DoctorDate;

import java.util.List;

/**
 * Created by 酸奶 on 2016/4/12.
 */
public class DoctorAdapter extends BaseAdapter {
    private List<DoctorDate> mDates;
    private RelativeLayout mLayout;
    private Context mContext;

    public DoctorAdapter(List<DoctorDate> mDates, Context mContext) {
        this.mDates = mDates;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return mDates.size();
    }

    @Override
    public Object getItem(int position) {
        return mDates.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        mLayout = (RelativeLayout) inflater.inflate(R.layout.inc_doctor, null);

        ((ImageView) mLayout.findViewById(R.id.img_head)).setImageBitmap(mDates.get(position).getHead());
        ((TextView) mLayout.findViewById(R.id.tv_name)).setText(mDates.get(position).getName());
        ((TextView) mLayout.findViewById(R.id.tv_info)).setText(mDates.get(position).getInfo());

        return mLayout;
    }
}
