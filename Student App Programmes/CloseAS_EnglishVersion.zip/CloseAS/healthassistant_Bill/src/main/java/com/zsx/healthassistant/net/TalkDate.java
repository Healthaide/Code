package com.zsx.healthassistant.net;

import android.os.AsyncTask;
import android.util.Log;

import com.zsx.healthassistant.Config;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by 酸奶 on 2016/4/3.
 */
public class TalkDate {
    private String TAG = "zsx";

    public TalkDate(final String info, final SuccessCallBack successCallBack, final FailCallBack failCallBack) {
        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {
                try {
                    URLConnection uc;
                    StringBuffer paramsStr = new StringBuffer();
                    paramsStr.append(Config.KEY_KEY+"=").append(Config.API_KEY+"&").
                            append(Config.KEY_INFO + "=").append(info+"&").
                            append(Config.KEY_USERID + "=").append(Config.API_USERID);

                    switch (HttpMethod.POST) {
                        case POST:
                            uc = new URL(Config.API_ANDRESS).openConnection();
                            Log.i(TAG, "Connection open...");
                            uc.setDoOutput(true);
                            BufferedWriter bw = new BufferedWriter(
                                    new OutputStreamWriter(uc.getOutputStream(), Config.CHARSET));
                            Log.i(TAG,"BufferedWriter bw");
                            bw.write(paramsStr.toString());
                            Log.i(TAG, "bw.write(paramsStr.toString());");
                            bw.flush();
                            Log.i(TAG,"bw.flush();");
                            break;
                        default:
                            uc = new URL(Config.API_ANDRESS + "?" + paramsStr.toString()).openConnection();
                            break;
                    }
                    Log.i(TAG, "Requst:" + uc.getURL());
                    Log.i(TAG, "Requst:" + paramsStr);

                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(uc.getInputStream(), Config.CHARSET));
                    String line = null;

                    StringBuffer result = new StringBuffer();
                    while ((line = br.readLine()) != null) {
                        result.append(line);
                    }
                    Log.i(TAG, "Result:" + result);
                    return result.toString();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    if (successCallBack != null) {
                        successCallBack.onSuccess(result);
                    }
                }else {
                    if (failCallBack != null) {
                        failCallBack.onFail();
                    }
                }
                super.onPostExecute(result);
            }
        }.execute();
    }
    public static interface SuccessCallBack{
        void onSuccess(String result);
    }
    public static interface FailCallBack{
        void onFail();
    }
}
